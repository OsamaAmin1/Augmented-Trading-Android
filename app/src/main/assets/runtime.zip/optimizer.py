"""D5 scenario-based integer allocation; not historical forecasts or live authorization."""
import math,random
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from replay import money,fee
from backtest import number,run,historical_gate

def parameters(capital=100000,horizon=20,risk=1.0,reserve=20,asset_cap=60,portfolio_cap=80,turnover=40,alpha=.9,fee_bps=15,spread_bps=45):
 for v,l,h in [(capital,100,1e8),(risk,0,10),(reserve,0,100),(asset_cap,1,100),(portfolio_cap,1,100),(turnover,0,100),(alpha,.5,.99),(fee_bps,0,200),(spread_bps,0,500)]:number(v,l,h)
 if type(horizon)!=int or not 1<=horizon<=20:raise ValueError('Horizon must be 1–20 simulated steps')
 if type(fee_bps)!=int or type(spread_bps)!=int:raise ValueError('Cost inputs must be whole basis points')
 return locals()

def forecast(world,scenario,ids,horizon,n=48):
 """Fixed seed, synchronized block bootstrap exclusively from other development families."""
 family=world.scenarios[scenario]['family'];pool=sorted(k for k,v in world.scenarios.items() if v['split']=='train' and v['family']!=family)
 if not pool:raise ValueError('No independent development families')
 rng=random.Random(1601);out=[]
 for _ in range(n):
  vals=np.ones(len(ids));left=horizon
  while left:
   k=rng.choice(pool);length=min(3,left);start=rng.randrange(len(world.paths[k][ids[0]])-length)
   vals*=np.array([world.paths[k][i][start+length]/world.paths[k][i][start] for i in ids]);left-=length
  out.append(vals)
 return np.array(out),pool

def unit_cost(mid,spread,commission):
 delta=math.ceil(mid*spread/10000);buy=mid+delta;sell=max(1,mid-delta)
 return buy+math.ceil(buy*commission/10000),sell-math.ceil(sell*commission/10000)

def optimize(cash,held,marks,factors,p):
 """Integer buy/sell, binary direction, continuous VaR and CVaR excess. All values in cents."""
 n=len(marks);m=len(factors);eq=cash+sum(q*v for q,v in zip(held,marks))
 if eq<=0:raise ValueError('Nonpositive portfolio equity')
 if any(type(q)!=int or q<0 for q in held) or any(type(v)!=int or v<=0 for v in marks) or cash<0:raise ValueError('Invalid portfolio state')
 if factors.shape!=(m,n) or m<2 or not np.all(np.isfinite(factors)) or np.any(factors<=0):raise ValueError('Invalid forecast scenarios')
 costs=[unit_cost(v,p['spread_bps'],p['fee_bps']) for v in marks];a=np.array([x[0]/eq for x in costs]);s=np.array([x[1]/eq for x in costs]);w=np.array(marks)/eq;h=np.array(held);q0=h*w;cash0=cash/eq
 # variables b[0:n], s[n:2n], direction[2n:3n], VaR, z[scenario]
 N=3*n+1+m;v_idx=3*n;rows=[];low=[];high=[]
 def add(co,l=-np.inf,u=np.inf):rows.append(co);low.append(l);high.append(u)
 def row():return np.zeros(N)
 ub=np.full(N,np.inf);ub[:n]=np.minimum(np.floor(eq/np.array(marks)),1000000);ub[n:2*n]=h;ub[2*n:3*n]=1
 for i in range(n):
  r=row();r[i]=1;r[2*n+i]=-ub[i];add(r,u=0)
  r=row();r[n+i]=1;r[2*n+i]=h[i];add(r,u=h[i])
  r=row();r[:n]=(a-w)*p['asset_cap']/100;r[n:2*n]=(w-s)*p['asset_cap']/100;r[i]+=w[i];r[n+i]-=w[i];add(r,u=p['asset_cap']/100-q0[i])
 r=row();r[:n]=-a+(a-w)*p['reserve']/100;r[n:2*n]=s+(w-s)*p['reserve']/100;add(r,l=p['reserve']/100-cash0)
 r=row();r[:n]=w+(a-w)*p['portfolio_cap']/100;r[n:2*n]=-w+(w-s)*p['portfolio_cap']/100;add(r,u=p['portfolio_cap']/100-q0.sum())
 r=row();r[:n]=w;r[n:2*n]=w;add(r,u=p['turnover']/100)
 # loss = 1 - terminal equity / current equity. Positive-part CVaR via VaR >=0.
 const=1-cash0-factors@q0;coef_buy=a[None,:]-factors*w[None,:];coef_sell=factors*w[None,:]-s[None,:]
 for j in range(m):
  r=row();r[:n]=coef_buy[j];r[n:2*n]=coef_sell[j];r[v_idx]=-1;r[v_idx+1+j]=-1;add(r,u=-const[j])
 obj=row();obj[:n]=coef_buy.mean(axis=0);obj[n:2*n]=coef_sell.mean(axis=0);obj[v_idx]=p['risk'];obj[v_idx+1:]=p['risk']/((1-p['alpha'])*m)
 integ=np.zeros(N);integ[:3*n]=1
 result=milp(obj,integrality=integ,bounds=Bounds(np.zeros(N),ub),constraints=LinearConstraint(np.array(rows),np.array(low),np.array(high)),options={'time_limit':5,'mip_rel_gap':1e-8})
 if result.status!=0 or result.x is None:return {'status':'infeasible' if result.status==2 else 'not_optimal','buy':[0]*n,'sell':[0]*n,'reason':str(result.message)}
 b=np.rint(result.x[:n]).astype(int);sell=np.rint(result.x[n:2*n]).astype(int);target=h+b-sell;after=cash-sum(int(x)*c[0] for x,c in zip(b,costs))+sum(int(x)*c[1] for x,c in zip(sell,costs));loss=1-(after+factors@(target*np.array(marks)))/eq
 # independently check integer feasibility before returning
 eps=1e-8;posteq=after+sum(int(q)*v for q,v in zip(target,marks))
 if np.any(b*sell) or np.any(target<0) or after/posteq+eps<p['reserve']/100 or np.any(target*np.array(marks)/posteq>p['asset_cap']/100+eps) or (target*np.array(marks)).sum()/posteq>p['portfolio_cap']/100+eps or ((b+sell)*w).sum()>p['turnover']/100+eps:raise ValueError('Solver result failed independent feasibility check')
 # empirical CVaR via minimization over positive loss breakpoints
 tail=min(float(t+np.maximum(loss-t,0).mean()/(1-p['alpha'])) for t in [0,*[float(x) for x in loss if x>0]])
 return {'status':'optimal','buy':b.tolist(),'sell':sell.tolist(),'target':target.tolist(),'estimated_cash':after/100,'expected_return_pct':float(-loss.mean()*100),'cvar_loss_pct':tail*100,'objective_pct':float((-loss.mean()-p['risk']*tail)*100),'solver_gap':float(result.mip_gap),'forecast_count':m}

def execute(cash,held,marks,buy,sell,p):
 """Atomic basket at next marks; reject if cash or risk limits would be breached. Costs conservative."""
 costs=[unit_cost(v,p['spread_bps'],p['fee_bps']) for v in marks];eq=cash+sum(q*v for q,v in zip(held,marks));target=[h+b-s for h,b,s in zip(held,buy,sell)]
 after=cash-sum(b*c[0] for b,c in zip(buy,costs))+sum(s*c[1] for s,c in zip(sell,costs));new_eq=after+sum(q*v for q,v in zip(target,marks));tol=1e-6
 if min(target)<0 or after<0 or new_eq<=0 or after+tol<new_eq*p['reserve']/100 or any(q*v>new_eq*p['asset_cap']/100+tol for q,v in zip(target,marks)) or sum(q*v for q,v in zip(target,marks))>new_eq*p['portfolio_cap']/100+tol or sum((b+s)*v for b,s,v in zip(buy,sell,marks))>eq*p['turnover']/100+tol:
  return cash,held,0,'rejected_at_next_quote'
 return after,target,eq-new_eq,'filled' if any(buy+sell) else 'hold'

def experiment(world,scenario,ids,expose=False,initial_holdings=None,limit=None,**kwargs):
 p=parameters(**kwargs)
 if scenario not in world.scenarios or (world.scenarios[scenario]['split']!='train' and expose is not True):raise ValueError('Unknown scenario or explicit evaluation exposure required')
 if not isinstance(ids,list) or not 1<=len(ids)<=5 or len(set(ids))!=len(ids) or any(i not in world.models or world.models[i]!='equity_proxy' or world.kind(i)!='exchange' for i in ids):raise ValueError('Choose 1–5 distinct equity proxies')
 held=initial_holdings if initial_holdings is not None else [0]*len(ids)
 if not isinstance(held,list) or len(held)!=len(ids) or any(type(q)!=int or not 0<=q<=1000000 for q in held):raise ValueError('Invalid initial holdings')
 held=held[:];baseline_held=held[:];cash=money(p['capital']);paths=[world.paths[scenario][i] for i in ids];initial=cash+sum(q*v[0] for q,v in zip(held,paths));last=len(paths[0])-1
 if limit is None:limit=last
 if type(limit)!=int or not 0<=limit<=last:raise ValueError('Invalid replay cutoff')
 factors,pool=forecast(world,scenario,ids,p['horizon']);curve=[];decisions=[];orders=[];pending=None;peak=initial;cost_total=0
 for t in range(limit+1):
  marks=[v[t] for v in paths]
  if pending:
   cash,held,cost,status=execute(cash,held,marks,pending['buy'],pending['sell'],p);cost_total+=cost;orders.append({'submitted_step':t-1,'execution_step':t,'status':status,'buy':pending['buy'],'sell':pending['sell'],'cost':cost/100});pending=None
  equity=cash+sum(q*v for q,v in zip(held,marks));peak=max(peak,equity);curve.append({'step':t,'cash':cash/100,'holdings':held[:],'equity':equity/100,'drawdown_pct':(1-equity/peak)*100})
  decision=optimize(cash,held,marks,factors,p);decisions.append({'step':t,**decision});pending=decision if decision['status']=='optimal' and any(decision['buy']+decision['sell']) else None
 # Cost-matched passive comparator: one initial equal-weight basket, or hold initial units.
 base_cash=money(p['capital']);base_curve=[initial/100];base_status='hold_existing' if any(baseline_held) else 'no_next_quote';base_cost=0
 if limit>=1 and not any(baseline_held):
  budget=.95*initial*min(p['turnover'],p['portfolio_cap'],100-p['reserve'],p['asset_cap']*len(ids))/100/len(ids)
  units=[int(budget//unit_cost(v[0],p['spread_bps'],p['fee_bps'])[0]) for v in paths]
  base_cash,baseline_held,base_cost,base_status=execute(base_cash,baseline_held,[v[1] for v in paths],units,[0]*len(ids),p)
 for t in range(1,limit+1):base_curve.append((base_cash+sum(q*v[t] for q,v in zip(baseline_held,paths)))/100)
 return {'passive':{'curve':base_curve,'return_pct':(base_curve[-1]/(initial/100)-1)*100,'entry_status':base_status,'cost':base_cost/100},'scenario':scenario,'split':world.scenarios[scenario]['split'],'ids':ids,'parameters':p,'initial_equity':initial/100,'ending_equity':curve[-1]['equity'],'return_pct':(curve[-1]['equity']/(initial/100)-1)*100,'max_drawdown_pct':max(x['drawdown_pct'] for x in curve),'cost_total':cost_total/100,'curve':curve,'decisions':decisions,'orders':orders,'pending_unexecuted':bool(pending),'forecast_pool':pool,'data_class':'D5','historical_verified':False,'live_authorized':False,'benchmark_gross_pct':(world.factors[scenario]['EGX30'][limit]/world.factors[scenario]['EGX30'][0]-1)*100,'cash_baseline_pct':0 if not any(initial_holdings or []) else None,'warning':'20 steps are synthetic forecast periods, not verified trading days. Reoptimizes one basket at a time. No actual future path used; forecasts from other development families only. No leverage, settlement or real execution.'}
