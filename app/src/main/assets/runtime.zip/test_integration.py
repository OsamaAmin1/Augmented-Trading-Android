import os,tempfile,csv,json,hashlib
from pathlib import Path
from fastapi.testclient import TestClient
P=Path(__file__).parent; tmp=tempfile.TemporaryDirectory();os.environ['INVESTOR_DB']=str(Path(tmp.name)/'test.sqlite')
import server as s,academy as ac
from store import Store
checks=[]
def ck(n,v):checks.append({'test':n,'passed':bool(v)});assert v,n
A=TestClient(s.app,base_url='http://localhost');B=TestClient(s.app,base_url='http://localhost');pw='test-fictional-long-password'
for path in ['/academy','/progress','/integration','/academy/api/catalogue','/progress/api/evidence','/integration/api/status']:
 ck('anonymous blocked '+path,A.get(path).status_code==401)
for c,alias in [(A,'tester_a'),(B,'tester_b')]:
 ck('register '+alias,c.post('/account/register',json={'alias':alias,'password':pw}).status_code==200);ck('login '+alias,c.post('/account/login',json={'alias':alias,'password':pw}).status_code==200)
for path in ['/academy','/progress','/integration']:
 ck('authenticated page '+path,A.get(path).status_code==200)
cat=A.get('/academy/api/catalogue').json();ck('31 lessons',len(cat['modules'])==31);ck('35 strategies',len(cat['strategies'])==35);ck('initial no progress',cat['passed_count']==0)
ck('prerequisite blocked',A.get('/academy/api/lesson?id=AC-02').status_code==400)
ck('unknown rejected',A.get('/academy/api/lesson?id=bad').status_code==400)
quiz=A.get('/academy/api/lesson?id=AC-01').json()['quiz'];ck('no answer keys',all('correct' not in q and 'feedback' not in q for q in quiz))
ck('incomplete quiz blocked',A.post('/academy/api/submit',json={'id':'AC-01','answers':{}}).status_code==400)
correct=lambda i:{q['id']:q['correct'] for q in ac.MODULES[i]['quiz']}
wrong={q['id']:(q['correct']+1)%len(q['choices']) for q in ac.MODULES['AC-01']['quiz']}
ck('locked submission blocked',A.post('/academy/api/submit',json={'id':'AC-02','answers':correct('AC-02')}).status_code==400)
ck('invalid bool answer rejected',A.post('/academy/api/submit',json={'id':'AC-01','answers':{q['id']:True for q in quiz}}).status_code==400)
r=A.post('/academy/api/submit',json={'id':'AC-01','answers':wrong}).json();ck('wrong quiz fails',r['score']==0 and not r['passed_this_attempt']);ck('does not unlock',A.get('/academy/api/lesson?id=AC-02').status_code==400)
r=A.post('/academy/api/submit',json={'id':'AC-01','answers':correct('AC-01')}).json();ck('passed correct quiz',r['passed_this_attempt'] and r['progress']['attempts']==2);ck('prerequisite now unlocked',A.get('/academy/api/lesson?id=AC-02').status_code==200);ck('second account no progress',B.get('/academy/api/catalogue').json()['passed_count']==0)
ck('no financial gate change',A.get('/api/profile').json()['approved_allocation']==0 and not A.get('/api/profile').json()['assessments'])
s.store.db.close();s.store=Store(os.environ['INVESTOR_DB']);ck('restart requires login',A.get('/academy/api/catalogue').status_code==401);ck('relogin',A.post('/account/login',json={'alias':'tester_a','password':pw}).status_code==200);ck('progress persisted',A.get('/academy/api/catalogue').json()['passed_count']==1)
# All lessons through dependency order; source definitions unchanged.
remaining=set(ac.MODULES)-{'AC-01'};passed={'AC-01'}
while remaining:
 ready=sorted(i for i in remaining if set(ac.MODULES[i]['prerequisites'])<=passed);ck('acyclic next curriculum batch '+str(len(passed)),bool(ready))
 for i in ready:
  r=A.post('/academy/api/submit',json={'id':i,'answers':correct(i)});ck('complete '+i,r.status_code==200 and r.json()['passed_this_attempt']);passed.add(i);remaining.remove(i)
ck('all 31 passed',A.get('/academy/api/catalogue').json()['passed_count']==31)
r=A.post('/academy/api/submit',json={'id':'AC-01','answers':wrong}).json();ck('historical pass preserved on retry',r['progress']['passed'] and r['progress']['last_score']==0)
scenario=next(k for k,v in s.world.scenarios.items() if v['split']=='train');w=A.post('/market/api/start',json={'scenario':scenario,'capital':100000}).json();t=w['token'];ck('queued virtual order',A.post('/market/api/order',json={'token':t,'replay_revision':0,'id':'EGX:ADIB','side':'buy','quantity':100}).status_code==200);ck('advance replay',A.post('/market/api/advance',json={'token':t,'replay_revision':1}).status_code==200)
e=A.get('/progress/api/evidence').json();ck('descriptive evidence',e['education']==31 and e['replays'][0]['filled_buys']==1 and e['behavioral_inference']=='not performed');ck('live still disabled',e['approved_allocation']==0 and not e['live_authorized']);ck('academy private export',len(A.get('/api/export').json()['profile']['academy']['modules'])==31)
ck('encrypted progress',b'first_pass' not in Path(os.environ['INVESTOR_DB']).read_bytes());ck('formal audit gate closed',A.get('/integration/api/status').json()['formal_mappings_verified']==0)
ck('warehouse unchanged',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip())
ck('original curriculum byte identical',hashlib.sha256((P/'runtime/trading_academy_v1/academy_data.json').read_bytes()).hexdigest()==hashlib.sha256((P.parent/'historical_replay_phase17/runtime/trading_academy_v1/academy_data.json').read_bytes()).hexdigest())
with (P/'integration_checks.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=['test','passed']);w.writeheader();w.writerows(checks)
print('PASS',len(checks))
