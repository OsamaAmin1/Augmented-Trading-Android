# Phase 14 — Market Intelligence Lab V1.0

Integrated offline extension of Phase 13. Use fictional financial inputs until an independent security review. No brokerage access, investment recommendation, or trained model. The previous 72-table warehouse is unchanged, checksum verified. Account data remains in a separate local encrypted store. No personal account database ships.

## Run
Python 3.13, `python -m pip install -r requirements.txt`, then `python server.py` or START_WINDOWS.bat. Open http://127.0.0.1:8767, sign in, select Market Intelligence Lab. For replay mode first create a Market World session, advance it, then open the Lab and select the saved replay. Reopen/refresh the Lab after advancing elsewhere. The historical mode is a candidate date-cutoff view, not an executable historical trading environment.

## Implementation
- Source-linked historical events: 21 global and 44 dated local disclosures by 2026-11-25; 6 undated local records withheld. Filter by instrument ID, with global context retained. Review priority and transmission channels are deterministic category heuristics, not NLP, impact estimates or predictive sentiment.
- Macro: latest available period and vintage by series, date cutoff on availability/publication/period, suppress same-vintage value conflicts; preceding period change only, never a consensus surprise. No imputed consensus. Age is measured from period end.
- Historical fundamental context uses existing dated-candidate financial metrics; historical price/technical evidence excluded due to unresolved availability and adjustment basis. Catalogue metadata is current reference, not point-in-time membership.
- D5 replay: latest price, cumulative and step movement, current drawdown, seven factors, market breadth across categorized exchange equity proxies, equal-weight sector comparisons (minimum 3 proxies), current portfolio concentration, spread stress flag from absolute latest EGX30 factor change >= 2%, synthetic news prefix. No actual flow, liquidity, sentiment or leverage estimate. No automatic buy/sell.
- Direction comparison: price relative to SMA3 versus generic cumulative factor return, with 0.05 percentage-point neutral band. Different horizons, descriptive only. Fund NAV proxies are not treated as stock technical signals. Gold fund comparator is theoretical gold USD return compounded with USD/EGP; ignores fund tracking, fees and local premium. Other unsupported models have no comparator.
- Historical context remains frozen at scenario anchor availability date; simulated news follows the replay clock. Actual dated news and real price tape are not synchronized. Current catalogue sectors may contain alias and membership limitations. Evaluation scenarios are visible in exported summaries and remain synthetic; do not treat the test set as sealed.
- No new market data acquired. Actual news and macro release timestamps/rights remain unresolved; no historical training approval.

## APIs (authenticated)
GET /intelligence, GET /intelligence/api/history?cutoff=YYYY-MM-DD&id=EGX:ADIB (id optional), GET /intelligence/api/replay?replay_id=<owned replay>&id=EGX:ADIB. Read-only. Reuses account ownership and server-side replay position.

## Verification
Run `python test_intelligence.py`, `python test.py`, `python test_fundamental.py`, `python test_technical.py`. 1,359 new checks plus 1,404 regression checks passed. HTML script syntax validated with Node. No browser interaction or native Windows deployment test in this phase. The CSV scenario summary has 216 snapshots (24 x 9), each labeled D5, with ADIB example and breadth. Coverage register covers 387 identifiers. No AI model training, no empirical calibration, no validated historical backtest. Future milestones: backtesting, OR optimization, complete historical replay, AI models and integration.
