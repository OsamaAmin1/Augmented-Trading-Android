"""Chronological educational technical indicators. No trading recommendations."""
import math, statistics as st, sqlite3, datetime
from pathlib import Path
P=Path(__file__).resolve().parent

def connect():
 c=sqlite3.connect(f'file:{P/"warehouse.sqlite"}?mode=ro',uri=True);c.row_factory=sqlite3.Row;return c

def mean(x):return sum(x)/len(x)
def ema(x,n):
 if len(x)<n:return None
 v=mean(x[:n]);a=2/(n+1)
 for p in x[n:]:v+=a*(p-v)
 return v

def wilder(x,n):
 if len(x)<n:return None
 v=mean(x[:n])
 for p in x[n:]:v=(v*(n-1)+p)/n
 return v

def rsi(x,n):
 d=[b-a for a,b in zip(x,x[1:])];g=wilder([max(v,0) for v in d],n);l=wilder([max(-v,0) for v in d],n)
 if g is None:return None
 return 50 if g==l==0 else 100 if l==0 else 100-100/(1+g/l)

def positive(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and x>0

def analyze(rows,mode):
 if mode not in ('observed_daily','observed_nav','synthetic_replay','synthetic_intraday','exercise'):raise ValueError('Unknown mode')
 if len(rows)>5000:raise ValueError('Series limit 5000')
 if any(not positive(r['close']) for r in rows):raise ValueError('Invalid price')
 if any(b['time']<=a['time'] for a,b in zip(rows,rows[1:])):raise ValueError('Non-increasing or duplicate observations')
 for r in rows:
  v=r.get('volume');o,h,l=(r.get(k) for k in ('open','high','low'))
  if v is not None and (not isinstance(v,(int,float)) or not math.isfinite(v) or v<0):raise ValueError('Invalid volume')
  if any(x is not None for x in (o,h,l)) and (not all(positive(x) for x in (o,h,l)) or not l<=min(o,r['close'])<=max(o,r['close'])<=h):raise ValueError('Invalid OHLC')
 out=[];xs=[];macds=[];trs=[];obv=0;weighted=0;volsum=0;nav=mode=='observed_nav'
 for i,r in enumerate(rows):
  p=r['close'];xs.append(p);m={};signals=[];patterns=[];prev=rows[i-1] if i else None
  m['interval_return']=p/xs[-2]-1 if i else None;m['drawdown']=1-p/max(xs)
  if not nav:
   for n in (3,5,20,50,200):m[f'sma{n}']=mean(xs[-n:]) if len(xs)>=n else None
   for n in (5,12,26):m[f'ema{n}']=ema(xs,n)
   for n in (3,14):m[f'rsi{n}']=rsi(xs,n)
   m['macd']=m['ema12']-m['ema26'] if m['ema26'] is not None else None
   if m['macd'] is not None:macds.append(m['macd'])
   m['macd_signal']=ema(macds,9);m['macd_hist']=m['macd']-m['macd_signal'] if m['macd_signal'] is not None else None
   s=m['sma20'];sd=st.pstdev(xs[-20:]) if s is not None else None
   m['bb_upper']=s+2*sd if s is not None else None;m['bb_lower']=s-2*sd if s is not None else None
   m['support5']=min(xs[-6:-1]) if i>=5 else None;m['resistance5']=max(xs[-6:-1]) if i>=5 else None
   if i>=5 and p>m['resistance5']:signals.append('close_above_prior_5_closes')
   if i>=5 and p<m['support5']:signals.append('close_below_prior_5_closes')
   if i and m['sma5'] is not None and out[-1]['metrics'].get('sma5') is not None:
    old=out[-1]['metrics'];a=old['sma3']-old['sma5'];b=m['sma3']-m['sma5']
    if a<=0<b:signals.append('sma3_cross_above_sma5')
    if a>=0>b:signals.append('sma3_cross_below_sma5')
   o,h,l=(r.get(k) for k in ('open','high','low'))
   if h is not None:
    tr=max(h-l,abs(h-prev['close']),abs(l-prev['close'])) if prev else h-l;trs.append(tr)
    m['atr14']=wilder(trs,14) if len(trs)==i+1 else None
    hi=[x.get('high') for x in rows[max(0,i-13):i+1]];lo=[x.get('low') for x in rows[max(0,i-13):i+1]]
    m['stoch14']=100*(p-min(lo))/(max(hi)-min(lo)) if len(hi)==14 and None not in hi+lo and max(hi)>min(lo) else None
    if h>l and abs(p-o)<=.1*(h-l):patterns.append('doji_10pct_range')
    if prev and prev.get('open') is not None:
     po,pc=prev['open'],prev['close']
     if pc<po and p>o and o<=pc and p>=po:patterns.append('bullish_body_engulfing')
     if pc>po and p<o and o>=pc and p<=po:patterns.append('bearish_body_engulfing')
   else:m['atr14']=None;m['stoch14']=None
   v=r.get('volume');pastvol=[q.get('volume') for q in rows[max(0,i-5):i]]
   m['volume_ratio5']=v/mean(pastvol) if v is not None and len(pastvol)==5 and None not in pastvol and mean(pastvol)>0 else None
   if v is not None and all(q.get('volume') is not None for q in rows[:i+1]):
    if prev:obv+=v*(1 if p>prev['close'] else -1 if p<prev['close'] else 0)
    m['obv']=obv
    if mode=='synthetic_intraday':weighted+=p*v;volsum+=v;m['synthetic_vwap']=weighted/volsum if volsum else None
   else:m['obv']=None
  out.append({**r,'metrics':m,'signals':signals,'patterns':patterns})
 return out

def catalogue(c):return [dict(r) for r in c.execute('select id,symbol,name,type,category from instrument_catalogue order by symbol,id')]

def observed(c,i,cutoff=None):
 if not c.execute('select 1 from instrument_catalogue where id=?',(i,)).fetchone():raise ValueError('Unknown instrument')
 if cutoff:cutoff=datetime.date.fromisoformat(cutoff).isoformat()
 groups={}
 for r in c.execute('select * from history_observation where instrument_id=? order by observation_date,observation_id',(i,)):
  if cutoff and r['observation_date']>cutoff:continue
  key=(r['dataset'],r['source_name'],r['currency'],r['price_basis'],r['date_basis']);groups.setdefault(key,[]).append(dict(r))
 result=[]
 for key,rr in groups.items():
  mode='observed_daily' if key[0]=='daily_ohlcv' else 'observed_nav'
  rows=[{'time':r['observation_date'],'close':r['close'] if mode=='observed_daily' else r['nav'],'open':r['open'],'high':r['high'],'low':r['low'],'volume':r['volume'],'source_id':r['observation_id'],'source_url':r['source_url'],'data_class':r['provenance']} for r in rr]
  try:series=analyze(rows,mode);error=None
  except ValueError as e:series=[];error=str(e)
  result.append({'mode':mode,'source':key[1],'series':series,'error':error,'training_approved':False,'verified_historical':False,'note':'Observation-date filter only; availability, basis and session continuity unverified. NAV intervals are irregular and not daily trading bars.'})
 return result

def anchors(c,i):return [dict(r) for r in c.execute('select anchor_id,anchor_date,count(*) points from recon_intraday_synthetic where instrument_id=? group by anchor_id,anchor_date order by anchor_date',(i,))]

def intraday(c,i,anchor,step=23):
 if type(step)!=int or not 0<=step<=23:raise ValueError('Step must be 0–23')
 rows=[{'time':int(r['step']),'close':r['synthetic_trade_price'],'volume':r['allocated_vendor_volume'],'bid':r['bid'],'ask':r['ask'],'data_class':'D5'} for r in c.execute('select * from recon_intraday_synthetic where instrument_id=? and anchor_id=? and step<=? order by step',(i,anchor,step))]
 if not rows:raise ValueError('Unknown anchor')
 return {'mode':'synthetic_intraday','series':analyze(rows,'synthetic_intraday'),'training_approved':False,'verified_historical':False,'note':'D5 retrospective exercise conditioned on full-day OHLCV; not a historical intraday backtest.'}

def replay(values):
 return {'mode':'synthetic_replay','series':analyze([{'time':i,'close':v,'data_class':'D5'} for i,v in enumerate(values)],'synthetic_replay'),'training_approved':False,'verified_historical':False,'note':'D5 replay prefix only; no OHLC or volume supplied by scenario.'}
