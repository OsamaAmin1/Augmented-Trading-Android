"""Offline educational replay; no broker, network, or actual investment advice."""
import sqlite3, threading, secrets, math, datetime, json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
BASE=Path(__file__).resolve().parent
D=Decimal

def money(x): return int((D(str(x))*100).quantize(D('1'),rounding=ROUND_HALF_UP))
def fee(v,bps): return int((D(v)*D(bps)/10000).quantize(D('1'),rounding=ROUND_HALF_UP))
def date(s): return datetime.date.fromisoformat(s).isoformat()
class World:
 def __init__(self,db=BASE/'warehouse.sqlite'):
  self.db=sqlite3.connect(f'file:{Path(db).resolve()}?mode=ro',uri=True,check_same_thread=False); self.db.row_factory=sqlite3.Row
  self.lock=threading.RLock(); self.sessions={}
  self.catalog={r['id']:r for r in self.rows('select id,symbol,name,type,category,icon from instrument_catalogue')}
  self.scenarios={r['scenario_id']:r for r in self.rows('select s.scenario_id,s.anchor_event,s.variant,p.family,p.split,e.available_from,e.summary from global_scenario s join ml_scenario_partitions p using(scenario_id) join global_event e on e.event_id=s.anchor_event')}
  self.paths={};self.models={};self.factors={}
  for r in self.rows('select scenario_id,instrument_id,step,normalized_value,model from recon_synthetic_universe order by step'):
   self.paths.setdefault(r['scenario_id'],{}).setdefault(r['instrument_id'],[]).append(money(r['normalized_value']));self.models[r['instrument_id']]=r['model']
  for r in self.rows('select scenario_id,asset,step,normalized_value from global_synthetic_path order by step'):
   self.factors.setdefault(r['scenario_id'],{}).setdefault(r['asset'],[]).append(r['normalized_value'])
 def rows(self,q,args=()):return [dict(r) for r in self.db.execute(q,args)]
 def kind(self,i):
  t=self.catalog[i]['type'];return 'fund' if t=='mutual_fund_certificate' else 'exchange' if t in ('provider_stock','common_stock','preferred_stock','ETF') else 'reference'
 def meta(self):return {'scenarios':list(self.scenarios.values()),'instruments':[{**self.catalog[i],'model':m,'order_type':self.kind(i)} for i,m in sorted(self.models.items())],'assumptions':{'exchange_fee_bps':15,'fund_fee_bps':20,'normal_half_spread_bps':10,'stress_half_spread_bps':40,'initial_cash':100000,'currency':'virtual EGP','margin':'disabled','execution':'next simulation step; market only; no actual liquidity or settlement'}}
 def evidence(self,cutoff):
  cutoff=date(cutoff)
  news=self.rows('select event_id,available_from,published_date,category,summary,source_url,data_class from global_event where available_from<=? order by available_from desc',(cutoff,))
  local=self.rows('select event_id,available_from,publication_date,event_type,summary,symbol,source_url,provenance from disclosure_event where available_from<=? order by available_from desc',(cutoff,))
  macro=self.rows('''select m.series_id,m.period_end,m.value,m.available_from,m.vintage,m.quality,s.unit from macro_observation m join macro_series s using(series_id) where m.available_from<=? order by m.period_end desc,m.available_from desc,m.observation_id desc''',(cutoff,))
  latest={};
  for r in macro:latest.setdefault(r['series_id'],r)
  return {'cutoff':cutoff,'global':news,'local':local,'macro':list(latest.values()),'mode':'candidate historical context; date-only conservative availability; no verified historical execution'}
 def samples(self,i):
  if i not in self.catalog:raise ValueError('Unknown instrument')
  return {'id':i,'mode':'retrospective source samples; availability and price basis unverified; not executable','rows':self.rows('select observation_date,dataset,close,nav,volume,provenance,source_url,quality_flags from history_observation where instrument_id=? order by observation_date',(i,))}
 def start(self,scenario,capital=100000,expose=False):
  if scenario not in self.scenarios:raise ValueError('Unknown scenario')
  if self.scenarios[scenario]['split']!='train' and expose is not True:raise ValueError('Explicit evaluation scenario exposure required')
  if isinstance(capital,bool) or not isinstance(capital,(int,float)) or not math.isfinite(capital) or not 100<=capital<=100000000:raise ValueError('Capital must be 100–100,000,000')
  token=secrets.token_urlsafe(24);c=money(capital);self.sessions[token]={'scenario':scenario,'step':0,'cash':c,'initial':c,'holdings':{},'pending':None,'journal':[],'equity':[c]};return {'token':token,**self.state(token)}
 def get(self,t):
  if t not in self.sessions:raise ValueError('Unknown replay session')
  return self.sessions[t]
 def mark(self,s):return s['cash']+sum(q*self.paths[s['scenario']][i][s['step']] for i,q in s['holdings'].items())
 def feed(self,k,step):
  out=[{'step':0,'headline':'Scenario opens; market proxies normalized to 100','data_class':'D5'}]
  for t in range(1,step+1):
   changes={a:(v[t]/v[t-1]-1)*100 for a,v in self.factors[k].items()}
   for a,r in sorted(changes.items(),key=lambda x:-abs(x[1]))[:2]:
    out.append({'step':t,'headline':f'{a} proxy {"rises" if r>=0 else "falls"} {abs(r):.2f}% this step','data_class':'D5'})
   if abs(changes['EGX30'])>=2:out.append({'step':t,'headline':'Simulated EGX spread stress threshold triggered','data_class':'D5'})
  return out
 def state(self,t):
  s=self.get(t);k=s['scenario'];step=s['step'];p=self.paths[k]; info=self.scenarios[k];val=self.mark(s)
  return {'scenario':k,'step':step,'last_step':len(next(iter(p.values())))-1,'cash':s['cash']/100,'initial':s['initial']/100,'equity':val/100,'return_pct':(val/s['initial']-1)*100,'drawdown_pct':(1-val/max(s['equity']))*100,'max_drawdown_pct':max(1-v/max(s['equity'][:j+1]) for j,v in enumerate(s['equity']))*100,'equity_path':[v/100 for v in s['equity']],'holdings':[{'id':i,'quantity':q,'mark':p[i][step]/100,'value':q*p[i][step]/100} for i,q in s['holdings'].items() if q],'pending':s['pending'],'journal':s['journal'][:],'quotes':{i:{'price':v[step]/100,'change_pct':(v[step]/v[0]-1)*100} for i,v in p.items()},'factors':{i:v[:step+1] for i,v in self.factors[k].items()},'feed':self.feed(k,step),'context_cutoff':info['available_from'],'data_class':'D5','benchmark_return_pct':(self.factors[k]['EGX30'][step]/self.factors[k]['EGX30'][0]-1)*100}
 def chart(self,t,i):
  s=self.get(t)
  if i not in self.paths[s['scenario']]:raise ValueError('Unknown instrument')
  return {'id':i,'values':[x/100 for x in self.paths[s['scenario']][i][:s['step']+1]],'data_class':'D5'}
 def order(self,t,i,side,qty):
  s=self.get(t)
  if i not in self.paths[s['scenario']] or self.kind(i)=='reference':raise ValueError('Instrument not orderable')
  if side not in ('buy','sell') or type(qty)!=int or not 1<=qty<=1000000:raise ValueError('Invalid order')
  if s['pending'] or s['step']>=len(self.paths[s['scenario']][i])-1:raise ValueError('Pending order exists or replay ended')
  if side=='sell' and qty>s['holdings'].get(i,0):raise ValueError('Insufficient units; no shorting')
  s['pending']={'id':i,'side':side,'quantity':qty,'submitted_step':s['step']};return self.state(t)
 def cancel(self,t):self.get(t)['pending']=None;return self.state(t)
 def advance(self,t):
  s=self.get(t);k=s['scenario'];p=self.paths[k]
  if s['step']>=len(next(iter(p.values())))-1:raise ValueError('Replay completed')
  s['step']+=1;step=s['step'];o=s['pending'];s['pending']=None
  if o:
   i=o['id'];q=o['quantity'];side=o['side'];mid=p[i][step];kind=self.kind(i); stress=abs(self.factors[k]['EGX30'][step]/self.factors[k]['EGX30'][step-1]-1)>=.02
   spread=0 if kind=='fund' else (40 if stress else 10); delta=max(1,fee(mid,spread)) if spread else 0; price=mid+delta if side=='buy' else max(1,mid-delta); gross=q*price;cost=fee(gross,20 if kind=='fund' else 15)
   fill=(gross+cost<=s['cash']) if side=='buy' else q<=s['holdings'].get(i,0)
   if fill:
    s['cash']+=(-gross-cost if side=='buy' else gross-cost);s['holdings'][i]=s['holdings'].get(i,0)+(q if side=='buy' else -q)
   s['journal'].append({**o,'execution_step':step,'status':'filled' if fill else 'rejected','price':price/100 if fill else None,'fee':cost/100 if fill else 0,'reason':'' if fill else 'Insufficient cash or units at next quote','pricing':'synthetic NAV proxy' if kind=='fund' else 'synthetic spread quote'})
  s['equity'].append(self.mark(s));return self.state(t)
 def leverage(self,capital,multiple,shock,maintenance=25):
  if not all(isinstance(x,(int,float)) and math.isfinite(x) for x in (capital,multiple,shock,maintenance)) or not (capital>0 and 1<=multiple<=4 and -100<=shock<=100 and 0<=maintenance<=100):raise ValueError('Invalid stress parameters')
  exposure=capital*multiple;assets=exposure*(1+shock/100);equity=assets-(exposure-capital);return {'exposure':exposure,'ending_equity':equity,'return_pct':(equity/capital-1)*100,'margin_breach':multiple>1 and (assets==0 or equity/assets*100<maintenance),'data_class':'D5','note':'static stress only, no actual margin orders or dynamic liquidation'}
