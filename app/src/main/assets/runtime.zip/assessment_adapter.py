"""Local-only prototype service. Uses frozen V4.1 functions, not reference labels for decisions."""
from pathlib import Path
import importlib.util,sys,os,secrets,math,threading,time,json
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
import uvicorn
O=Path(__file__).resolve().parent; R=O/'runtime'; os.environ['PROJECT_ROOT']=str(R); os.environ['REFERENCE_ROOT']=str(R)
s=importlib.util.spec_from_file_location('recovery',R/'progressive_engine_v41/recovery.py'); rec=importlib.util.module_from_spec(s);sys.modules[s.name]=rec;s.loader.exec_module(rec);V=rec.V
app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)
sessions={};lock=threading.RLock(); TTL=3600
# Allowed input categories are extracted from the synthetic development schema; not inferred from an individual.
ENUMS={k:sorted(set(str(x) for x in V.P[k].unique())) for k in V.FIELDS if k not in rec.NUM+rec.BOOL}
ENUMS.update({k:sorted(v) for k,v in rec.ENUM.items()});
class Need(Exception):
 def __init__(self,question):self.question=question

def jsonout(x,status=200):return JSONResponse(rec.plain(x),status_code=status)

def error(m,status=400):return jsonout({'error':m},status)

def validate(data,fields):
 if not isinstance(data,dict) or set(data)!=set(fields):raise ValueError('Supply exactly the required fields.')
 for k in fields:
  v=data[k]
  if k in rec.NUM and (not rec.real(v) or not 0<=v<=1e12):raise ValueError('Invalid number: '+k)
  if k in rec.BOOL and type(v)!=bool:raise ValueError('Invalid boolean: '+k)
  if k in ENUMS and v not in ENUMS[k]:raise ValueError('Invalid category: '+k)

def question(q,k):return {'id':q.id+('' if k==0 else '-C'+str(k)),'prompt':q.prompt if hasattr(q,'prompt') else q.scenario,'a':q.a,'b':q.b,'kind':'binary'}

def compute(s):
 pos=0
 def consume(q,transform):
  nonlocal pos
  if pos==len(s['answers']):raise Need(q)
  record=s['answers'][pos];pos+=1
  if record['id']!=q['id']:raise ValueError('Transcript mismatch')
  return transform(record['answer'])
 def ask(q,k):return consume(question(q,k),lambda x:int(x=='A'))
 def atom(typ,f,ys):
  q={'id':f'SUP-{pos}','prompt':f'Additional evidence ({typ}): {f}'+(f' in {sorted(ys,key=str)}' if ys is not None else ''),'a':'Yes, condition applies','b':'No, condition does not apply','kind':'supplemental'}
  return consume(q,lambda x:x=='A')
 try:i=V.discover(s['first'],ask,atom,False)
 except Need as n:return {'stage':'question','question':n.question,'answered':pos}
 if pos!=len(s['answers']):raise ValueError('Unexpected transcript entries')
 s['discovery']=i
 return {'stage':'structured_intake','candidate':{k:i['z'][k] for k in ['foundation','pathway','components','confirmed','reason'] if k in i['z']},'questions':i['questions'],'training':i['training'],'pending_conflicts':i['pending']}

def get_session(sid):
 s=sessions.get(sid)
 if not s or time.monotonic()-s['created']>TTL:raise ValueError('Session missing or expired. Start again.')
 return s
@app.middleware('http')
async def restrict(request:Request,call_next):
 if request.headers.get('host','').split(':')[0] not in ('localhost','127.0.0.1'):return error('Localhost only',403)
 if request.method=='POST':
  if request.headers.get('content-type','').split(';')[0]!='application/json':return error('JSON required',415)
  if request.headers.get('origin') not in (None,str(request.base_url).rstrip('/')):return error('Origin rejected',403)
  if len(await request.body())>256*1024:return error('Request too large',413)
 r=await call_next(request);r.headers['Cache-Control']='no-store';r.headers['X-Content-Type-Options']='nosniff';return r
@app.get('/')
def home():return FileResponse(O/'web/index.html')
@app.get('/api/schema')
def schema():return jsonout({'initial':V.FIRST,'additional':V.EXTRA,'goals':V.GF,'numeric':rec.NUM,'boolean':rec.BOOL,'enums':ENUMS,'scope':'Local synthetic engineering calculator; no trading authorization.'})
@app.get('/api/example/{pid}')
def example(pid:str):
 if pid not in ['P00052','P02723','P00311','P00026']:return error('Unknown example',404)
 p=V.P.loc[pid];return jsonout({'first':{k:p[k] for k in V.FIRST},'full':{k:p[k] for k in V.FIELDS},'goals':V.integ.goal.goals(p)})
@app.post('/api/start')
def start(x:dict):
 try:
  validate(x,V.FIRST)
  if V.initial_input(x)[0] is None or x['monthly_expenses']+x['monthly_debt_payment']<=0:raise ValueError('Invalid financial intake')
  with lock:
   for k in list(sessions):
    if time.monotonic()-sessions[k]['created']>TTL:del sessions[k]
   if len(sessions)>=100:return error('Session limit reached',429)
   sid=secrets.token_urlsafe(32);s={'first':x,'answers':[],'created':time.monotonic()};out=compute(s);sessions[sid]=s;return jsonout({'session':sid,**out})
 except (ValueError,TypeError,KeyError,AttributeError) as e:return error(str(e))
@app.post('/api/answer')
def answer(x:dict):
 try:
  with lock:
   s=get_session(x['session']);pending=compute(s)
   if pending['stage']!='question' or x['id']!=pending['question']['id'] or x['answer'] not in ('A','B'):raise ValueError('Invalid or stale answer')
   s['answers'].append({'id':x['id'],'answer':x['answer']})
   try:return jsonout(compute(s))
   except Exception:s['answers'].pop();raise
 except (ValueError,TypeError,KeyError,AttributeError) as e:return error(str(e))
@app.post('/api/plan')
def plan(x:dict):
 try:
  with lock:
   s=get_session(x['session']);i=s.get('discovery')
   if not i:raise ValueError('Discovery incomplete')
   full=x['full'];gs=x['goals'];validate(full,V.FIELDS)
   out,g,sc,st,review=rec.finalize(i,s['first'],full,gs,x['session'],x.get('approval'))
   if out is not None and (out['live_authorized'] or out['approved_allocation']!=0):raise ValueError('Safety check failed')
   return jsonout({'status':st,'review':review,'plan':out,'goals':g,'scenarios':sc,'live_authorized':False})
 except (ValueError,TypeError,KeyError,AttributeError,OverflowError) as e:return error(str(e))
@app.get('/{name}')
def assets(name:str):
 p=O/'web'/name
 if p.is_file() and p.parent==O/'web':return FileResponse(p)
 return error('Not found',404)
if __name__=='__main__':uvicorn.run(app,host='127.0.0.1',port=int(os.getenv('PORT','8765'))) 
