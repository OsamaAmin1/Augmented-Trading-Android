"""Persistent education evidence. Never modifies eligibility or assessment rules."""
import json
from pathlib import Path
P=Path(__file__).resolve().parent
DATA=json.loads((P/'runtime/trading_academy_v1/academy_data.json').read_text())
MODULES=DATA['modules']; STRATEGIES=DATA['strategies']

def progress(state):
    return state.get('academy',{}).get('modules',{})

def catalogue(state):
    p=progress(state)
    return {'modules':[{'id':m['id'],'title':m['title'],'domain':m['domain'],'prerequisites':m['prerequisites'],'estimated_minutes':m['estimated_minutes'],'passed':p.get(i,{}).get('passed',False),'attempts':p.get(i,{}).get('attempts',0),'unlocked':all(p.get(j,{}).get('passed',False) for j in m['prerequisites'])} for i,m in MODULES.items()], 'strategies':STRATEGIES,'passed_count':sum(bool(p.get(i,{}).get('passed')) for i in MODULES),'total':len(MODULES),'live_authorized':False,'approved_allocation':0}

def lesson(state,i):
    if i not in MODULES:raise ValueError('Unknown lesson')
    m=MODULES[i];p=progress(state)
    if not all(p.get(j,{}).get('passed',False) for j in m['prerequisites']):raise ValueError('Complete prerequisites first')
    return {**{k:v for k,v in m.items() if k!='quiz'},'quiz':[{k:q[k] for k in ('id','question','choices')} for q in m['quiz']]}

def submit(state,i,answers,now):
    m=lesson(state,i);original=MODULES[i]['quiz']
    if not isinstance(answers,dict) or set(answers)!={q['id'] for q in original}:raise ValueError('Answer each question exactly once')
    for q in original:
        v=answers[q['id']]
        if type(v)!=int or not 0<=v<len(q['choices']):raise ValueError('Invalid quiz answer')
    results=[{'id':q['id'],'correct':answers[q['id']]==q['correct'],'feedback':q['feedback']} for q in original]
    score=sum(q['correct'] for q in results);passed=score==len(original)
    p=state.setdefault('academy',{}).setdefault('modules',{});old=p.get(i,{})
    p[i]={'attempts':old.get('attempts',0)+1,'best_score':max(old.get('best_score',0),score),'total':len(original),'passed':old.get('passed',False) or passed,'last_score':score,'last_attempt':now,'first_pass':old.get('first_pass') or (now if passed else None)}
    return {'score':score,'total':len(original),'passed_this_attempt':passed,'progress':p[i],'results':results,'live_authorized':False,'approved_allocation':0}

def evidence(state):
    """Counts of persisted simulated actions, not personality or suitability inference."""
    replays=[]
    for i,z in state.get('replays',{}).items():
        s=z['state'];j=s['journal'];f=[x for x in j if x['status']=='filled'];n=s['step'];eq=s['equity'];peak=max(eq)
        replays.append({'id':i,'scenario':s['scenario'],'step':n,'filled_buys':sum(x['side']=='buy' for x in f),'filled_sells':sum(x['side']=='sell' for x in f),'rejected':sum(x['status']=='rejected' for x in j),'current_holdings':sum(q>0 for q in s['holdings'].values()),'return_pct':100*(eq[-1]/s['initial']-1),'current_drawdown_pct':100*(1-eq[-1]/peak),'data_class':'D5'})
    return {'education':catalogue(state)['passed_count'],'education_total':len(MODULES),'assessment_versions':len(state['assessments']),'replays':replays,'behavioral_inference':'not performed','live_authorized':False,'approved_allocation':0}
