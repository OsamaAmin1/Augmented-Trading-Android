import os,tempfile,csv,ast,hashlib,json
from pathlib import Path
from fastapi.testclient import TestClient
from store import Store
P=Path(__file__).parent;tmp=tempfile.TemporaryDirectory();os.environ['INVESTOR_DB']=str(Path(tmp.name)/'test.sqlite')
import server as s
V=s.V;checks=[]
def ck(n,v):checks.append({'test':n,'passed':bool(v)});assert v,n
A=TestClient(s.app,base_url='http://localhost');B=TestClient(s.app,base_url='http://localhost');PW='Test-only-long-secret-752';post=lambda c,p,x:c.post(p,json=x)
ck('anonymous profile blocked',A.get('/api/profile').status_code==401);ck('anonymous replay blocked',A.get('/market/api/meta').status_code==401)
for c,alias in [(A,'fiction_a'),(B,'fiction_b')]:
 ck(alias+' registration',post(c,'/account/register',{'alias':alias,'password':PW}).status_code==200);ck(alias+' login',post(c,'/account/login',{'alias':alias,'password':PW}).status_code==200)
ck('duplicate registration rejected',post(A,'/account/register',{'alias':'fiction_a','password':PW}).status_code==400);ck('wrong password rejected',post(B,'/account/login',{'alias':'fiction_a','password':'wrong-long-password'}).status_code==400)
ck('cross origin denied',A.post('/account/logout',json={},headers={'origin':'https://evil.invalid'}).status_code==403);ck('remote host denied',A.get('/api/profile',headers={'host':'evil.invalid'}).status_code==403)
ck('no prefilled real profile',A.get('/api/profile').json()['assessments']==[]);ck('no example route',A.get('/api/example/P00052').status_code==404)
def run(pid,restart=False):
 p=V.P.loc[pid];full=s.rec.plain({k:p[k] for k in V.FIELDS});first={k:full[k] for k in V.FIRST};gs=s.rec.plain(V.integ.goal.goals(p));truth=V.rel.truth(V.materialize(full,pid));atoms=V.opt.atoms(V.materialize(full,pid));r=post(A,'/api/start',first);ck(pid+' start',r.status_code==200);o=r.json();sid=o['session'];n=0
 ck(pid+' cross-account draft blocked',post(B,'/api/answer',{'session':sid,'id':'bad','answer':'A'}).status_code==400)
 while o['stage']=='question':
  q=o['question'];
  if q['kind']=='binary':qq=V.QM[q['id']];ans='A' if truth[qq.field] in qq.yes else 'B'
  else:
   text=q['prompt'];t=text.split(': ',1)[1]
   if text.startswith('Additional evidence (atom)'):ans='A' if atoms[t] else 'B'
   else:f,ys=t.split(' in ',1);ans='A' if truth[f] in ast.literal_eval(ys) else 'B'
  r=post(A,'/api/answer',{'session':sid,'id':q['id'],'answer':ans});ck(pid+f' question {n+1}',r.status_code==200);o=r.json();n+=1
  if restart and n==1:
   s.store.db.close();s.store=Store(os.environ['INVESTOR_DB']);ck('restart invalidates login',A.get('/api/profile').status_code==401);ck('restart login',post(A,'/account/login',{'alias':'fiction_a','password':PW}).status_code==200);ck('second account relogin',post(B,'/account/login',{'alias':'fiction_b','password':PW}).status_code==200);z=A.get('/api/resume').json();ck('draft persisted after restart',z['session']==sid and z['stage']==o['stage'] and z.get('question')==o.get('question'))
  assert n<60
 payload={'session':sid,'full':full,'goals':gs};r=post(A,'/api/plan',payload);ck(pid+' plan call',r.status_code==200);z=r.json()
 if z['review']['status']=='review_required':
  rv=z['review'];ap={'token':rv['token'],'accept_proposal':True,'accept_structured_profile':True,'confirmed_discrepancies':[x['id'] for x in rv['discrepancies']]};ck(pid+' unapproved plan blocked',z['plan'] is None);ck(pid+' stale approval blocked',post(A,'/api/plan',{**payload,'approval':{**ap,'token':'bad'}}).json()['plan'] is None);z=post(A,'/api/plan',{**payload,'approval':ap}).json()
 ck(pid+' completed',z['plan'] is not None);ck(pid+' no live allocation',not z['plan']['live_authorized'] and z['plan']['approved_allocation']==0);ref=V.REF.loc[pid];ck(pid+' reference parity',z['plan']['foundation']==ref.foundation and abs(z['plan']['market_alloc']-ref.market_alloc)<.05);ck(pid+' duplicate finalization blocked',post(A,'/api/plan',payload).status_code==400);ck(pid+' account isolation',B.get('/api/assessment/'+sid).status_code==400);return sid
id1=run('P00052',True);id2=run('P02723');hist=A.get('/api/profile').json()['assessments'];ck('versioned plans',len(hist)==2 and not hist[0]['current'] and hist[1]['current']);ck('detail available',A.get('/api/assessment/'+id2).status_code==200)
scenario=next(k for k,v in s.world.scenarios.items() if v['split']=='train');r=post(A,'/market/api/start',{'scenario':scenario,'capital':100000});ck('replay created',r.status_code==200);w=r.json();t=w['token'];ck('initial virtual cash',w['cash']==100000);ck('cross-user replay inaccessible',B.get('/market/api/state',params={'token':t}).status_code==400);ck('cross-user mutation blocked',post(B,'/market/api/advance',{'token':t,'replay_revision':0}).status_code==400)
r=post(A,'/market/api/order',{'token':t,'replay_revision':0,'id':'EGX:ADIB','side':'buy','quantity':100});ck('queued buy',r.status_code==200 and r.json()['pending']['quantity']==100);ck('stale write rejected',post(A,'/market/api/advance',{'token':t,'replay_revision':0}).status_code==400)
s.store.db.close();s.store=Store(os.environ['INVESTOR_DB']);ck('relogin after replay restart',post(A,'/account/login',{'alias':'fiction_a','password':PW}).status_code==200);r=A.get('/market/api/state',params={'token':t});ck('pending trade persisted',r.json()['pending']['quantity']==100 and r.json()['replay_revision']==1);r=post(A,'/market/api/advance',{'token':t,'replay_revision':1});w=r.json();ck('next-step order filled',w['journal'][0]['status']=='filled' and w['holdings'][0]['quantity']==100 and w['step']==1);ck('cash ledger',abs(w['cash']-(100000-100*w['journal'][0]['price']-w['journal'][0]['fee']))<.001);ck('saved replay summary',A.get('/api/profile').json()['replays'][0]['step']==1)
ck('private export',len(A.get('/api/export').json()['profile']['assessments'])==2);data=Path(os.environ['INVESTOR_DB']).read_bytes();ck('financial payload not plaintext',b'monthly_income' not in data and b'EGX:ADIB' not in data and PW.encode() not in data);ck('warehouse unchanged',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip());ck('delete wrong password denied',post(A,'/account/delete',{'password':'wrong-long-password'}).status_code==400);ck('delete succeeds',post(A,'/account/delete',{'password':PW}).status_code==200);ck('deleted session revoked',A.get('/api/profile').status_code==401);ck('deleted login denied',post(A,'/account/login',{'alias':'fiction_a','password':PW}).status_code==400)
with (P/'checks.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=['test','passed']);w.writeheader();w.writerows(checks)
print('PASS',len(checks))
