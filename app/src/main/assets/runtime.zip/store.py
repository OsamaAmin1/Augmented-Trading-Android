"""Local encrypted investor store. One server process, no broker connectivity."""
import sqlite3, secrets, hashlib, json, time, threading, hmac, re
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from datetime import datetime, timezone

def now():return datetime.now(timezone.utc).isoformat()
def encode(x):return json.dumps(x,allow_nan=False,sort_keys=True,separators=(',',':')).encode()
def derive(password,salt):
 if not isinstance(password,str) or not 12<=len(password)<=256:raise ValueError('Password must contain 12–256 characters')
 k=hashlib.scrypt(password.encode(),salt=salt,n=2**15,r=8,p=1,maxmem=64*1024*1024,dklen=64);return k[:32],k[32:]
class Store:
 def __init__(self,path):
  self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(self.path,check_same_thread=False);self.db.execute('PRAGMA foreign_keys=ON');self.db.execute('PRAGMA secure_delete=ON');self.lock=threading.RLock();self.sessions={};self.failures={}
  self.db.execute('CREATE TABLE IF NOT EXISTS account (id TEXT PRIMARY KEY,alias TEXT UNIQUE NOT NULL,salt BLOB NOT NULL,verifier BLOB NOT NULL,nonce BLOB NOT NULL,cipher BLOB NOT NULL,revision INTEGER NOT NULL)');self.db.commit()
  try:self.path.chmod(0o600)
  except OSError:pass
 def seal(self,uid,key,rev,data):
  nonce=secrets.token_bytes(12);return nonce,AESGCM(key).encrypt(nonce,encode(data),f'{uid}:{rev}'.encode())
 def register(self,alias,password):
  if not isinstance(alias,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{3,40}',alias):raise ValueError('Alias: 3–40 letters, digits, underscore or hyphen')
  alias=alias.lower();uid=secrets.token_hex(16);salt=secrets.token_bytes(16);key,v=derive(password,salt);state={'schema':1,'created':now(),'draft':None,'assessments':[],'replays':{},'events':[]};nonce,cipher=self.seal(uid,key,0,state)
  try:
   with self.db:self.db.execute('INSERT INTO account VALUES(?,?,?,?,?,?,?)',(uid,alias,salt,v,nonce,cipher,0))
  except sqlite3.IntegrityError:raise ValueError('Alias unavailable')
 def login(self,alias,password):
  if not isinstance(alias,str):raise ValueError('Invalid credentials')
  alias=alias.lower();t=time.monotonic();attempts=[x for x in self.failures.get(alias,[]) if t-x<300]
  if len(attempts)>=5:raise ValueError('Too many attempts; retry later')
  r=self.db.execute('SELECT id,salt,verifier FROM account WHERE alias=?',(alias,)).fetchone();key,v=derive(password,r[1] if r else b'\0'*16)
  if not r or not hmac.compare_digest(v,r[2]):self.failures[alias]=attempts+[t];raise ValueError('Invalid credentials')
  self.failures.pop(alias,None);token=secrets.token_urlsafe(32);self.sessions[token]=(r[0],key,t+3600);return token
 def auth(self,token):
  s=self.sessions.get(token)
  if not s or s[2]<time.monotonic():self.sessions.pop(token,None);raise PermissionError('Sign in required')
  return s[:2]
 def read(self,token):
  uid,key=self.auth(token);r=self.db.execute('SELECT nonce,cipher,revision FROM account WHERE id=?',(uid,)).fetchone()
  if not r:raise PermissionError('Account deleted')
  return json.loads(AESGCM(key).decrypt(r[0],r[1],f'{uid}:{r[2]}'.encode())),r[2]
 def write(self,token,data,rev):
  uid,key=self.auth(token);nonce,cipher=self.seal(uid,key,rev+1,data)
  with self.db:
   n=self.db.execute('UPDATE account SET nonce=?,cipher=?,revision=? WHERE id=? AND revision=?',(nonce,cipher,rev+1,uid,rev)).rowcount
   if n!=1:raise ValueError('Stale revision; reload')
  return rev+1
 def logout(self,token):self.sessions.pop(token,None)
 def delete(self,token,password):
  uid,key=self.auth(token);r=self.db.execute('SELECT salt,verifier FROM account WHERE id=?',(uid,)).fetchone();_,v=derive(password,r[0])
  if not hmac.compare_digest(v,r[1]):raise ValueError('Invalid credentials')
  with self.db:self.db.execute('DELETE FROM account WHERE id=?',(uid,))
  for t,s in list(self.sessions.items()):
   if s[0]==uid:del self.sessions[t]
