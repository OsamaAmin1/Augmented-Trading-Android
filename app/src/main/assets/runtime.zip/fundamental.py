"""Read-only educational analysis. No live orders, investment ratings or training approvals."""
from pathlib import Path
import sqlite3, math, datetime as dt, collections
P=Path(__file__).resolve().parent
DB=P/'warehouse.sqlite'

def connect(db=DB):
 c=sqlite3.connect(Path(db).resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;return c

def date(s):
 if not isinstance(s,str) or dt.date.fromisoformat(s).isoformat()!=s:raise ValueError('Use YYYY-MM-DD')
 return s

def finite(x):
 if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x):raise ValueError('Finite number required')
 return float(x)

def rows(c,sql,args=()):return [dict(r) for r in c.execute(sql,args)]

def select_vintage(records,cutoff=None):
 groups=collections.defaultdict(list)
 if cutoff:date(cutoff)
 for r in records:
  if cutoff and (not r['available_from'] or r['available_from']>cutoff or r['period_end']>cutoff):continue
  groups[(r['instrument_id'],r['scope'],r['accounting_basis'],r['period_start'],r['period_end'],r['metric'])].append(r)
 picked=[];conflicts=[]
 for k,rr in groups.items():
  latest=max(r['available_from'] or '' for r in rr); candidates=[r for r in rr if (r['available_from'] or '')==latest]
  if len({(r['normalized_value'],r['normalized_unit']) for r in candidates})!=1:conflicts.append({'key':k,'ids':[r['observation_id'] for r in candidates]});continue
  picked.append(sorted(candidates,key=lambda r:r['observation_id'])[0])
 return picked,conflicts

# All derived metrics require compatible units, basis, period and scope.
RATIOS=[('equity_assets','total_equity','total_assets',100,'percent'),('liabilities_assets','total_liabilities','total_assets',100,'percent'),('profit_ending_assets','net_profit','total_assets',100,'percent'),('profit_ending_equity','net_profit','total_equity',100,'percent'),('loans_deposits','customer_loans_net','customer_deposits',100,'percent'),('net_profit_margin','net_profit_as_disclosed','revenue',100,'percent'),('ebitda_margin','ebitda','revenue',100,'percent'),('cash_capex_revenue','cash_capex','revenue',100,'percent'),('fcff_margin','fcff_reported','revenue',100,'percent'),('operating_cash_profit','operating_cash_flow','net_profit',1,'multiple'),('effective_tax_rate','tax_expense','profit_before_tax',100,'percent')]
BANK_ONLY={'loans_deposits','profit_ending_assets','profit_ending_equity'}
NONBANK_ONLY={'net_profit_margin','ebitda_margin','cash_capex_revenue','fcff_margin','operating_cash_profit'}
def metrics(records,category):
 groups=collections.defaultdict(dict);out=[]
 for r in records:groups[(r['instrument_id'],r['scope'],r['accounting_basis'],r['period_start'],r['period_end'])][r['metric']]=r
 def emit(key,name,v,unit,inputs,method):
  av=[r['available_from'] for r in inputs];out.append(dict(zip(('instrument_id','scope','accounting_basis','period_start','period_end'),key),metric=name,value=v,unit=unit,available_from=max(av) if all(av) else '',input_ids='|'.join(r['observation_id'] for r in inputs),method=method,provenance='D2',training_approved=0))
 for k,m in sorted(groups.items()):
  for name,a,b,scale,unit in RATIOS:
   if (category=='Banks' and name in NONBANK_ONLY) or (category!='Banks' and name in BANK_ONLY):continue
   if a not in m or b not in m:continue
   x,y=m[a],m[b]
   if x['normalized_unit']!=y['normalized_unit'] or y['normalized_value']<=0:continue
   # Tax expense sign varies across sources: magnitude only.
   num=abs(x['normalized_value']) if name=='effective_tax_rate' else x['normalized_value']
   emit(k,name,num/y['normalized_value']*scale,unit,[x,y],f'{a} / {b}; ending-balance ratios are not average-balance ROA/ROE')
  if all(x in m for x in ('total_assets','total_liabilities','total_equity')) and len({m[x]['normalized_unit'] for x in ('total_assets','total_liabilities','total_equity')})==1:
   a,l,e=[m[x] for x in ('total_assets','total_liabilities','total_equity')];emit(k,'balance_sheet_residual',a['normalized_value']-l['normalized_value']-e['normalized_value'],a['normalized_unit'],[a,l,e],'assets - liabilities - equity')
  # same fiscal dates one year earlier, not annualizing YTD
  def prior(d):
   v=dt.date.fromisoformat(d)
   try:return v.replace(year=v.year-1).isoformat()
   except ValueError:return v.replace(year=v.year-1,day=28).isoformat()
  prev=groups.get((*k[:3],prior(k[3]),prior(k[4])),{})
  for field in ('net_profit','net_profit_as_disclosed','net_profit_highlights','total_assets','total_equity','customer_deposits','revenue','net_operating_income','assets_highlights','deposits_highlights','fcff_reported'):
   if field in m and field in prev:
    x,y=m[field],prev[field]
    if x['normalized_unit']==y['normalized_unit'] and y['normalized_value']>0:
     emit(k,field+'_yoy',(x['normalized_value']/y['normalized_value']-1)*100,'percent',[x,y],'same fiscal window and accounting basis; positive prior denominator')
 return out

def model_type(r):
 if r['type'] in ('mutual_fund_certificate','fund_certificate','ETF'):return 'fund'
 if r['category']=='Banks':return 'bank'
 if r['type'] in ('provider_stock','stock_unverified','common_stock','preferred_stock'):return 'company'
 return 'reference'

def catalogue(c):
 return rows(c,"select i.*, (select count(*) from fundamental_observation f where f.instrument_id=i.id) financial_count,(select count(*) from history_observation h where h.instrument_id=i.id and h.dataset='nav') nav_count,(select count(*) from fund_characteristics f where f.instrument_id=i.id) profile_count from instrument_catalogue i order by symbol,id")

def report(c,ident,cutoff=None):
 if cutoff:date(cutoff)
 rr=rows(c,'select * from instrument_catalogue where id=?',(ident,))
 if not rr:raise ValueError('Unknown instrument')
 i=rr[0];raw=rows(c,'select * from fundamental_observation where instrument_id=?',(ident,));selected,conflicts=select_vintage(raw,cutoff)
 q='select * from fund_characteristics where instrument_id=?';p=rows(c,q,(ident,)) if not cutoff else []
 # fund terms and retrospective sampled performance excluded from as-of view
 nav=rows(c,"select * from perf_observed_sample where instrument_id=? and dataset='nav'",(ident,)) if not cutoff else []
 fm=rows(c,'select * from funds_master where instrument_id=?',(ident,)) if not cutoff else []
 policy=rows(c,'select * from fund_distribution_policy where instrument_id=?',(ident,)) if not cutoff else []
 actions=rows(c,"select * from corporate_action where instrument_id=? and action_type='cash_dividend'",(ident,))
 if cutoff:actions=[a for a in actions if a['announcement_date'] and a['announcement_date']<cutoff]
 return {'instrument':i,'model':model_type(i),'mode':'dated_candidate_asof' if cutoff else 'retrospective_education','cutoff':cutoff,'raw_count':len(raw),'statements':selected,'metrics':metrics(selected,i['category']),'conflicts':conflicts,'fund_terms':p,'fund_master':fm,'fund_nav_samples':nav,'fund_distribution_policy':policy,'dividend_events':actions,'warnings':['Historical reuse and training approval unresolved. No investment rating or live authorization.','Reported ratios are not independently recomputed unless listed as D2.','Price/share-count adjustment basis unverified: no automatic P/E, P/B, dividend yield or company valuation.']+(['Undated observations, fund profiles and historical NAV returns excluded; catalogue metadata is present-day reference only.'] if cutoff else ['Retrospective data may contain later revisions and unknown release dates.'])}

def dcf(fcff,growth,wacc,terminal,years,net_debt=0,shares=None):
 fcff,growth,wacc,terminal,net_debt=map(finite,(fcff,growth,wacc,terminal,net_debt))
 if type(years)!=int or not 1<=years<=30 or not -1<growth<=2 or not 0<wacc<=2 or not -1<terminal<wacc:raise ValueError('Require 1–30 years, growth > -100%, WACC > terminal growth, reasonable rates')
 if fcff<=0:raise ValueError('Positive normalized base FCFF required for this simple model')
 flows=[fcff*(1+growth)**t for t in range(1,years+1)];pv=sum(x/(1+wacc)**t for t,x in enumerate(flows,1));tv=flows[-1]*(1+terminal)/(wacc-terminal)/(1+wacc)**years;ev=pv+tv;eq=ev-net_debt
 if shares is not None:
  shares=finite(shares)
  if shares<=0:raise ValueError('Positive shares required')
 return {'enterprise_value':ev,'equity_value':eq,'per_share':eq/shares if shares else None,'pv_explicit':pv,'pv_terminal':tv,'terminal_fraction':tv/ev,'mode':'D5_user_assumptions','training_approved':0}

def multiple(value,mult):
 value,mult=map(finite,(value,mult))
 if value<=0 or mult<=0:raise ValueError('Positive per-share base and multiple required')
 return {'per_share':value*mult,'mode':'D5_user_assumptions'}

def fund_cost(capital,ret,entry,exit):
 capital,ret,entry,exit=map(finite,(capital,ret,entry,exit))
 if capital<=0 or ret<=-1 or not 0<=entry<1 or not 0<=exit<1:raise ValueError('Invalid assumptions')
 end=capital*(1-entry)*(1+ret)*(1-exit);return {'ending':end,'net_return':end/capital-1,'mode':'D5_user_assumptions','note':'Entry fee modeled as deduction from capital; no tax/distributions; not broker terms'}

def sensitivity(revenue,cost,debt,fx_exposure,rate_delta,fx_delta):
 revenue,cost,debt,fx_exposure,rate_delta,fx_delta=map(finite,(revenue,cost,debt,fx_exposure,rate_delta,fx_delta))
 if min(revenue,cost,debt)<0 or not 0<=fx_exposure<=1 or fx_delta<=-1:raise ValueError('Invalid sensitivity assumptions')
 return {'base_operating_surplus':revenue-cost,'incremental_import_cost':cost*fx_exposure*fx_delta,'incremental_interest_cost':debt*rate_delta,'post_shock_surplus_before_existing_interest_tax':revenue-cost-cost*fx_exposure*fx_delta-debt*rate_delta,'mode':'D5_user_assumptions'}

def peers(c,ident,cutoff=None):
 base=report(c,ident,cutoff);cat=base['instrument']['category'];result=[]
 if not cat or base['model'] not in ('bank','company'):return result
 for i in rows(c,'select * from instrument_catalogue where category=? and id<>?',(cat,ident)):
  if model_type(i)!=base['model']:continue
  other=report(c,i['id'],cutoff)
  def key(m):return tuple(m[k] for k in ('scope','accounting_basis','period_start','period_end','metric','unit'))
  om={key(m):m for m in other['metrics']}
  for m in base['metrics']:
   if key(m) in om:
    n=om[key(m)];result.append({'peer':i['id'],'metric':m['metric'],'period_end':m['period_end'],'accounting_basis':m['accounting_basis'],'scope':m['scope'],'unit':m['unit'],'base':m['value'],'peer_value':n['value'],'base_inputs':m['input_ids'],'peer_inputs':n['input_ids']})
 return result
