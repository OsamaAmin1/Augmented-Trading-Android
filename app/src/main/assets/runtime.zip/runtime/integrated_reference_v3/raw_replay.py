"""Fresh V2 eligibility evaluation on selected positive cases and mutations."""
from build import *
# V2 checks local files absent from mounted directory. Verify the complete original archive instead.
m=json.loads((P/'manifest.json').read_text())['files_sha256'];z=zipfile.ZipFile(R/'persona_v7.zip');assert all(hashlib.sha256(z.read('persona_v7/'+k)).hexdigest()==v and (not (P/k).exists() or hashlib.sha256((P/k).read_bytes()).hexdigest()==v) for k,v in m.items())
source=V/'build.py'; tree=ast.parse(source.read_text());tree.body=[n for n in tree.body if not isinstance(n,ast.Assert) and not isinstance(n,ast.If)];ns={'__file__':str(source),'__name__':'raw_reference'};exec(compile(tree,str(source),'exec'),ns)
D=pd.read_csv(O/'integrated_plans.csv',keep_default_na=False);D=D[D.case_type=='core'].set_index('persona_id');P0=pd.read_csv(P/'personas.csv').set_index('persona_id',drop=False); positives=D[D.market_alloc>.05]; rows=[]
# Verify the full chain for every previously positive case, plus four safety mutations.
for k,b in positives.iterrows():
 p=P0.loc[k];gs=goal.goals(p)
 for test,field,val in [('fresh_baseline',None,None),('reject_any_loss','reject_any_loss',True),('borrowed_funding','FP-08','borrowed'),('immediate_horizon','FP-10','immediate'),('uncertain_obligations','obligation_uncertain',True)]:
  q=p.copy();
  if field:q[field]=val
  ee,pl=ns['evaluate'](q);ee=pd.DataFrame(ee).set_index('strategy_id');rr,_,_=run(q,pd.Series(pl),ee,gs); actual=rr['market_alloc'];ok=(abs(actual-b.market_alloc)<=.05 and rr['active_components']==b.active_components) if not field else actual<=.05 and not rr['active_components'];rows.append(dict(persona_id=k,test=test,modified_field=field,modified_value=val,baseline_allocation=b.market_alloc,actual_allocation=actual,actual_components=rr['active_components'],passed=bool(ok)))
T=pd.DataFrame(rows);T.to_csv(O/'raw_replay_tests.csv',index=False);print(T.groupby('test').passed.agg(['size','sum']).to_string());assert T.passed.all()
