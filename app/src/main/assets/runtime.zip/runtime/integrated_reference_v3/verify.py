from pathlib import Path
import os,json,hashlib,zipfile
import pandas as pd,numpy as np
R=Path(os.getenv('PROJECT_ROOT','/mnt/data'));O=Path(__file__).parent;V=R/'strategy_reference_v2';P=R/'persona_v7'
D=pd.read_csv(O/'integrated_plans.csv',keep_default_na=False);G=pd.read_csv(O/'goal_plans.csv');S=pd.read_csv(O/'scenario_cashflows.csv'); eps=.05
split=pd.read_csv(V/'split_manifest.csv').set_index('persona_id').split;reg=pd.read_csv(V/'strategy_register.csv').set_index('id');mat=pd.read_csv(R/'strategy_compatibility_v1/compatibility_matrix.csv').set_index('strategy_id')
def parts(x):return set(str(x).split('|'))-{'','nan'}
checks=[]; failures=[]
def check(name,mask,keys,scope):
 mask=np.asarray(mask,dtype=bool);checks.append(dict(scope=scope,check=name,total=len(mask),passed=int(mask.sum()),failed=int((~mask).sum())))
 for k in np.asarray(keys)[~mask]:failures.append(dict(scope=scope,check=name,case_id=k))
def ck(name,mask):check(name,mask,D.case_id,'plan')
pos=D.market_alloc>eps
ck('split matches frozen manifest',D.split.eq(D.persona_id.map(split))&D.split.ne('holdout'))
ck('unique case IDs',~D.case_id.duplicated(keep=False))
ck('foundation ID valid',D.foundation.isin(reg.index[:5]))
ck('no live authorization',~D.live_authorized & D.approved_allocation.eq(0))
ck('financial gate preserved',~D.financial_gate|~pos)
ck('joint gates preserved',D.joint_gates.eq('')|~pos)
ck('protected cash gap prevents new market',D.protected_cash_shortfall.le(.005)|~pos)
ck('positive allocation has components',D.active_components.ne('')==pos)
ck('no prohibited active components',[not(parts(a)&parts(b)) for a,b in zip(D.active_components,D.blocked_strategies)])
ck('active components eligible after controls',[parts(a)<=parts(b) for a,b in zip(D.active_components,D.eligible_after_controls)])
ck('market ceiling respected',D.market_alloc.le(D.joint_envelope+eps))
ck('capital conservation',D.market_alloc+D.cash_assigned<=D.uncommitted_cash+eps)
ck('goal cash resource matches uncommitted cash',np.isclose(D.cash_initial,D.uncommitted_cash,atol=eps,rtol=0))
ck('contribution ceiling',D.contributions.le(D.monthly_budget+eps))
ck('sleeve reconciliation',np.isclose(D.market_alloc,D.investment_alloc+D.trading_alloc+D.satellite_alloc,atol=eps,rtol=0))
ck('stress reconciliation',np.isclose(D.modeled_incremental_stress,.35*(D.investment_alloc+D.satellite_alloc)+.5*D.trading_alloc,atol=eps,rtol=0))
ck('incremental stress constraint',D.modeled_incremental_stress.le(D.incremental_loss_budget+eps))
ck('aggregate stress constraint',~pos|(D.existing_stress+D.modeled_incremental_stress<=D.loss_limit+eps))
ck('no missing readiness',D.readiness.ne('')&D.questions_pending.ne(''))
ck('lexicographic objective',D.objective_shortfall.le(D.primary_optimum+2e-7))
ck('nonnegative allocations',(D[['market_alloc','cash_assigned','contributions','investment_alloc','trading_alloc','satellite_alloc']]>=-eps).all(axis=1))
ck('no conflicting same-sleeve pair',[all(mat.loc[i,j] not in ['ALTERNATIVE','GATED','SEPARATE_SLEEVE','REGIME_CONDITIONAL'] for i in parts(a) for j in parts(a) if i!=j) for a in D.active_components])
# Recompute monthly account balances from saved goals; no solver calls.
M=S.merge(G,on=['case_id','goal_id'],suffixes=('','_g'),validate='many_to_one').merge(D[['case_id','trade_share']],on='case_id',validate='many_to_one'); n=len(M);cash=M.initial_cash.to_numpy().copy();inv=M.initial_market.to_numpy()*(1-M.trade_share.to_numpy());tr=M.initial_market.to_numpy()*M.trade_share.to_numpy(); mins=cash.copy();rc=(1+M.cash_rate.to_numpy())**(1/12);ri=((1+M.market_investment_rate.to_numpy())*.99)**(1/12);rt=((1+M.market_trading_rate.to_numpy())*.99)**(1/12);months=M.months.to_numpy();flow=M.monthly_contribution.to_numpy()-M.monthly_withdrawal_paid.to_numpy()
for t in range(int(months.max())):
 active=months>t;cash[active]=cash[active]*rc[active]+flow[active];inv[active]*=ri[active];tr[active]*=rt[active];mins=np.minimum(mins,cash)
target=M.target_today*np.where(M.real_target,(1+M.inflation)**(months/12),1); wealth=cash+inv+tr;gap=np.maximum(0,target-wealth)
for name,m in [('cash never negative',mins>=-eps),('terminal cash',np.isclose(cash,M.terminal_cash,atol=eps,rtol=0)),('terminal market',np.isclose(inv+tr,M.terminal_market,atol=eps,rtol=0)),('terminal wealth',np.isclose(wealth,M.terminal_wealth,atol=eps,rtol=0)),('target',np.isclose(target,M.target,atol=eps,rtol=0)),('shortfall',np.isclose(gap,M.shortfall,atol=eps,rtol=0)),('withdrawal bounds',M.monthly_withdrawal_paid.le(M.withdrawal+eps)&M.monthly_withdrawal_paid.ge(-eps)),('market horizon',M.months.ge(36)|M.initial_market.le(eps))]:check(name,m,M.case_id,'scenario')
# Goal and scenario cardinalities, actual status and sums.
met=(gap<=eps)&(M.monthly_withdrawal_gap<=eps);M['recalc_met']=met; agg=M.groupby('case_id').recalc_met.all();base=M[M.scenario=='base'].groupby('case_id').recalc_met.all(); totals=G.groupby('case_id')[['initial_cash','initial_market','monthly_contribution']].sum();
ck('two goals per plan',D.case_id.map(G.groupby('case_id').size()).eq(2));ck('six scenarios per plan',D.case_id.map(S.groupby('case_id').size()).eq(6));ck('goal capital reconciles',np.isclose(D.cash_assigned,D.case_id.map(totals.initial_cash),atol=eps,rtol=0)&np.isclose(D.market_alloc,D.case_id.map(totals.initial_market),atol=eps,rtol=0));ck('goal contributions reconcile',np.isclose(D.contributions,D.case_id.map(totals.monthly_contribution),atol=eps,rtol=0));ck('base classification',D.base_all_met.eq(D.case_id.map(base)));ck('robust classification',D.robust_all_met.eq(D.case_id.map(agg)))
F=D[D.case_type=='conflict'].copy(); detected=[x in parts(y) for x,y in zip(F.test_conflict,F.conflicts)];check('target conflict detected',detected,F.case_id,'conflict'); policy=pd.read_csv(R/'strategy_compatibility_v1/conflict_control_register.csv').set_index('conflict').control;check('target control propagated',[policy[x] in parts(y) for x,y in zip(F.test_conflict,F.conflict_controls)],F.case_id,'conflict')
T=pd.DataFrame(checks);T.to_csv(O/'checks.csv',index=False);pd.DataFrame(failures,columns=['scope','check','case_id']).to_csv(O/'failures.csv',index=False)
core=D[D.case_type=='core'].copy();old=pd.read_csv(R/'financial_goal_v1/persona_plans.csv').set_index('persona_id'); core['previous_market_alloc']=core.persona_id.map(old.market_alloc); core['allocation_delta']=core.market_alloc-core.previous_market_alloc;core['previous_base_all_met']=core.persona_id.map(old.base_all_met);core[['persona_id','split','previous_market_alloc','market_alloc','allocation_delta','previous_base_all_met','base_all_met','conflicts','active_components']].to_csv(O/'core_comparison.csv',index=False)
Y=D[D.case_type=='dynamic'];b=Y.pivot(index=['persona_id','event'],columns='state',values=['market_alloc','base_all_met','conflicts','active_components']);changes={k:int((b[k].before!=b[k].after).sum()) for k in ['base_all_met','conflicts','active_components']};changes['allocation']=int((abs(b.market_alloc.before-b.market_alloc.after)>eps).sum());b.to_csv(O/'dynamic_comparison.csv')
summary=dict(counts=D.groupby('case_type').size().to_dict(),by_split=core.groupby('split').size().to_dict(),core_positive=int((core.market_alloc>eps).sum()),core_total=float(core.market_alloc.sum()),core_base_met=int(core.base_all_met.sum()),core_robust_met=int(core.robust_all_met.sum()),core_conflict_personas=int(core.conflicts.ne('').sum()),core_conflict_occurrences=int(sum(len(parts(x)) for x in core.conflicts)),core_changed_allocation=int((abs(core.allocation_delta)>eps).sum()),core_old_positive=int((core.previous_market_alloc>eps).sum()),core_newly_zero=int(((core.previous_market_alloc>eps)&(core.market_alloc<=eps)).sum()),dynamic_changes=changes,conflict_cases=len(F),conflict_detected=sum(detected),scenario_evidence_cases=int(F.scenario_evidence_supplied.sum()),checks_total=int(T.total.sum()),checks_passed=int(T.passed.sum()),checks_failed=int(T.failed.sum()),holdout_labels_read=False,goals=len(G),scenarios=len(S))
(O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print(T[T.failed>0].to_string(index=False))
