import os,json,hashlib,zipfile,importlib.util,ast
from pathlib import Path
import numpy as np,pandas as pd
R=Path(os.getenv('PROJECT_ROOT','/mnt/data')); O=Path(__file__).parent; P=R/'persona_v7'; V=R/'strategy_reference_v2'; K=R/'strategy_compatibility_v1'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
cap=load('capital',R/'capital_sleeve_v1/build.py');joint=load('joint',R/'joint_optimizer_v1/build.py');goal=load('goal',R/'financial_goal_v1/build.py')
node=next(n for n in ast.parse((K/'build.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='trigger');exec(compile(ast.Module(body=[node],type_ignores=[]),'policy_predicate','exec'))
reg=joint.reg;market=set(reg.index[5:]);policy=pd.read_csv(K/'conflict_control_register.csv').set_index('conflict');scenario_ids={3,18,21};emptyctx=pd.Series(dict(target_monthly_income=0,scenario_income_ceiling_monthly=0,available_capital=0,scenario_basket_min_cost=0,synthetic_period_returns_pct='',synthetic_confidence_0_100=''))
def parts(x):return set(str(x).split('|'))-{'','nan'}
def pipe(x):return '|'.join(sorted(x))
def restrictions(k,p):
 if k in (2,13,20,23):return market.copy()
 if k==1:return set(reg.index[reg.min_capacity.gt({'none':0,'limited':1,'medium':2,'high':3}[p['FP-15']])])&market
 if k in (4,5,25):return {'ST-28','ST-29'} | (set(reg.index[reg.monitor.eq('daily')]) if k==4 and p['PC-05']=='none' else set())
 return set()
def run(p,pl,e,gs,ctx=None,ck=None):
 hits={k for k in range(1,26) if k not in scenario_ids and trigger(k,p,emptyctx)}
 if ck in scenario_ids and trigger(ck,p,ctx):hits.add(ck)
 codes={f'CF-{k:02}' for k in hits};ban=set().union(*(restrictions(k,p) for k in hits));cs={policy.loc[k,'control'] for k in codes}
 a=pd.Series(cap.solve(p,pl,banned=ban));j=joint.solve(p,a,e,pl,ban=ban)
 d=.5*max(0,p.monthly_surplus) if a.protected_cash_shortfall<=.005 and not p.obligation_uncertain and p['FP-07'] not in ('high cost','distressed') else 0
 gr,sr,f=goal.solve(gs,float(j['available_cash']),d,float(j['total_envelope']),float(j['trading']/j['total_envelope']) if j['total_envelope']>0 else 0.)
 ids=parts(j['investment_components'])|parts(j['trading_components'])|parts(j['satellite_or_standby']);ids|={j['architecture']} if j['architecture'].startswith('ST-') else set();train=set();ver=set()
 for i in (ids or (parts(pl.market_components)-ban)):train|=parts(e.loc[i,'readiness_requirements']);ver|=parts(e.loc[i,'conditions'])
 active=ids if f['market_alloc']>.05 else set();pending=parts(pl.questions_pending)|{'confirm_actual_goal_amounts_dates_and_contributions','verify_existing_holdings_and_funding','confirm_product_costs_and_liquidity'}
 if not f['base_all_met']:pending.add('review_goal_shortfall_target_deadline_or_contributions')
 if codes:pending.add('resolve_or_acknowledge_conflict_controls')
 if active:ver.add('confirm_strategy_and_allocation_before_execution')
 ratio=f['market_alloc']/j['total_envelope'] if j['total_envelope']>0 else 0
 out=dict(persona_id=p.persona_id,foundation=pl.foundation_strategy,financial_gate=bool(pl.financial_gate),pathway=pl.pathway,reference_candidate=pl.market_candidate,reference_components=pl.market_components,eligible_after_controls=pipe(parts(pl.market_eligible)-ban),conflicts=pipe(codes),conflict_controls=pipe(cs),blocked_strategies=pipe(ban),scenario_evidence_supplied=ck in scenario_ids,allocation_gates=a.reasons,joint_gates=j['gates'],joint_architecture=j['architecture'],joint_components=pipe(ids),active_components=pipe(active),plan_status='conditional_goal_plan' if active else 'no_new_market_exposure',readiness='preparation_and_verification' if train else 'verification_required',training=pipe(train),verification=pipe(ver),questions_pending=pipe(pending),risk_controls=pipe(parts(pl.risk_controls)|cs),execution_methods=pl.execution_methods,uncommitted_cash=a.uncommitted_cash,protected_cash_shortfall=a.protected_cash_shortfall,existing_exposure=a.existing_investment_proxy,existing_stress=j['existing_loss'],loss_limit=j['loss_limit'],incremental_loss_budget=j['loss_room'],joint_envelope=j['total_envelope'],investment_alloc=j['investment']*ratio,trading_alloc=j['trading']*ratio,satellite_alloc=j['satellite']*ratio,modeled_incremental_stress=j['stress_loss']*ratio,approved_allocation=0,**f)
 return out,gr,sr

def main():
 manifest=json.loads((P/'manifest.json').read_text())['files_sha256'];z=zipfile.ZipFile(R/'persona_v7.zip');assert all(hashlib.sha256(z.read('persona_v7/'+k)).hexdigest()==v and (not (P/k).exists() or hashlib.sha256((P/k).read_bytes()).hexdigest()==v) for k,v in manifest.items())
 split=pd.read_csv(V/'split_manifest.csv');split=split[split.split!='holdout'].set_index('persona_id').split;core=pd.read_csv(P/'personas.csv').set_index('persona_id',drop=False).loc[split.index];plans=pd.concat([pd.read_csv(V/f'plans_{s}.csv',keep_default_na=False) for s in ('development','validation')]).set_index('persona_id');ev=pd.concat([pd.read_csv(V/f'evaluations_{s}.csv',keep_default_na=False) for s in ('development','validation')]);E={k:g.set_index('strategy_id') for k,g in ev.groupby('persona_id')};sp=pd.concat([pd.read_csv(V/f'stress_plans_{s}.csv',keep_default_na=False) for s in ('development','validation')]).set_index('case_id');se=pd.concat([pd.read_csv(V/f'stress_evaluations_{s}.csv',keep_default_na=False) for s in ('development','validation')]);SE={k:g.set_index('strategy_id') for k,g in se.groupby('case_id')};dyn=pd.read_csv(P/'dynamic_snapshots.csv');dyn=dyn[dyn.persona_id.isin(split.index)];fx=pd.read_csv(P/'counterfactual_profiles.csv').set_index('fixture_id');suite=pd.read_csv(P/'final_conflict_suite.csv');suite=suite[suite.persona_id.isin(split.index)];gs={k:goal.goals(p) for k,p in core.iterrows()};rows=[];gr=[];sr=[]
 def add(p,pl,e,kind,key,ctx=None,ck=None):
  out,g,s=run(p,pl,e,gs[p.persona_id],ctx,ck);meta=dict(case_id=key,case_type=kind,split=split.loc[p.persona_id],test_conflict=f'CF-{ck:02}' if ck else '',event=pl.get('event',''),state=pl.get('state',''));rows.append(dict(**meta,**out));gr.extend(dict(**meta,persona_id=p.persona_id,**r) for r in g);sr.extend(dict(**meta,persona_id=p.persona_id,**r) for r in s)
 for k,p in core.iterrows():add(p,plans.loc[k],E[k],'core',k)
 print('core done',flush=True)
 for _,p in dyn.iterrows():
  k=f'{p.persona_id}:{p.event_id}:{p.state}';add(p,sp.loc[k],SE[k],'dynamic',k)
 print('dynamic done',flush=True)
 for n,s in enumerate(suite.itertuples(index=False)):
  ctx=pd.Series(s._asdict());ck=int(s.test_conflict[-2:]);k=s.persona_id
  if s.case_type=='counterfactual':p=fx.loc[s.fixture_id];pl=sp.loc[s.fixture_id];e=SE[s.fixture_id]
  else:p=core.loc[k];pl=plans.loc[k];e=E[k]
  add(p,pl,e,'conflict',f'CT-{n+1:04}',ctx,ck)
 print('conflicts done',flush=True)
 D=pd.DataFrame(rows);G=pd.DataFrame(gr);S=pd.DataFrame(sr);D.to_csv(O/'integrated_plans.csv',index=False);G.to_csv(O/'goal_plans.csv',index=False);S.to_csv(O/'scenario_cashflows.csv',index=False)
 assert D.case_id.is_unique and set(D.persona_id)==set(split.index)
 print(D.groupby('case_type').agg(n=('case_id','size'),positive=('market_alloc',lambda s:sum(s>.05)),base_met=('base_all_met','sum'),robust=('robust_all_met','sum'),total=('market_alloc','sum')).to_string(),flush=True)
if __name__=='__main__':main()
