from pathlib import Path
import os,json,hashlib,zipfile
import numpy as np,pandas as pd
from scipy.optimize import linprog
R=Path(os.getenv('PROJECT_ROOT','/mnt/data')); O=Path(__file__).parent
# name, cash return, investment return, trading return, inflation (annual, synthetic)
SC=[('adverse',0.,-.15,-.25,.15),('base',.04,.08,.08,.10),('favorable',.08,.18,.25,.06)]
W=np.array([.5,.35,.15]); FEE=.01

def fac(r,n):
 m=(1+r)**(1/12)-1;a=(1+m)**n;return a,(a-1)/m if abs(m)>1e-10 else n

def goals(p):
 rng=np.random.default_rng(int(p.persona_id[1:])+82491);base=max(0,p.investment_savings-p.invested_from_savings-p.earmarked_savings);out=[]
 for j,(g,w) in enumerate([(p.FO,p.primary_goal_weight),(p.secondary_goal,p.secondary_goal_weight)]):
  n={'preservation':12,'purchasing power':36,'income':36,'replace job':60,'specific goal':24,'wealth':60,'independence':120,'quick profit':6,'small capital growth':24,'wealth management':60}[g];known=g=='specific goal' and p.goal_months_remaining>0
  if known:n=int(p.goal_months_remaining)
  elif g not in ('preservation','quick profit'):n=max(12,int(n*rng.choice([.75,1,1.25])))
  seed=max(1000,base*w);ms=max(0,p.monthly_surplus)*w;mult={'preservation':1,'purchasing power':1,'income':1,'replace job':1,'specific goal':1.5,'wealth':1.5,'independence':2.5,'quick profit':1.4,'small capital growth':1.5,'wealth management':1.3}[g];t=round(max(1000,seed*mult+(0 if g in ('preservation','purchasing power','income','replace job') else ms*n*rng.uniform(.15,.85))),2);ki=p.target_monthly_income>0 and j==0
  q=round(p.target_monthly_income if ki else p.monthly_expenses*rng.uniform(.15,.6)*w,2) if g in ('income','replace job') else 0.
  out.append(dict(goal_id=f'G{j+1}',goal=g,weight=float(w),months=n,target_today=t,real_target=g not in ('preservation','quick profit'),withdrawal=q,source='synthetic_assumption',date_source='existing_synthetic' if known else 'generated',withdrawal_source='existing_synthetic' if q and ki else 'generated' if q else 'not_applicable'))
 return out

def required_rate(c,d,n,t):
 if t<=c+n*d:return 0.
 if c<=0 and d<=0:return None
 def fv(r):a,b=fac(r,n);return a*c+b*d
 hi=1.
 while hi<100 and fv(hi)<t:hi*=2
 if fv(hi)<t:return None
 lo=0.
 for _ in range(45):
  mid=(lo+hi)/2
  if fv(mid)>=t:hi=mid
  else:lo=mid
 return hi

def solve(gs,C,D,M,ts=0.,weights=W):
 # Thousands of EGP. Per goal: initial cash, market, monthly contribution, paid withdrawal, 3 terminal shortfalls.
 C,D,M=[max(0,float(x))/1000 for x in (C,D,M)];N=7*len(gs);A=[];B=[];obj=np.zeros(N);bounds=[];cache={}
 def row(entries,rhs):
  v=np.zeros(N)
  for idx,val in entries:v[idx]=val
  A.append(v);B.append(rhs)
 row([(7*j+k,1) for j in range(len(gs)) for k in (0,1)],C);row([(7*j+1,1) for j in range(len(gs))],M);row([(7*j+2,1) for j in range(len(gs))],D)
 for j,g in enumerate(gs):
  n=g['months'];w=g['weight'];t=g['target_today']/1000;q=g['withdrawal']/1000;i=7*j;bounds.extend([(0,C),(0,M if n>=36 else 0),(0,D),(0,q)]+[(0,None)]*3);frac=.5 if q>0 else 1.
  if q:obj[i+3]=-w*(1-frac)/q
  for s,(_,rc,ri,rt,inf) in enumerate(SC):
   a,b=fac(rc,n);ai,_=fac((1+ri)*(1-FEE)-1,n);at,_=fac((1+rt)*(1-FEE)-1,n);am=ai*(1-ts)+at*ts;target=t*(1+inf)**(n/12) if g['real_target'] else t;cache[j,s]=(a,b,am,target)
   row([(i,-a),(i+1,-am),(i+2,-b),(i+3,b),(i+4+s,-1)],-target);row([(i,-a),(i+2,-b),(i+3,b)],0);obj[i+4+s]=w*frac*weights[s]/max(target,1e-9)
 sol=linprog(obj,A_ub=A,b_ub=B,bounds=bounds,method='highs');assert sol.success,sol.message
 obj2=np.zeros(N);obj2[1::7]=1
 sol2=linprog(obj2,A_ub=np.vstack([A,obj]),b_ub=np.r_[B,sol.fun+1e-8],bounds=bounds,method='highs');assert sol2.success,sol2.message
 x=np.maximum(0,sol2.x);rows=[];scrows=[]
 for j,g in enumerate(gs):
  i=7*j;c,m,d,q=x[i:i+4]*1000;n=g['months'];targets=[];deficits=[];cashmins=[]
  for s,(name,rc,ri,rt,inf) in enumerate(SC):
   a,b,am,t=cache[j,s];t*=1000;ce=a*c+b*(d-q);wealth=ce+am*m;gap=max(0,t-wealth);targets.append(t);deficits.append(gap);cashmins.append(min(c,ce));scrows.append(dict(goal_id=g['goal_id'],scenario=name,months=n,cash_rate=rc,market_investment_rate=ri,market_trading_rate=rt,inflation=inf,target=t,terminal_cash=ce,terminal_market=am*m,terminal_wealth=wealth,shortfall=gap,extra_monthly_cash_if_available=gap/b))
  unmet=max(0,g['withdrawal']-q);met=[gap<=.05 and unmet<=.05 for gap in deficits];rows.append(dict(**g,initial_cash=c,initial_market=m,monthly_contribution=d,monthly_withdrawal_paid=q,monthly_withdrawal_gap=unmet,base_target=targets[1],base_shortfall=deficits[1],adverse_shortfall=deficits[0],favorable_shortfall=deficits[2],base_met=met[1],all_scenarios_met=all(met),required_nonnegative_annual_return_base=required_rate(c+m,d,n,targets[1]) if g['withdrawal']==0 else None,required_income_yield_on_initial_capital=12*g['withdrawal']/(c+m) if g['withdrawal']>0 and c+m>0 else None,min_cash_balance=min(cashmins)))
 const=sum(g['weight']*.5 for g in gs if g['withdrawal']>0)
 return rows,scrows,dict(cash_initial=C*1000,monthly_budget=D*1000,market_cap=M*1000,trade_share=ts,market_alloc=x[1::7].sum()*1000,cash_assigned=x[0::7].sum()*1000,contributions=x[2::7].sum()*1000,base_all_met=all(r['base_met'] for r in rows),robust_all_met=all(r['all_scenarios_met'] for r in rows),objective_shortfall=float(obj@x+const),primary_optimum=float(sol.fun+const),live_authorized=False)

def main():
 P=R/'persona_v7';manifest=json.loads((P/'manifest.json').read_text())['files_sha256'];z=zipfile.ZipFile(R/'persona_v7.zip');assert all(hashlib.sha256(z.read('persona_v7/'+k)).hexdigest()==v and (not (P/k).exists() or hashlib.sha256((P/k).read_bytes()).hexdigest()==v) for k,v in manifest.items())
 split=pd.read_csv(R/'strategy_reference_v2/split_manifest.csv');split=split[split.split!='holdout'];p=pd.read_csv(P/'personas.csv').merge(split[['persona_id','split']],on='persona_id').set_index('persona_id',drop=False);J=pd.read_csv(R/'joint_optimizer_v1/joint_plans.csv').set_index('persona_id');A=pd.read_csv(R/'capital_sleeve_v1/core_allocations.csv').set_index('persona_id')
 def evaluate(q,j,a,gs,**kw):
  d=.5*max(0,q.monthly_surplus) if a.protected_cash_shortfall<=.005 and not q.obligation_uncertain and q['FP-07'] not in ('high cost','distressed') else 0
  return solve(gs,float(j.available_cash),d,float(j.total_envelope),float(j.trading/j.total_envelope) if j.total_envelope>0 else 0.,**kw)
 G={k:goals(q) for k,q in p.iterrows()};ag=[];asc=[];plans=[];sens=[]
 for k,q in p.iterrows():
  rr,ss,pl=evaluate(q,J.loc[k],A.loc[k],G[k]);meta=dict(persona_id=k,split=q['split']);ag.extend(dict(**meta,**r) for r in rr);asc.extend(dict(**meta,**r) for r in ss);plans.append(dict(**meta,**pl))
 pd.DataFrame(ag).to_csv(O/'goal_plans.csv',index=False);pd.DataFrame(asc).to_csv(O/'scenario_cashflows.csv',index=False);D=pd.DataFrame(plans);D.to_csv(O/'persona_plans.csv',index=False);print('core finished',flush=True)
 for name,ww in [('baseline',W),('adverse_heavy',np.array([.8,.15,.05])),('base_heavy',np.array([.15,.7,.15]))]:
  Y=D if name=='baseline' else pd.DataFrame([dict(persona_id=k,**evaluate(q,J.loc[k],A.loc[k],G[k],weights=ww)[2]) for k,q in p.iterrows()]);sens.append(dict(config=name,positive=int((Y.market_alloc>.05).sum()),market_total=float(Y.market_alloc.sum()),base_all_met=int(Y.base_all_met.sum()),robust_all_met=int(Y.robust_all_met.sum()),mean_weighted_shortfall=float(Y.objective_shortfall.mean())));print(name,flush=True)
 pd.DataFrame(sens).to_csv(O/'sensitivity.csv',index=False)
 dp=pd.read_csv(R/'joint_optimizer_v1/dynamic_plans.csv').set_index(['persona_id','event','state']);da=pd.read_csv(R/'capital_sleeve_v1/dynamic_allocations.csv').set_index(['persona_id','event','state']);dy=pd.read_csv(P/'dynamic_snapshots.csv').merge(split[['persona_id','split']],on='persona_id');dyn=[];dg=[];ds=[]
 for _,q in dy.iterrows():
  k=(q.persona_id,q.event_id,q.state);rr,ss,pl=evaluate(q,dp.loc[k],da.loc[k],G[k[0]]);meta=dict(persona_id=k[0],event=k[1],state=k[2]);dyn.append(dict(**meta,**pl));dg.extend(dict(**meta,**r) for r in rr);ds.extend(dict(**meta,**r) for r in ss)
 Y=pd.DataFrame(dyn);Y.to_csv(O/'dynamic_plans.csv',index=False);pd.DataFrame(dg).to_csv(O/'dynamic_goals.csv',index=False);pd.DataFrame(ds).to_csv(O/'dynamic_scenarios.csv',index=False)
 def g(n,t,q=0,real=False,w=1,id='G1'):return dict(goal_id=id,goal='test',months=n,target_today=t,withdrawal=q,real_target=real,weight=w,source='fixture')
 fs=[('cash_sufficient',[g(60,350000)],200000,5000,100000,lambda x,r:x['market_alloc']<.05 and x['robust_all_met']),('unrealistic_goal',[g(24,1000000)],200000,500,100000,lambda x,r:not x['base_all_met'] and (r[0]['required_nonnegative_annual_return_base'] or 0)>1),('zero_market_gate',[g(60,500000)],100000,2000,0,lambda x,r:x['market_alloc']<.05),('no_cashflow',[g(12,100000,1000)],0,0,0,lambda x,r:r[0]['monthly_withdrawal_paid']<.05 and not x['base_all_met']),('short_horizon',[g(12,130000)],100000,0,100000,lambda x,r:x['market_alloc']<.05),('two_goals',[g(12,100000,w=.5),g(60,200000,w=.5,id='G2')],100000,1000,50000,lambda x,r:x['cash_assigned']+x['market_alloc']<=100000.05 and x['contributions']<=1000.05),('income_affordable',[g(12,50000,1000)],100000,0,0,lambda x,r:x['robust_all_met']),('inflation_gap',[g(60,100000,real=True)],100000,0,0,lambda x,r:r[0]['base_shortfall']>0),('interior_allocation',[g(60,125000)],100000,0,100000,lambda x,r:.05<x['market_alloc']<99999)]
 fr=[]
 for name,gs,c,d,m,test in fs:
  rr,ss,x=solve(gs,c,d,m);fr.append(dict(fixture=name,passed=bool(test(x,rr)),**x,goal1_base_gap=rr[0]['base_shortfall'],goal1_required_return=rr[0]['required_nonnegative_annual_return_base']))
 rr,ss,x=solve([g(60,125000)],100000,0,100000,weights=np.array([.15,.7,.15]));fr.append(dict(fixture='interior_allocation_base_heavy',passed=.05<x['market_alloc']<99999,**x,goal1_base_gap=rr[0]['base_shortfall'],goal1_required_return=rr[0]['required_nonnegative_annual_return_base']))
 pd.DataFrame(fr).to_csv(O/'fixture_results.csv',index=False)
 summary=dict(core=len(D),goal_records=len(ag),scenario_records=len(asc),positive=int((D.market_alloc>.05).sum()),prior_positive=int((J.total_envelope>.05).sum()),market_total=float(D.market_alloc.sum()),prior_total=float(J.total_envelope.sum()),base_all_met=int(D.base_all_met.sum()),robust_all_met=int(D.robust_all_met.sum()),individual_base_met=int(sum(r['base_met'] for r in ag)),individual_robust_met=int(sum(r['all_scenarios_met'] for r in ag)),withdrawal_goals=int(sum(r['withdrawal']>0 for r in ag)),withdrawal_met=int(sum(r['withdrawal']>0 and r['monthly_withdrawal_gap']<=.05 for r in ag)),dynamic_records=len(Y),dynamic_goal_records=len(dg),dynamic_scenario_records=len(ds),dynamic_base_changed=int(Y.pivot(index=['persona_id','event'],columns='state',values='base_all_met').eval('before != after').sum()),fixtures=len(fr),fixtures_pass=sum(r['passed'] for r in fr),manifest_verified=len(manifest),sensitivity=sens)
 (O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print(pd.DataFrame(fr)[['fixture','passed','market_alloc','goal1_base_gap','goal1_required_return']].to_string(index=False))
if __name__=='__main__':main()
