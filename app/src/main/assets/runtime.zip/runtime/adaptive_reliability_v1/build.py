import os,sys,ast,json,multiprocessing as mp
from pathlib import Path
import numpy as np,pandas as pd
R=Path(__import__('os').environ['PROJECT_ROOT']);O=Path(__file__).parent
os.environ['ADAPTIVE_VARIANT']='refined';sys.path.insert(0,str(R/'adaptive_engine_v3'))
from run import E,Q,P,A,ids,ref,reg,truth,inputs,parts,verify,folders
from engine import DOM
B=pd.read_csv(R/'adaptive_engine_v3/refined_results.csv',keep_default_na=False).set_index('persona_id').loc[ids];T=pd.read_csv(R/'adaptive_engine_v3/refined_traces.csv').groupby('persona_id');QM={q.id:q for q in Q};REG=reg.set_index('id')
def pipe(x):return '|'.join(sorted(x))
def state(trace):
 d={k:set(v) for k,v in DOM.items()}
 for qid,a in trace:
  q=QM[qid];d[q.field]&=set(q.yes) if a else set(DOM[q.field])-set(q.yes)
 return d
# Conflict policy atomic predicates from frozen source, excluding contextual cases. Split conjunctions and collect each predicate explicitly.
node=next(n for n in ast.parse((R/'strategy_compatibility_v1/build.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='trigger')
expr=next(n for n in ast.walk(node) if isinstance(n,ast.Dict) and len(n.keys)==25)
rules={k.value:(v.values if isinstance(v,ast.BoolOp) and isinstance(v.op,ast.And) else [v]) for k,v in zip(expr.keys,expr.values) if k.value not in [3,18,21]}
# Map atomic predicates to existing evidence when possible; otherwise ask explicit predicate, never infer from missing data.
M={"bp(1) in ['adventurous', 'risk seeking']":('risk',{3,4}),"bp(1) == 'very conservative'":('risk',{0}),"p.reject_any_loss":('reject_any_loss',{True}),"bp(15) == 'high'":('activity',{True}),"lowtime":('time',{'none','limited'}),"kl <= 2":('KL',{0,1,2}),"kl >= 5":('KL',set(range(5,9))),"ex >= 5":('EX',set(range(5,8))),"bp(19) == 'self'":('mode',{'self'}),"bp(19) == 'delegate'":('mode',{'delegate'}),"p.rely_entirely_on_tips":('rely_entirely_on_tips',{True}),"p.long_hold_preference":('long_hold_preference',{True}),"p.same_bucket_liquidity":('same_bucket_liquidity',{True}),"p.no_learning_time":('no_learning_time',{True}),"p.unrealistic_expectations":('unrealistic_expectations',{True}),"p.same_bucket_borrowed":('same_bucket_borrowed',{True}),"p.control_every_decision":('control_every_decision',{True}),"p.time_sensitive_review_delay":('time_sensitive_review_delay',{True})}
intake={"p['FP-15'] in ['none', 'limited']","p['FP-10'] in ['immediate', 'months']","p['FP-12'] == 'essential'","p['FP-08'] == 'borrowed'"}
# All atomic propositions are separate simulated A/B answers. Source syntax is internal, not final UX wording.
ruletexts={k:[ast.unparse(v) for v in vv] for k,vv in rules.items()};codes={ast.unparse(v):compile(ast.Expression(v),'predicate','eval') for vv in rules.values() for v in vv}
def complete(i,selected=None):
 pid=ids[i];p=P.loc[pid];t,e=inputs(p);d=truth(p);b=B.loc[pid];trace=[(x.question,int(x.answer=='A')) for x in T.get_group(pid).itertuples()];st=state(trace);log=[];cache={};train=set();
 def query(key,oracle,field=None,yes=None,verified=False):
  if key in cache:return cache[key]
  if field is not None:
   x=st[field]; val=True if x<=yes else False if not x&yes else None
  else:val=None
  if val is None:
   val=bool(oracle())
   if not verified:log.append((key,val))
   if field is not None:st[field]&=yes if val else set(DOM[field])-yes
  cache[key]=val;return val
 def req(field,yes,label):
  if query(field+':'+str(sorted(yes)),lambda:d[field] in yes,field,yes):train.add(label)
 for s in parts(b.components):
  sp=REG.loc[s];n=int(s[-2:]);
  if sp.min_knowledge:req('KL',set(range(int(sp.min_knowledge))),'knowledge_training')
  if sp.min_experience:req('EX',set(range(int(sp.min_experience))),'supervised_simulation_or_practice')
  if n in list(range(18,31))+[33,34]:req('difficulty_stopping',{True},'behavioral_controls_and_review')
  req('difficulty_stopping',{True},'behavioral_control_assessment');req('unrealistic_expectations',{True},'realistic_return_expectations')
  if sp.management=='self':req('rely_entirely_on_tips',{True},'independent_decision_training')
  if sp.monitor in ['daily','intraday']:req('discipline_problem',{True},'discipline_and_loss_control')
 nr=len(log);g={p.FO,p.secondary_goal};styles={p.DS,p.secondary_style};lowtime=p['PC-05'] in ['none','limited'];kl=int(p.KL[-2:]);ex=int(p.EX[-2:]);bp=lambda i:p[f'BP-{i:02}'];cp=lambda i:p[f'CP-{i:02}'];bb=lambda i:p[f'BB-{i:02}'];env=dict(p=p,g=g,styles=styles,lowtime=lowtime,kl=kl,ex=ex,bp=bp,cp=cp,bb=bb);hits=set()
 for k,atoms in ruletexts.items():
  if selected is not None and k not in selected:continue
  def check(a):
   f,yes=M.get(a,(None,None));return query(a,lambda:eval(codes[a],{},env),f,yes,a in intake)
  if all(check(a) for a in atoms):hits.add(f'CF-{k:02}')
 r=ref.loc[pid];ready='preparation_and_verification' if train else 'verification_required'
 return dict(persona_id=pid,base_questions=len(trace),readiness_questions=nr,conflict_questions=len(log)-nr,total_questions=len(trace)+len(log),readiness=ready,reference_readiness=r.readiness,readiness_match=ready==r.readiness,training=pipe(train),reference_training=r.training,training_match=train==parts(r.training),detected=pipe(hits),reference_conflicts=r.conflicts,conflicts_exact=hits==parts(r.conflicts),context_pending='CF-03|CF-18|CF-21',live=False),[dict(persona_id=pid,question=k,answer='A' if v else 'B') for k,v in log]
def robust(t,e,answer,policy='triple'):
 logs=[];dis=0
 def ask(q):
  nonlocal dis
  a=answer(q,0);logs.append((q.id,a))
  if a not in (0,1):return None
  if q.priority not in ['objective','preference','readiness'] or policy=='single' or (policy=='goal' and q.priority!='objective'):return a
  b=answer(q,1);logs.append((q.id+'-C1',b))
  if b not in (0,1):return None
  if a==b:return a
  dis+=1;c=answer(q,2);logs.append((q.id+'-C2',c));return c if c in (0,1) else None
 z=E.assess(t,e,ask,budget=36);z.update(total_questions=len(logs),confirmation_questions=len(logs)-z['questions'],disagreements=dis);return z
def noise(i):
 pid=ids[i];p=P.loc[pid];d=truth(p);t,e=inputs(p);r=ref.loc[pid];a={q.id:int(A.loc[pid,q.id]=='A') if q.id in A.columns else int(d[q.field] in q.yes) for q in Q};rng=np.random.default_rng(i+170);first={q.id:int(q.priority in ['objective','preference','readiness'] and rng.random()<.1) for q in Q};extra=np.random.default_rng(i+921).random((len(Q),2));idx={q.id:j for j,q in enumerate(Q)};rows=[]
 for mode,policy,persist,clean in [('single_noise','single',False,False),('goal_confirmation','goal',False,False),('all_soft_confirmation','triple',False,False),('persistent_noise','triple',True,False),('clean_confirmation','triple',False,True)]:
  def ans(q,k):return a[q.id]^(0 if clean else first[q.id] if k==0 or persist else int(extra[idx[q.id],k-1]<.1))
  z=robust(t,e,ans,policy);c=parts(z['components']);rows.append(dict(persona_id=pid,mode=mode,exact=z['foundation']==r.foundation and z['pathway']==r.pathway and z['components']==r.reference_components,confirmed=z['confirmed'],questions=z['total_questions'],confirmation_questions=z['confirmation_questions'],disagreements=z['disagreements'],ineligible=bool(c-parts(r.eligible_after_controls)),gate_violation=bool(c and r.financial_gate),live=z['live']))
 return rows
if __name__=='__main__':
 with mp.Pool(8) as pool:
  result=list(pool.imap(complete,range(len(ids)),chunksize=50));print('completeness done',flush=True)
  D=pd.DataFrame([r for r,l in result]);D.to_csv(O/'completeness_results.csv',index=False);pd.DataFrame([q for r,l in result for q in l]).to_csv(O/'supplemental_question_traces.csv',index=False)
  N=pd.DataFrame([r for rr in pool.imap(noise,range(1,len(ids),10),chunksize=10) for r in rr]);print('noise done',flush=True)
 N.to_csv(O/'noise_tests.csv',index=False);M1=N.groupby('mode').agg(n=('exact','size'),exact=('exact','mean'),confirmed=('confirmed','sum'),avg_questions=('questions','mean'),avg_confirmations=('confirmation_questions','mean'),disagreements=('disagreements','sum'),ineligible=('ineligible','sum'),gate_violations=('gate_violation','sum'),live=('live','sum')).reset_index();M1.to_csv(O/'noise_summary.csv',index=False)
 pd.DataFrame([dict(conflict=f'CF-{k:02}',predicate=a,answer_A='Predicate true',answer_B='Predicate false',source='verified intake' if a in intake else 'binary evidence',wording_status='needs natural-language validation') for k,aa in ruletexts.items() for a in aa]).to_csv(O/'conflict_evidence_register.csv',index=False)
 print(M1.to_string(index=False),flush=True);print(D[['base_questions','readiness_questions','conflict_questions','total_questions','readiness_match','training_match','conflicts_exact']].mean().to_string(),flush=True)
