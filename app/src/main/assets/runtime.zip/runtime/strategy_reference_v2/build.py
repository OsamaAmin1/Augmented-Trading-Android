from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,os
from collections import Counter
ROOT=Path(os.environ.get('REFERENCE_ROOT','/mnt/data')); BASE=ROOT/'persona_v7'; OLD=ROOT/'strategy_reference_v1'; OUT=Path(__file__).parent
manifest=json.loads((BASE/'manifest.json').read_text())['files_sha256']
def integrity():return all(hashlib.sha256((BASE/k).read_bytes()).hexdigest()==v for k,v in manifest.items())
assert integrity()
reg=pd.read_csv(OLD/'strategy_register.csv').fillna(''); S=reg.to_dict('records')
for s in S:
 for k in ['goals','signals']:s[k]=s[k].split('|') if s[k] else []
capmap={'none':0,'limited':1,'medium':2,'high':3};tolmap={'very conservative':0,'conservative':1,'balanced':2,'adventurous':3,'risk seeking':4}
def assess(p,s):
 n=int(s['id'][-2:]); kind=s['kind']; cap=capmap[p['FP-15']]; tol=tolmap[p['BP-01']]; kl=int(p.KL[-2:]); ex=int(p.EX[-2:]); h=p['FP-10']; time=p['PC-05']; timing=p['PC-06']; intervention=p['PC-07']; mode=p['BP-19']; short=h in ['immediate','months']; owned=float(p.risk_budget)>0
 safety=[]; mismatch=[]; conditions=[]; readiness=[]
 financial_block=cap==0 or not owned or p['FP-07'] in ['high cost','distressed'] or p['FP-08']=='borrowed' or h=='immediate'
 # SD-15 is a simulated scenario answer, not proof of actual borrowed exposure; treat as confirmation gate.
 uncertainty=(bool(p.same_bucket_borrowed) and p['FP-08']!='borrowed') or bool(p.obligation_uncertain)
 if kind!='foundation':
  if financial_block: safety.append('financial_capacity_or_funding_gate')
  if cap<s['min_capacity']: safety.append('below_strategy_capacity')
  if short and bool(p.same_bucket_liquidity): safety.append('same_capital_needed_soon')
  if bool(p.reject_any_loss) or tol==0: mismatch.append('rejects_market_loss')
  if tol<s['risk_demand']: mismatch.append('risk_tolerance_below_requirement')
  if s['horizon']=='long' and h in ['immediate','months','year']: mismatch.append('long_horizon_mismatch')
  if s['horizon']=='medium' and short: mismatch.append('medium_horizon_mismatch')
  if h=='undefined' and s['horizon'] in ['long','medium']: conditions.append('confirm_horizon')
  if short and s['horizon']=='trade': conditions.append('separate_uncommitted_trading_funds')
  if uncertainty: conditions.append('clarify_funding_or_obligations')
  if bool(p.exposure_above_budget): conditions.append('review_existing_exposure')
  if s['monitor']=='intraday' and (time!='high' or timing!='session' or intervention!='immediate'): mismatch.append('intraday_availability_missing')
  if s['monitor']=='daily' and (time=='none' or intervention=='unavailable'): mismatch.append('daily_monitoring_missing')
  if s['monitor']=='low' and time=='none' and mode=='self': conditions.append('arrange_periodic_review')
  if s['management']=='self' and mode=='delegate': mismatch.append('prefers_delegation')
  if s['management']=='delegate' and mode=='self' and bool(p.control_every_decision): mismatch.append('delegation_rejected')
  if kind in ['trading','hybrid'] and n in list(range(18,31))+[33,34] and bool(p.difficulty_stopping): readiness.append('behavioral_controls_and_review')
  if kl<s['min_knowledge']: readiness.append('knowledge_training')
  if ex<s['min_experience']: readiness.append('supervised_simulation_or_practice')
  if s['management']=='self' and bool(p.rely_entirely_on_tips): readiness.append('independent_decision_training')
  if s['monitor'] in ['daily','intraday'] and (p['BP-05']=='undisciplined' or p['BP-06']=='impulsive' or p['BB-18']=='strong'): readiness.append('discipline_and_loss_control')
  if p['FP-12']=='essential' and n in [13,14,15,31]: conditions.append('verify_income_feasibility_no_guarantee')
  if n in [5,6,7,8,31,32,33,34]: conditions.append('verify_product_or_allocation_availability')
 else:
  if n==0 and not financial_block and not bool(p.exposure_above_budget) and not uncertainty: mismatch.append('no_identified_readiness_need')
  if n==3 and (not owned or p['FP-07'] in ['high cost','distressed'] or p['FP-08']=='borrowed' or h=='immediate'): mismatch.append('income_capital_not_available')
  if n==3: conditions.append('verify_non_equity_income_terms_and_feasibility')
  if n in [1,2,4] and not owned: conditions.append('budget_or_savings_plan_only')
  if n==4 and not(short or p.FO=='specific goal' or h=='year'): mismatch.append('no_identified_short_term_goal')
 # Weighted goals, partial credit for generic goals.
 def gmatch(g): return 1 if g in s['goals'] else .25 if g!='quick profit' and kind in ['foundation','investing','hybrid'] else .10
 goal=30*(p.primary_goal_weight*gmatch(p.FO)+p.secondary_goal_weight*gmatch(p.secondary_goal))
 risk=20*(1 if tol>=s['risk_demand'] else max(0,1-.35*(s['risk_demand']-tol)))
 horizonfit=1 if s['horizon']=='flexible' or (s['horizon']=='long' and h=='years') or (s['horizon']=='medium' and h in ['year','years']) or (s['horizon']=='trade' and h in ['year','years','undefined']) else .5
 monitorfit=1 if s['monitor']=='none' or (s['monitor']=='low' and time!='none') or (s['monitor']=='daily' and time in ['moderate','high']) or (s['monitor']=='intraday' and time=='high' and timing=='session' and intervention=='immediate') else .5 if time!='none' else 0
 timing_score=15*(.55*horizonfit+.45*monitorfit)
 sig={'security':p.MO=='security' or p['BP-01'] in ['very conservative','conservative'],'liquidity':short,'income':p.FO in ['income','replace job'] or p.secondary_goal=='income','shortgoal':short or h=='year' or p.FO=='specific goal','planning':p['CP-11']=='high','patience':p['BP-03']=='patient','fundamental':'fundamental' in [p.DS,p.secondary_style] or p['CP-05']=='high','verification':bool(p.challenge_claims) or bool(p.verification_preference),'activity':p['BP-15']=='high','rules':'rule-based' in [p.DS,p.secondary_style] or p['BP-05']=='disciplined','patterns':p['CP-04']=='high' or 'visual' in [p.DS,p.secondary_style],'quantitative':p['CP-02']=='high' or 'quantitative' in [p.DS,p.secondary_style],'fast':p['CP-07']=='high' and bool(p.fast_decision_preference),'adaptive':p['BP-09']=='adaptive' or 'adaptive' in [p.DS,p.secondary_style]}
 pref=20*(np.mean([float(sig.get(k,bool(p.get(k,False)))) for k in s['signals']]) if s['signals'] else 1 if n==0 and financial_block else .5)
 mgmt=15*(1 if s['management']=='any' or mode==s['management'] else .75 if mode=='shared' or s['management']=='shared' else .45)
 score=round(goal+risk+timing_score+pref+mgmt,3)
 if n==0 and financial_block: score=100.0 # policy precedence, not ordinary score
 status='financially_blocked' if safety else 'incompatible' if mismatch else 'conditional' if conditions or readiness else 'compatible'
 # A mandatory precondition prevents live action but not future strategy suitability.
 ready='not_applicable' if kind=='foundation' else 'blocked' if safety or mismatch else 'preparation_required' if readiness else 'verification_required' if conditions else 'model_ready'
 return dict(persona_id=p.persona_id, strategy_id=s['id'],status=status,score=score,goal_score=round(goal,3),risk_score=round(risk,3),time_score=round(timing_score,3),preference_score=round(pref,3),management_score=round(mgmt,3),safety_reasons='|'.join(safety),incompatibility_reasons='|'.join(mismatch),conditions='|'.join(conditions),readiness_requirements='|'.join(readiness),readiness=ready)

L={'foundation':range(5),'portfolio':[5,6,7,8,31,32,33,34],'philosophy':range(10,18),'investment_horizon':[9],'trading_horizon':[18,19,28,29],'setup':list(range(20,28))+[30]}
ROLE={f'ST-{i:02}':k for k,v in L.items() for i in v}; A={'compatible','conditional'}
def pipe(x):return '|'.join(dict.fromkeys(y for y in x if y))
def parts(x):return x.split('|') if x else []
def rank(x):return sorted(x,key=lambda r:(-r['score'],r['strategy_id']))
def evaluate(p,cf=''):
 rr=[assess(p,s) for s in S];by={r['strategy_id']:r for r in rr}
 for n,r in enumerate(rr):
  r['layer']=ROLE[r['strategy_id']];r['goal_direct_weight']=round(float(p.primary_goal_weight)*(p.FO in S[n]['goals'])+float(p.secondary_goal_weight)*(p.secondary_goal in S[n]['goals']),3)
  if n<5:continue
  cond=parts(r['conditions']);train=parts(r['readiness_requirements']);bad=parts(r['incompatibility_reasons'])
  if bool(p.same_bucket_borrowed):cond+=['confirm_no_borrowed_exposure']
  if p['FP-10']=='undefined':cond+=['confirm_liquidity_horizon']
  if p['FP-12']=='essential':cond+=['essential_income_not_funded_by_uncertain_returns']
  if bool(p.exposure_above_budget):cond+=['existing_exposure_review_no_increment']
  if bool(p.difficulty_stopping):train+=['behavioral_control_assessment']
  if bool(p.unrealistic_expectations):train+=['realistic_return_expectations']
  if bool(p.time_sensitive_review_delay) and n in [28,29]:bad+=['time_critical_review_delay']
  if cf=='CF-21':train+=['review_negative_performance_and_rising_confidence']
  r.update(conditions=pipe(cond),readiness_requirements=pipe(train),incompatibility_reasons=pipe(bad))
  r['status']='financially_blocked' if r['safety_reasons'] else 'incompatible' if bad else 'conditional' if cond or train else 'compatible'
  r['readiness']='blocked' if r['status'] not in A else 'preparation_required' if train else 'verification_required' if cond else 'model_requirements_met'
 for n in [32,33,34]:
  r=rr[n]
  if r['status'] not in A:continue
  invest=any(rr[i]['status'] in A for i in range(5,18));trade=all(any(rr[i]['status'] in A for i in L[k]) for k in ['trading_horizon','setup'])
  if not invest or (n==33 and not trade):r.update(status='incompatible',readiness='blocked',incompatibility_reasons='missing_compatible_component')
  else:r.update(status='conditional',conditions=pipe(parts(r['conditions'])+['confirm_sleeve_allocation_and_components']),readiness='preparation_required' if r['readiness_requirements'] else 'verification_required')
 gate=rr[0]['score']==100;f=rank([r for r in rr[:5] if r['status'] in A]);foundation='ST-00' if gate else f[0]['strategy_id']
 market=rank([r for r in rr[5:] if r['status'] in A]);aligned=[r for r in market if r['goal_direct_weight']>=.5];protect=p.FO in ['preservation','specific goal'] or p['FP-10'] in ['immediate','months'];pool=[] if gate or protect else aligned
 ip=[r for r in pool if r['layer'] in ['portfolio','philosophy','investment_horizon'] and r['strategy_id'] not in ['ST-33','ST-34']]
 th=[r for r in market if r['layer']=='trading_horizon'];setups=[r for r in market if r['layer']=='setup'];tp=bool(th and setups and any(r['layer'] in ['trading_horizon','setup'] for r in pool))
 ti=p.FO=='quick profit' and (bool(p.opportunity_search) or p['BP-15']=='high');ii=p.FO in ['wealth','purchasing power','independence','wealth management','income','replace job','small capital growth']
 if tp and ip:path='trading_candidate' if ti else 'investment_candidate' if ii else 'clarify_invest_vs_trade'
 elif tp:path='trading_candidate' if ti or p.FO=='quick profit' else 'clarify_invest_vs_trade'
 elif ip:path='investment_candidate' if ii else 'clarify_invest_vs_trade'
 else:path='foundation_only' if not market or gate else 'foundation_first_clarify_goal_or_bucket'
 def short(x):
  x=rank(x);return (x[0]['strategy_id'],pipe(r['strategy_id'] for r in x if x[0]['score']-r['score']<=8)) if x else ('','')
 pc,pa=short([r for r in ip if r['layer']=='portfolio']);ph,pha=short([r for r in ip if r['layer']=='philosophy']);hold,ha=short([r for r in market if r['layer']=='investment_horizon']);hc,hca=short(th);sc,sca=short(setups)
 selected='';comps=[]
 if path=='investment_candidate':
  selected=(ph or pc or hold) if p['BP-19']=='self' and not bool(p.low_maintenance) else (pc or ph or hold)
  if selected not in {r['strategy_id'] for r in ip}:selected=rank(ip)[0]['strategy_id']
  comps=[selected]+([hold] if ROLE[selected]=='philosophy' and hold and p['BP-19']=='self' else [])
 elif path=='trading_candidate':selected=hc;comps=[hc,sc]
 hybrid=pipe(r['strategy_id'] for r in market if r['strategy_id'] in ['ST-31','ST-32','ST-33','ST-34']);cond=parts(pipe(y for x in comps for y in parts(by[x]['conditions'])));training=pipe(y for x in comps for y in parts(by[x]['readiness_requirements']));prompts=[]
 if selected:cond+=['confirm_product_or_security_and_allocation'] if path=='investment_candidate' else ['confirm_holding_horizon_and_setup','confirm_costs_liquidity_and_execution_rules']
 if market and not selected:prompts+=['clarify_goal_and_separate_investable_bucket']
 if path=='investment_candidate' and (len(parts(pa))>1 or len(parts(pha))>1 or (pc and ph)):prompts+=['compare_management_and_investment_philosophy']
 if path=='trading_candidate':prompts+=['clarify_position_swing_intraday_horizon','compare_market_setups']
 if hybrid:prompts+=['confirm_separate_sleeves_before_hybrid']
 funding=bool(p.same_bucket_borrowed) or bool(p.obligation_uncertain) or bool(p.exposure_above_budget)
 controls=['protect_essential_funds','no_live_execution_authorization'];em=['EM-10']
 if selected:
  em+=['EM-08','EM-09']+(['EM-02','EM-07'] if path=='investment_candidate' else ['EM-05','EM-06']);controls+=['verify_ownership_and_liquidity','set_loss_budget_and_exposure_limits','review_diversification_and_costs']
  if selected in ['ST-13','ST-14','ST-15','ST-31']:em+=['EM-04' if p.FO in ['income','replace job'] else 'EM-03']
 if funding:controls+=['resolve_funding_or_existing_exposure_before_new_risk']
 if cf=='CF-21':controls+=['performance_review_before_new_risk'];prompts+=['review_negative_performance_and_rising_confidence']
 if bool(p.time_sensitive_review_delay):controls+=['no_time_critical_execution_before_review']
 if gate:controls+=['no_new_market_risk_under_current_profile']
 readiness='foundation_or_clarification' if not selected else 'preparation_and_verification' if training and cond else 'preparation_required' if training else 'verification_required' if cond else 'model_requirements_met'
 return rr,dict(persona_id=p.persona_id,financial_gate=gate,foundation_strategy=foundation,capital_status='blocked' if gate else 'verification_required' if funding or p['FP-10']=='undefined' else 'unallocated',uncommitted_capital_proxy=p.risk_budget,approved_new_market_allocation=0,financial_objective=p.FO,secondary_objective=p.secondary_goal,pathway=path,market_candidate=selected,market_components=pipe(comps),market_eligible_count=len(market),market_eligible=pipe(r['strategy_id'] for r in market),goal_aligned_candidates=pipe(r['strategy_id'] for r in aligned),portfolio_candidate=pc,portfolio_alternatives=pa,philosophy_candidate=ph,philosophy_alternatives=pha,investment_holding_candidate=hold,trading_horizon_candidate=hc,trading_horizon_alternatives=hca,setup_candidate=sc,setup_alternatives=sca,hybrid_alternatives=hybrid,management_preference=p['BP-19'],execution_methods=pipe(em),risk_controls=pipe(controls),readiness=readiness,verification=pipe(cond),training=training,questions_pending=pipe(prompts),live_execution_authorized=False)
def main():
 d=pd.read_csv(BASE/'personas.csv');splits=pd.read_csv(OLD/'split_manifest.csv');sm=splits.set_index('persona_id')['split'].to_dict();assert set(sm)==set(d.persona_id)
 rows=[];plans=[];cases=[];ce=[]
 def run(p,kind='core',key='',event='',state='',cf=''):
  rr,pl=evaluate(p,cf);sp=sm[p.persona_id];pl.update(split=sp,case_id=key or p.persona_id,case_type=kind,event=event,state=state)
  for r in rr:r.update(split=sp,case_id=pl['case_id'])
  (plans if kind=='core' else cases).append(pl);(rows if kind=='core' else ce).extend(rr)
 for _,p in d.iterrows():run(p)
 dyn=pd.read_csv(BASE/'dynamic_snapshots.csv');fx=pd.read_csv(BASE/'counterfactual_profiles.csv');meta=pd.read_csv(BASE/'counterfactual_fixtures.csv').set_index('fixture_id')
 for _,p in dyn.iterrows():run(p,'dynamic',f'{p.persona_id}:{p.event_id}:{p.state}',p.event_id,p.state)
 for _,p in fx.iterrows():run(p,'counterfactual',p.fixture_id,meta.loc[p.fixture_id,'test_conflict'],'after',meta.loc[p.fixture_id,'test_conflict'])
 ev=pd.DataFrame(rows);plan=pd.DataFrame(plans);cases=pd.DataFrame(cases);ce=pd.DataFrame(ce);base=plan.set_index('persona_id');dr=[];fr=[]
 for (pid,event),g in cases[cases.case_type=='dynamic'].groupby(['persona_id','event']):
  b=g[g.state=='before'].iloc[0];a=g[g.state=='after'].iloc[0];E0=set(parts(b.market_eligible));E1=set(parts(a.market_eligible));rb0=b.uncommitted_capital_proxy;rb1=a.uncommitted_capital_proxy
  ok={'DT-01':rb1<=rb0+.01 and E1<=E0,'DT-02':rb1>=rb0-.01,'DT-03':rb1<=rb0+.01,'DT-04':rb1<=rb0+.01,'DT-05':rb1>=rb0-.01,'DT-06':E0==E1,'DT-07':E0==E1,'DT-08':rb1<=rb0+.01,'DT-09':rb1==rb0,'DT-10':rb1<=rb0+.01}[event]
  dr.append(dict(persona_id=pid,event=event,split=b['split'],before_path=b.pathway,after_path=a.pathway,before_candidate=b.market_candidate,after_candidate=a.market_candidate,before_eligible=len(E0),after_eligible=len(E1),eligible_set_changed=E0!=E1,capital_before=rb0,capital_after=rb1,readiness_changed=b.readiness!=a.readiness,passed=ok))
 for _,a in cases[cases.case_type=='counterfactual'].iterrows():
  b=base.loc[a.persona_id];cf=a.event;ok=(not a.market_candidate and a.financial_gate) if cf=='CF-13' else ('performance_review_before_new_risk' in a.risk_controls) if cf=='CF-21' else ('no_time_critical_execution_before_review' in a.risk_controls and not any(x in parts(a.market_eligible) for x in ['ST-28','ST-29']))
  fr.append(dict(fixture_id=a.case_id,persona_id=a.persona_id,split=a['split'],conflict=cf,before_candidate=b.market_candidate,after_candidate=a.market_candidate,controls=a.risk_controls,passed=ok))
 dr=pd.DataFrame(dr);fr=pd.DataFrame(fr)
 for sp in ['development','validation','holdout']:
  for k,x in [('plans',plan),('evaluations',ev),('stress_plans',cases),('stress_evaluations',ce),('dynamic_checks',dr),('counterfactual_checks',fr)]:x[x.split==sp].to_csv(OUT/f'{k}_{sp}.csv',index=False)
 allp=pd.concat([plan,cases]);alle=pd.concat([ev,ce]);lookup=alle.set_index(['case_id','strategy_id']).status.to_dict();bad=[(r.case_id,s) for r in allp.itertuples() for s in parts(r.market_components) if lookup.get((r.case_id,s)) not in A]
 checks={'baseline_integrity':integrity(),'unique_core_pairs':len(ev)==175000 and not ev.duplicated(['persona_id','strategy_id']).any(),'one_plan_each':len(plan)==5000 and plan.persona_id.is_unique,'split_preserved':plan.split.equals(plan.persona_id.map(sm)),'stress_inherits_parent_split':cases.split.equals(cases.persona_id.map(sm)),'stress_pairs_complete':len(ce)==35875 and not ce.duplicated(['case_id','strategy_id']).any(),'no_blocked_components':not bad,'no_market_candidate_when_financial_gate':not allp.loc[allp.financial_gate,'market_candidate'].astype(bool).any(),'no_live_authorization':bool((allp.approved_new_market_allocation==0).all() and not allp.live_execution_authorized.any()),'score_range':bool(alle.score.between(0,100).all()),'foundation_present':bool(allp.foundation_strategy.str.match(r'ST-0[0-4]').all()),'trading_composite':bool(allp.loc[allp.pathway=='trading_candidate','market_components'].map(lambda x:len(parts(x))==2 and ROLE[parts(x)[0]]=='trading_horizon' and ROLE[parts(x)[1]]=='setup').all()),'counterfactual_checks':bool(fr.passed.all()),'dynamic_checks':bool(dr.passed.all())}
 pd.DataFrame([{'check':k,'passed':v} for k,v in checks.items()]).to_csv(OUT/'checks.csv',index=False)
 dev=plan[plan.split!='holdout'];de=ev[ev.split!='holdout'];old=pd.concat([pd.read_csv(OLD/f'plans_{s}.csv') for s in ['development','validation']]);summary={'core_personas':len(plan),'core_evaluations':len(ev),'stress_snapshots':len(cases),'stress_evaluations':len(ce),'split_counts':plan.split.value_counts().to_dict(),'development_validation_only':{'personas':len(dev),'v1_market_primary':int((old.primary_strategy.str[3:].astype(int)>=5).sum()),'market_eligible_personas':int((dev.market_eligible_count>0).sum()),'pathways':dev.pathway.value_counts().to_dict(),'candidate_count':int(dev.market_candidate.astype(bool).sum()),'candidate_ids':dev.loc[dev.market_candidate!='','market_candidate'].value_counts().to_dict(),'foundation_counts':dev.foundation_strategy.value_counts().to_dict(),'readiness':dev.readiness.value_counts().to_dict(),'strategy_eligible_count':int(de.loc[de.status.isin(A),'strategy_id'].nunique()),'component_ids':dict(Counter(x for z in dev.market_components for x in parts(z))),'layer_candidate_counts':{c:int(dev[c].astype(bool).sum()) for c in ['portfolio_candidate','philosophy_candidate','investment_holding_candidate','trading_horizon_candidate','setup_candidate','hybrid_alternatives']},'status_counts':de.status.value_counts().to_dict()},'dynamic':{'passed':int(dr.passed.sum()),'total':len(dr),'candidate_changed':int((dr.before_candidate!=dr.after_candidate).sum()),'eligible_set_changed':int(dr.eligible_set_changed.sum()),'pathway_changed':int((dr.before_path!=dr.after_path).sum()),'readiness_changed':int(dr.readiness_changed.sum()),'by_event':dr.groupby('event').passed.agg(['sum','count']).astype(int).to_dict('index')},'fixtures':{'passed':int(fr.passed.sum()),'total':len(fr)},'checks':checks}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));reg2=reg.copy();reg2['layer']=reg2.id.map(ROLE);reg2.to_csv(OUT/'strategy_register.csv',index=False);splits.to_csv(OUT/'split_manifest.csv',index=False)
 cov=de.groupby(['strategy_id','status']).size().unstack(fill_value=0);cov['candidate_count']=dev.market_candidate.value_counts().reindex(cov.index,fill_value=0);cov['component_count']=pd.Series(summary['development_validation_only']['component_ids']).reindex(cov.index,fill_value=0);cov['foundation_count']=dev.foundation_strategy.value_counts().reindex(cov.index,fill_value=0);cov.to_csv(OUT/'strategy_coverage.csv')
if __name__=='__main__':main()
