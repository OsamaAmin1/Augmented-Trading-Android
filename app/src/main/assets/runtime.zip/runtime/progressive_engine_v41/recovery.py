"""V4.1 bounded recovery wrapper. Explicit evidence and acknowledgement required.
Never substitutes a hidden persona for user input. Prior engine is unchanged.
"""
from pathlib import Path
import importlib.util,sys,hashlib,json,math,numbers
import numpy as np,pandas as pd
ROOT=Path(__import__('os').environ['PROJECT_ROOT']); HERE=Path(__file__).parent
s=importlib.util.spec_from_file_location('v40',ROOT/'progressive_engine_v4/build.py'); V=importlib.util.module_from_spec(s);sys.modules[s.name]=V;s.loader.exec_module(V)
NUM='monthly_income monthly_expenses monthly_debt_payment debt_principal debt_annual_rate investment_savings earmarked_savings emergency_reserve_separate invested_from_savings primary_goal_weight'.split()
BOOL=['debt_overdue']+V.EXTRA[V.EXTRA.index('verification_preference'):]
# Explicit domain types for the fields that determine financial and strategy safety.
ENUM={'FP-08':{'savings','surplus','inheritance','asset sale','borrowed'},'FP-10':{'immediate','months','year','years','undefined'},'FP-12':{'none','supplemental','essential'},'FO':V.DOM['FO'],'secondary_goal':V.DOM['secondary_goal'],'BP-01':{'very conservative','conservative','balanced','adventurous','risk seeking'},'BP-19':V.DOM['mode'],'PC-05':V.DOM['time'],'PC-06':V.DOM['timing'],'PC-07':V.DOM['intervention'],'KL':{f'KL-{i:02}' for i in range(9)},'EX':{f'EX-{i:02}' for i in range(8)}}
PENDING={'answer_conflict_requires_clarification','reference_reassessment_requires_clarification','discovery_unresolved'}
def plain(x):
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,set):return sorted(plain(v) for v in x)
 if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [plain(v) for v in x]
 return x
def digest(x):return hashlib.sha256(json.dumps(plain(x),sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()
def real(x):return isinstance(x,numbers.Real) and not isinstance(x,(bool,np.bool_)) and math.isfinite(x)
def valid(first,full,gs):
 if not isinstance(first,dict) or not isinstance(full,dict) or not isinstance(gs,list):return 'structured_intake_pending'
 if any(k not in first or k not in full for k in V.FIRST) or any(k not in full or full[k] is None for k in V.FIELDS):return 'missing_required_input'
 for k in NUM:
  if not real(full[k]) or not real(first[k]) or min(first[k],full[k])<0:return 'invalid_numeric:'+k
 for k in BOOL:
  if not isinstance(full[k],(bool,np.bool_)):return 'invalid_boolean:'+k
 if not isinstance(first['debt_overdue'],(bool,np.bool_)):return 'invalid_boolean:debt_overdue'
 for k,vals in ENUM.items():
  if not isinstance(full[k],str) or full[k] not in vals:return 'invalid_category:'+k
 if any(not isinstance(full[k],str) or not full[k].strip() for k in V.FIELDS if k not in NUM+BOOL):return 'invalid_text'
 if any(full[k]!=first[k] for k in V.FIRST):return 'changed_financial_intake_restart'
 if V.initial_input(first)[0] is None:return 'invalid_financial_intake'
 if len(gs)!=2 or not all(isinstance(g,dict) and all(k in g for k in V.GF) for g in gs):return 'invalid_goal_count'
 if not all(isinstance(g['goal_id'],str) and g['goal_id'] for g in gs) or gs[0]['goal_id']==gs[1]['goal_id']:return 'invalid_goal_id'
 for j,g in enumerate(gs):
  if not all(real(g[k]) for k in ['weight','months','target_today','withdrawal']) or not isinstance(g['real_target'],(bool,np.bool_)):return 'invalid_goal_type'
  if not 1<=g['months']<=600 or int(g['months'])!=g['months'] or g['target_today']<=0 or g['withdrawal']<0:return 'invalid_goal_value'
  if g['goal']!=[full['FO'],full['secondary_goal']][j] or abs(g['weight']-[full['primary_goal_weight'],1-full['primary_goal_weight']][j])>1e-8:return 'goal_profile_mismatch'
 return None

def prepare(i,first,full,gs,sid):
 """Create review requirements from actual supplied inputs. No allocation is released."""
 error=valid(first,full,gs)
 if error:return dict(status=error)
 reason=i['z'].get('reason','')
 if i['unresolved'] or reason in {'missing_intake','missing_answer','contradictory_answers'}:return dict(status='discovery_evidence_incomplete_restart')
 try:
  p=V.materialize(full,sid);d=V.rel.truth(p);a=V.opt.atoms(p)
  # A correction to a verified eligibility answer must restart the assessment.
  for qid,answer,_ in i['z'].get('trace',[]):
   q=V.QM[qid]
   if q.priority=='eligibility' and (answer not in (0,1) or int(d[q.field] in q.yes)!=answer):return dict(status='eligibility_conflict_restart')
  discrepancies=[]
  for k,allowed in sorted(i['domains'].items()):
   if d[k] not in allowed:discrepancies.append(dict(id='domain:'+k,previous=plain(allowed),proposed=plain(d[k])))
  for j,(typ,k,ys,v) in enumerate(i['supp']):
   actual=d[k] in set(ys) if typ=='field' else a[k]
   if actual!=v:discrepancies.append(dict(id=f'supplement:{j}:{k}',previous=plain(v),proposed=plain(actual)))
  ee,pl=V.evaluate(p);proposal=[pl['foundation_strategy'],pl['pathway'],pl['market_components']];original=[i['z'][k] for k in ['foundation','pathway','components']]
  if not i['z']['confirmed'] and reason not in {'budget','no_relevant_question'}:return dict(status='discovery_evidence_incomplete_restart')
  if not discrepancies and proposal==original and i['z']['confirmed']:return dict(status='unchanged')
  token=digest(dict(session=sid,first=first,full=full,goals=gs,evidence=i['domains'],supp=i['supp'],logs=i['logs'],proposal=proposal,discrepancies=discrepancies))
  return dict(status='review_required',token=token,discrepancies=discrepancies,proposal=proposal,original=original,changed_strategy=proposal!=original,financial_gate=bool(pl['financial_gate']))
 except (ValueError,KeyError,TypeError,AttributeError,IndexError,OverflowError) as exc:return dict(status='invalid_profile:'+str(exc))

def finalize(i,first,full,gs,sid,approval=None):
 """Approval must explicitly confirm each discrepancy and the revised proposal.
 A fresh digest is recomputed to prevent reuse after a changed input snapshot.
 A digest is not authentication: application must bind it to authenticated session.
 """
 review=prepare(i,first,full,gs,sid)
 if review['status']=='unchanged':return (*V.finalize(i,first,full,gs,sid),review)
 if review['status']!='review_required':return None,[],[],review['status'],review
 if not isinstance(approval,dict):return None,[],[],'clarification_pending',review
 required={c['id'] for c in review['discrepancies']}
 if approval.get('token')!=review['token'] or approval.get('accept_proposal') is not True or approval.get('accept_structured_profile') is not True or not isinstance(approval.get('confirmed_discrepancies'),list) or not all(isinstance(k,str) for k in approval['confirmed_discrepancies']) or len(approval['confirmed_discrepancies'])!=len(required) or set(approval['confirmed_discrepancies'])!=required:return None,[],[],'clarification_not_accepted',review
 # Recompute from the explicitly confirmed structured profile; do not reuse the original candidate.
 try:
  p=V.materialize(full,sid);ee,pl=V.evaluate(p);out,g,s=V.integ.run(p,pd.Series(pl),pd.DataFrame(ee).set_index('strategy_id'),gs)
  if out['live_authorized'] or out['approved_allocation']!=0 or (out['market_alloc']>.05 and (out['financial_gate'] or out['joint_gates'])) or not V.parts(out['active_components'])<=V.parts(out['eligible_after_controls']):return None,[],[],'recomputed_plan_failed_safety',review
  return out,g,s,'conditional_plan_after_clarification',review
 except (ValueError,KeyError,TypeError,AttributeError,IndexError,OverflowError):return None,[],[],'recomputed_plan_invalid',review
