"""Adaptive empirical question selection. No access to evaluation labels at inference."""
import numpy as np
from collections import Counter
from dataclasses import dataclass

MARKET={f'ST-{i:02}' for i in range(5,35)}
UNKNOWN='UNRESOLVED'
def parts(s):return set(s.split('|')) if s else set()

def financial_intake(p):
    # These 12 explicitly supplied inputs are not binary questions.
    fields=['monthly_income','monthly_expenses','monthly_debt_payment','debt_principal','debt_annual_rate','debt_overdue','investment_savings','earmarked_savings','emergency_reserve_separate','FP-08','FP-10','FP-12']
    if any(k not in p or p[k] is None for k in fields):return None
    e=p['monthly_expenses']+p['monthly_debt_payment']; s=round(p['monthly_income']-e,2)
    if e<=0 or min(p[k] for k in fields[:5]+fields[6:9])<0:return None
    if p['FP-08'] not in ['savings','surplus','inheritance','asset sale','borrowed'] or p['FP-10'] not in ['immediate','months','year','years','undefined'] or p['FP-12'] not in ['none','supplemental','essential']:return None
    m=p['emergency_reserve_separate']/e; budget=round(max(0,p['investment_savings']-p['earmarked_savings']-6*max(0,-s)),2)
    debt=p['debt_principal']>0 and (p['debt_overdue'] or p['debt_annual_rate']>=.20)
    blocked=bool(budget<=0 or p['FP-08']=='borrowed' or debt or p['FP-10']=='immediate' or m<1)
    cap=0 if blocked else 3 if m>=6 and s>0 and p['FP-10']=='years' and p['FP-12']!='essential' and budget>=3*e else 2 if m>=3 and s>=0 and p['FP-10'] in ['year','years'] and p['FP-12']!='essential' and budget>=e else 1
    # known answer bits A=1. B=0. Never consult profile answers for these facts.
    known={0:int(debt),1:int(p['FP-08']=='borrowed'),2:int(p['FP-10']=='immediate'),3:int(m<1),4:int(p['FP-12']=='essential'),5:int(budget<=0),7:int(p['FP-10'] in ['immediate','months']),8:int(p['FP-10'] in ['immediate','months','year']),9:int(m<3)}
    return dict(blocked=blocked,capacity=cap,horizon=p['FP-10'],known=known,inputs=len(fields))

@dataclass
class Node:
    ids:np.ndarray
    q:int=-1
    a:object=None
    b:object=None
    gain:float=0.

class Model:
    def __init__(self,X,labels,intakes,register,exclusions,depth=24):
        self.X=X.astype(np.int32);self.labels=labels;self.register=register;self.exclusions=exclusions;self.depth=depth
        # Joint pathway+composition label prevents contradictory output. Readiness separate.
        self.keys=['foundation','mandate','readiness']; self.weights=[1.,2.,.65]
        self.enc=[];self.vals=[];self.hot=[]
        for k in self.keys:
            vals,enc=np.unique(labels[k],return_inverse=True);self.vals.append(vals);self.enc.append(enc);self.hot.append(np.eye(len(vals),dtype=np.float32)[enc])
        self.groups={}
        for cap in range(4):
            ids=np.array([i for i,t in enumerate(intakes) if t is not None and t['capacity']==cap]);
            if not len(ids):continue
            # Known intake partitions can be used to select cohort without questions.
            for horizon in sorted({intakes[i]['horizon'] for i in ids}):
                ix=np.array([i for i in ids if intakes[i]['horizon']==horizon]); t=intakes[ix[0]]
                self.groups[(cap,horizon)]=self.fit(ix,set(t['known']),0)
            self.groups[(cap,'*')]=self.fit(ids,set(intakes[ids[0]]['known']),0)
    @staticmethod
    def ent(counts):
        p=counts/np.maximum(1,counts.sum(axis=-1,keepdims=True));return -(p*np.log2(np.maximum(p,1e-30))).sum(axis=-1)
    def fit(self,ids,used,d):
        node=Node(ids);n=len(ids)
        if d>=self.depth or n<10:return node
        x=self.X[ids];na=x.sum(0);nb=n-na
        avail=np.ones(x.shape[1],dtype=bool);avail[list(used)]=False;avail&=(na>=4)&(nb>=4)
        if not avail.any():return node
        # require basic readiness screen on all paths; reject-any-loss verification for open paths.
        forced=[48,51] # BQ-049 and BQ-052 (knowledge and actual experience)
        if d==0 and 64 not in used and not np.all(self.labels['mandate'][ids]=='foundation_only::'):forced=[64]+forced
        q=next((v for v in forced if v not in used and avail[v]),None)
        scores=np.zeros(x.shape[1]); xf=x.astype(np.float32).T
        for weight,hot in zip(self.weights,self.hot):
            y=hot[ids];total=y.sum(0);a=xf@y;b=total-a
            scores+=weight*(self.ent(total)-na/n*self.ent(a)-nb/n*self.ent(b))
        scores[~avail]=-np.inf
        if q is None:q=int(np.argmax(scores))
        if not np.isfinite(scores[q]) or (scores[q]<.0001 and q not in forced):return node
        node.q=q;node.gain=float(scores[q]);node.a=self.fit(ids[x[:,q]==1],used|{q},d+1);node.b=self.fit(ids[x[:,q]==0],used|{q},d+1);return node
    def distribution(self,node,key,excluded):
        labels=self.labels[key][node.ids];count=Counter(labels);n=len(labels)
        if key=='mandate':
            # Do not re-normalize after exclusion: mass of incompatible answers remains uncertainty.
            count={k:v for k,v in count.items() if not (parts(k.split('::')[1])&excluded)}
        return sorted([(k,v/n) for k,v in count.items()],key=lambda z:(-z[1],z[0]))
    def assess(self,intake,answer,cap=12,threshold=.8,mandate_threshold=.65,final_guard=True):
        # answer(q) -> 1,0,None. Unanswered is not evidence. A missing branch ends safely.
        base=dict(questions=0,trace=[],foundation=UNKNOWN,mandate=UNKNOWN,readiness=UNKNOWN,foundation_top=UNKNOWN,mandate_top=UNKNOWN,readiness_top=UNKNOWN,shortlist=[],excluded=[],live_authorized=False,approved_allocation=0,stop_reason='',financial_state='unverified',intake_fields=0,readiness_screen=False,reference_gate_pred=None,conditional_candidate=False)
        if intake is None:base.update(stop_reason='missing_verified_financial_intake',readiness='verification_required');return base
        base.update(financial_state='blocked' if intake['blocked'] else 'intake_gate_clear_not_execution_clearance',intake_fields=intake['inputs'],reference_gate_pred=intake['blocked'])
        excluded={s for s in MARKET if self.register[s]['min_capacity']>intake['capacity'] or (self.register[s]['horizon']=='long' and intake['horizon'] in ['immediate','months','year']) or (self.register[s]['horizon']=='medium' and intake['horizon'] in ['immediate','months'])}
        if intake['blocked']:excluded|=MARKET
        for q,a in intake['known'].items():
            if a:excluded|=self.exclusions.get(q,set())
        node=self.groups.get((intake['capacity'],intake['horizon']),self.groups.get((intake['capacity'],'*')))
        if node is None:base.update(stop_reason='unsupported_intake_group',excluded=sorted(excluded),readiness='verification_required');return base
        seen={}; trace=[];reason='question_cap';missing=False
        while True:
            f=self.distribution(node,'foundation',excluded);m=self.distribution(node,'mandate',excluded);r=self.distribution(node,'readiness',excluded)
            screen=48 in seen and 51 in seen and seen[48] is not None and seen[51] is not None
            verified_loss=intake['blocked'] or (64 in seen and seen[64] is not None)
            # Known block always overrides inference. Loss rejection eliminates all market strategies.
            if intake['blocked']:f=[('ST-00',1.)];m=[('foundation_only::',1.)]
            confident=screen and verified_loss and f and m and r and f[0][1]>=threshold and m[0][1]>=mandate_threshold and r[0][1]>=threshold and len(node.ids)>=8
            if confident:reason='confidence_threshold';break
            if len(trace)>=cap:reason='question_cap';break
            if node.q<0:reason='insufficient_support';break
            q=node.q; a=answer(q);trace.append((q,a,round(node.gain,6),len(node.ids)));seen[q]=a
            if a not in (0,1):missing=True;reason='unanswered_question';break
            if a==1:
                excluded|=self.exclusions.get(q,set())
                if q in [64,23]:excluded|=MARKET
                if q==66 and intake['horizon'] in ['immediate','months']:excluded|=MARKET
            node=node.a if a else node.b
        # Require readiness evidence even when rare cohorts do not contain a valid split.
        for q in [48,51]:
            if q not in seen and len(trace)<cap and not missing:
                a=answer(q);trace.append((q,a,0.,len(node.ids)));seen[q]=a
                if a not in (0,1):missing=True
        screen=all(seen.get(q) in (0,1) for q in [48,51]);verified_loss=intake['blocked'] or seen.get(64) in (0,1)
        f=self.distribution(node,'foundation',excluded);m=self.distribution(node,'mandate',excluded);r=self.distribution(node,'readiness',excluded)
        if intake['blocked']:f=[('ST-00',1.)];m=[('foundation_only::',1.)]
        if not intake['blocked'] and not verified_loss:
            # No inferred market proposal without explicit loss acceptance evidence.
            m=[(k,v) for k,v in m if not parts(k.split('::')[1])]
        def top(dist):return dist[0][0] if dist else UNKNOWN
        def pick(dist,t):return dist[0][0] if dist and dist[0][1]>=t and len(node.ids)>=8 else UNKNOWN
        foundation='ST-00' if intake['blocked'] else pick(f,threshold)
        mandate='foundation_only::' if intake['blocked'] else pick(m,mandate_threshold)
        readiness=pick(r,threshold) if screen else UNKNOWN
        # Candidate-specific verification: not a financial approval. Guard uses only asked or verified inputs.
        if missing:
            mandate=UNKNOWN
        if final_guard and mandate!=UNKNOWN and parts(mandate.split('::')[1]):
            components=parts(mandate.split('::')[1]); specs=[self.register[s] for s in components]
            demand=max(1,max(x['risk_demand'] for x in specs)); required=[22+demand] # zero-based BQ-024..027
            if any(x['management']=='self' for x in specs):required.append(27)
            if any(x['monitor']=='daily' for x in specs):required.extend([29,32])
            if any(x['monitor']=='intraday' for x in specs):required.extend([30,31,33,69])
            if intake['horizon']=='months':required.append(66)
            for q in dict.fromkeys(required):
                if q not in seen:
                    if len(trace)>=cap:mandate=UNKNOWN;reason='candidate_verification_budget';break
                    a=answer(q);trace.append((q,a,0.,len(node.ids)));seen[q]=a
                a=seen[q]
                if a!=0:
                    if a==1:
                        excluded|=self.exclusions.get(q,set())
                        if 23<=q<=26:excluded|={s for s in MARKET if max(1,self.register[s]['risk_demand'])>=q-22}
                    mandate=UNKNOWN;reason='candidate_verification_failed_or_missing';break
        # readiness must be conservative when evidence missing; explicit classification separate from statistical label
        readiness_assessment=readiness if readiness!=UNKNOWN else 'verification_and_readiness_review_required'
        base.update(questions=len(trace),trace=trace,foundation=foundation,mandate=mandate,readiness=readiness,readiness_assessment=readiness_assessment,foundation_top=top(f),mandate_top=top(m),readiness_top=top(r),foundation_confidence=f[0][1] if f else 0,mandate_confidence=m[0][1] if m else 0,readiness_confidence=r[0][1] if r else 0,shortlist=[k for k,v in m[:3] if v>=.10],excluded=sorted(excluded),stop_reason=reason,readiness_screen=screen,conditional_candidate=bool(mandate!=UNKNOWN and parts(mandate.split('::')[1])),leaf_support=len(node.ids))
        return base
