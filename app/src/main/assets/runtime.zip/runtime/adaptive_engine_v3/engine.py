"""Rule-based partial evidence engine. No persona rows or reference labels at inference."""
import numpy as np
from dataclasses import dataclass
import math
GOALS=['preservation','purchasing power','income','replace job','specific goal','quick profit','small capital growth','wealth','wealth management','independence']
DOM={'FO':GOALS,'secondary_goal':GOALS,'risk':list(range(5)),'mode':['delegate','shared','self'],'time':['none','limited','moderate','high'],'timing':['session','after session','variable'],'intervention':['immediate','delayed','unavailable'],'KL':list(range(9)),'EX':list(range(8))}
FLAGS=['reject_any_loss','same_bucket_liquidity','obligation_uncertain','same_bucket_borrowed','low_maintenance','control_every_decision','time_sensitive_review_delay','opportunity_search','activity','security_motive','planning','patience','fundamental','verification','rules','patterns','quantitative','fast','adaptive','diversification_preference','long_hold_preference','value_preference','growth_preference','trend_interest','evidence_contrarian','news_monitoring','difficulty_stopping','rely_entirely_on_tips','unrealistic_expectations','discipline_problem','inflation_concern','no_learning_time']
for f in FLAGS:DOM[f]=[False,True]
@dataclass
class Question:
 id:str; field:str; yes:tuple; scenario:str; a:str; b:str; priority:str='preference'

def bank():
 q=[]
 def add(id,f,yes,scenario,a,b,priority='preference'):q.append(Question(id,f,tuple(yes),scenario,a,b,priority))
 # balanced goal partitions; include existing splits and new missing splits
 for f,prefix in [('FO','G'),('secondary_goal','S')]:
  for i,ys in enumerate([GOALS[:5],GOALS[:2],GOALS[2:4],[GOALS[0]],[GOALS[2]],[GOALS[4]],GOALS[5:7],[GOALS[5]],GOALS[7:9],[GOALS[7]],[GOALS[9]]]):
   a=' / '.join(ys); b=' / '.join(x for x in GOALS if x not in ys)
   add(f'R{prefix}-{i+1:02}',f,ys,'Which group contains your '+('most important' if f=='FO' else 'second')+' financial objective?',a,b,'objective')
 for i in range(4):add(f'BQ-{24+i:03}','risk',range(i+1),'What level of market fluctuation could you accept within verified limits?', ['Very conservative','Conservative or less','Balanced or less','Adventurous or less'][i],'A higher level than this','eligibility')
 for id,f,ys,a,b in [('BQ-028','mode',['delegate'],'Delegate decisions','Share or make decisions'),('BQ-029','mode',['self'],'Make decisions myself','Share or delegate'),('BQ-030','time',['none'],'No review time','Some review time'),('BQ-031','time',['none','limited','moderate'],'Less than high availability','High availability'),('RT-01','time',['none','limited'],'At most limited time','Moderate or high time'),('BQ-032','timing',['after session','variable'],'Outside session or variable','During market session'),('BQ-033','intervention',['unavailable'],'Cannot intervene','Can intervene'),('BQ-034','intervention',['delayed','unavailable'],'Cannot act immediately','Can act immediately')]:add(id,f,ys,'Imagine your investment needs attention. Which is closer to your actual circumstances?',a,b,'eligibility')
 for f,nums,ids in [('KL',[2,4,6,8],[48,49,50,51]),('EX',[3,5,7],[52,53,54])]:
  for k,i in zip(nums,ids):add(f'BQ-{i:03}',f,range(k),'Which best describes your current '+('knowledge' if f=='KL' else 'experience')+' level?',f'Below modeled level {k}',f'At or above modeled level {k}','readiness')
 # Additional exact thresholds for readiness (levels are internal; wording requires usability review)
 for f in ['KL','EX']:
  for k in range(1,len(DOM[f])):
   if k not in ([2,4,6,8] if f=='KL' else [3,5,7]):add(f'R-{f}-{k}',f,range(k),'Which describes your current demonstrated level?',f'Below level {k}',f'At or above level {k}','readiness')
 texts={'reject_any_loss':('Even diversified investments can lose money.','I cannot accept any loss.','I can accept some loss within verified limits.'),'same_bucket_liquidity':('A near-term bill comes due.','It needs the same capital.','It is funded separately.'),'obligation_uncertain':('Before investing, review upcoming obligations.','Important obligations are unknown.','I can account for them.'),'same_bucket_borrowed':('Consider the proposed capital pool.','Some money is borrowed.','All funds are owned.'),'control_every_decision':('An investment manager makes a decision.','I need to control every decision.','I can accept a delegated decision.'),'security_motive':('What primarily motivates you?','Security.','Another motivation.'),'discipline_problem':('Review your typical trading habits.','I have difficulty with discipline, impulsivity or revenge trading.','These are not currently observed.')}
 old={'reject_any_loss':65,'same_bucket_liquidity':67,'obligation_uncertain':7,'same_bucket_borrowed':69,'low_maintenance':56,'time_sensitive_review_delay':70,'opportunity_search':59,'activity':36,'patience':35,'value_preference':57,'growth_preference':58,'trend_interest':60,'evidence_contrarian':61,'news_monitoring':62,'difficulty_stopping':63,'rely_entirely_on_tips':66,'inflation_concern':55,'no_learning_time':68}
 for i,f in enumerate(FLAGS):
  s,a,b=texts.get(f,('When planning investments, which describes you more closely?',f'I identify with {f.replace("_"," ")}.',f'I do not identify with {f.replace("_"," ")}.'))
  add(f'BQ-{old[f]:03}' if f in old else f'RF-{i+1:02}',f,[True],s,a,b,'eligibility' if f in ['reject_any_loss','same_bucket_liquidity','obligation_uncertain','same_bucket_borrowed','control_every_decision','time_sensitive_review_delay'] else 'preference')
 return q
Q=bank()
class Engine:
 def __init__(self,reg):
  self.reg=reg; self.n=len(reg); self.kinds=np.array([s['kind'] for s in reg]); self.roles=np.array([s['layer'] for s in reg]);self.risk=np.array([s['risk_demand'] for s in reg]);self.cap=np.array([s['min_capacity'] for s in reg]);self.h=np.array([s['horizon'] for s in reg]);self.mon=np.array([s['monitor'] for s in reg]);self.mode=np.array([s['management'] for s in reg]); self.goals=np.array([[g in s['goals'].split('|') for s in reg] for g in GOALS],float);self.sig=[s['signals'].split('|') if s['signals'] else [] for s in reg]; self.market=np.arange(35)>=5
 def state(self,t,extra):
  d={k:set(v) for k,v in DOM.items()};d['FO']=set(GOALS);d['secondary_goal']=set(GOALS);return d
 def calc(self,d,t,e):
  h=t['horizon']; short=h in ['immediate','months']; cap=t['capacity']; w=e['weight']; exp=e['exposure'];
  # eligibility: possible vs guaranteed over remaining domains, independent of preference score
  possible=np.ones(35,bool); supported=np.ones(35,bool)
  def req(mask,field,valid):
   vals=d[field]; v=set(valid); possible[mask]&=bool(vals&v);supported[mask]&=vals<=v
  if t['blocked']:possible[5:]=False;supported[5:]=False
  possible[5:] &= self.cap[5:]<=cap;supported[5:] &= self.cap[5:]<=cap
  for n in range(1,5):
   if n==3 and (t['blocked'] and (e['budget']<=0 or t['known'][0] or t['known'][1] or h=='immediate')):possible[n]=supported[n]=False
  if not t['blocked'] and not exp:
   # readiness strategy eligible only with a funding/obligation issue
   poss=True in d['obligation_uncertain'] or True in d['same_bucket_borrowed']; sure=d['obligation_uncertain']=={True} or d['same_bucket_borrowed']=={True}
   possible[0]=poss;supported[0]=sure
  if not(short or h=='year'):req(4,'FO',['specific goal'])
  req(self.market,'reject_any_loss',[False]);req(self.market,'risk',[1,2,3,4]);
  if short:req(self.market,'same_bucket_liquidity',[False])
  for r in range(1,5):req(self.market&(self.risk==r),'risk',range(r,5))
  if h in ['immediate','months','year']:possible[self.market&(self.h=='long')]=False;supported[self.market&(self.h=='long')]=False
  if short:possible[self.market&(self.h=='medium')]=False;supported[self.market&(self.h=='medium')]=False
  intr=self.market&(self.mon=='intraday'); daily=self.market&(self.mon=='daily')
  req(intr,'time',['high']);req(intr,'timing',['session']);req(intr,'intervention',['immediate']);req(daily,'time',['limited','moderate','high']);req(daily,'intervention',['immediate','delayed']);req(self.market&(self.mode=='self'),'mode',['shared','self'])
  # delegation rejection only when both conditions apply
  m=self.market&(self.mode=='delegate'); possible[m]&=not(d['mode']=={'self'} and d['control_every_decision']=={True});supported[m]&=not('self' in d['mode'] and True in d['control_every_decision'])
  req(np.array([i in [28,29] for i in range(35)]),'time_sensitive_review_delay',[False]);
  for i in [32,33,34]:
   possible[i]&=possible[5:18].any();supported[i]&=supported[5:18].any()
   if i==33:
    for r in ['trading_horizon','setup']:possible[i]&=possible[self.roles==r].any();supported[i]&=supported[self.roles==r].any()
  # compute interval additive score bounds and direct goal alignment
  G=[];D=[]
  for f in ['FO','secondary_goal']:
   ix=[GOALS.index(g) for g in d[f]];direct=self.goals[ix]; fallback=np.array([[.25 if GOALS[j]!='quick profit' and k in ['foundation','investing','hybrid'] else .1 for k in self.kinds] for j in ix]);a=np.where(direct,direct,fallback);G.append((a.min(0),a.max(0)));D.append((direct.min(0),direct.max(0)))
  dlo=w*D[0][0]+(1-w)*D[1][0];dhi=w*D[0][1]+(1-w)*D[1][1];lo=30*(w*G[0][0]+(1-w)*G[1][0]);hi=30*(w*G[0][1]+(1-w)*G[1][1]);
  v=np.array([20*np.maximum(0,1-.35*np.maximum(0,self.risk-r)) for r in d['risk']]);lo+=v.min(0);hi+=v.max(0)
  hf=np.where((self.h=='flexible')|((self.h=='long')&(h=='years'))|((self.h=='medium')&(h in ['year','years']))|((self.h=='trade')&(h in ['year','years','undefined'])),1.,.5)
  v=[]
  for tm in d['time']:
   for ti in d['timing']:
    for it in d['intervention']:
     mf=np.where((self.mon=='none')|((self.mon=='low')&(tm!='none'))|((self.mon=='daily')&(tm in ['moderate','high']))|((self.mon=='intraday')&(tm=='high')&(ti=='session')&(it=='immediate')),1.,.5 if tm!='none' else 0.)
     v.append(15*(.55*hf+.45*mf))
  v=np.array(v);lo+=v.min(0);hi+=v.max(0)
  v=np.array([15*np.where((self.mode=='any')|(self.mode==md),1.,np.where((md=='shared')|(self.mode=='shared'),.75,.45)) for md in d['mode']]);lo+=v.min(0);hi+=v.max(0)
  def signal(k):
   if k=='security':return {a or b<=1 for a in d['security_motive'] for b in d['risk']}
   if k=='liquidity':return {short}
   if k=='income':return {g in ['income','replace job'] or s=='income' for g in d['FO'] for s in d['secondary_goal']}
   if k=='shortgoal':return {short or h=='year' or g=='specific goal' for g in d['FO']}
   return d.get(k,{False,True})
  cache={k:signal(k) for k in set(sum(self.sig,[]))}
  for i,ss in enumerate(self.sig):
   if ss:lo[i]+=20*sum(min(cache[k]) for k in ss)/len(ss);hi[i]+=20*sum(max(cache[k]) for k in ss)/len(ss)
   else:lo[i]+=10;hi[i]+=10
  if t['blocked']:lo[0]=hi[0]=100;possible[0]=supported[0]=True
  return possible,supported,lo,hi,dlo,dhi
 def decision(self,d,t,e,calc):
  pos,sup,lo,hi,dl,dh=calc; mid=(lo+hi)/2
  def best(mask):
   ix=np.flatnonzero(mask);return int(ix[np.argmax(mid[ix])]) if len(ix) else -1
  f=best(pos&~self.market);fok=f>=0 and sup[f] and all(lo[f]>=hi[j]+(1e-6 if j<f else 0) for j in np.flatnonzero(pos&~self.market) if j!=f)
  if t['blocked']:return f,True,'foundation_only',[],True,[],[]
  # evaluate pathway across remaining possible objectives. Conservative confidence from both lower and upper eligibility/goal alignment.
  def route(mask,aligned,goal,activity):
   pool=mask&aligned&self.market if goal not in ['preservation','specific goal'] and t['horizon'] not in ['immediate','months'] else np.zeros(35,bool)
   ip=pool&np.isin(self.roles,['portfolio','philosophy','investment_horizon']);ip[[33,34]]=False
   th=mask&(self.roles=='trading_horizon');st=mask&(self.roles=='setup');tp=th.any() and st.any() and (pool&np.isin(self.roles,['trading_horizon','setup'])).any(); ii=goal in GOALS and goal not in ['preservation','specific goal','quick profit'];ti=goal=='quick profit' and activity
   if tp and ip.any():p='trading_candidate' if ti else 'investment_candidate' if ii else 'clarify_invest_vs_trade'
   elif tp:p='trading_candidate' if goal=='quick profit' else 'clarify_invest_vs_trade'
   elif ip.any():p='investment_candidate' if ii else 'clarify_invest_vs_trade'
   else:p='foundation_first_clarify_goal_or_bucket' if (mask&self.market).any() else 'foundation_only'
   return p,ip,th,st
  goals=d['FO'];act={a or b for a in d['opportunity_search'] for b in d['activity']};paths=set()
  for g in goals:
   for a in act:
    paths.add(route(pos,dh>=.5,g,a)[0]);paths.add(route(sup,dl>=.5,g,a)[0])
  g=sorted(goals)[0]; a=True in act;p,ip,th,st=route(pos,(dl+dh)/2>=.5,g,a)
  comp=[]; robust=len(paths)==1;shortlist=[]
  def rankgroup(mask):
   j=best(mask)
   if j<0:return j,False,[]
   alt=[int(k) for k in np.flatnonzero(mask) if hi[k]>=lo[j]-1e-6];ok=sup[j] and all(lo[j]>=hi[k]+(1e-6 if k<j else 0) for k in np.flatnonzero(mask) if k!=j)
   return j,ok,alt
  if p=='investment_candidate':
   pref_self=d['mode']=={'self'} and d['low_maintenance']=={False}; pref_port='self' not in d['mode'] or d['low_maintenance']=={True}
   ph=ip&(self.roles=='philosophy');po=ip&(self.roles=='portfolio');hold=ip&(self.roles=='investment_horizon'); mask=(ph if ph.any() else po if po.any() else hold) if pref_self else (po if po.any() else ph if ph.any() else hold)
   j,ok,alt=rankgroup(mask);shortlist=alt;comp=[j] if j>=0 else [];robust &= ok and (pref_self or pref_port or not(ph.any() and po.any())) and (j<0 or dl[j]>=.5)
   if j>=0:
    possible_ip=pos&(dh>=.5)&np.isin(self.roles,['portfolio','philosophy','investment_horizon']);possible_ip[[33,34]]=False
    supported_ip=sup&(dl>=.5)&possible_ip
    role=self.roles[j];competitors=np.flatnonzero(possible_ip&(self.roles==role));robust &= bool(supported_ip[j]) and all(lo[j]>=hi[k]+(1e-6 if k<j else 0) for k in competitors if k!=j)
    shortlist=sorted(set(shortlist)|{int(k) for k in competitors if hi[k]>=lo[j]-1e-6})
    order=['philosophy','portfolio','investment_horizon'] if pref_self else ['portfolio','philosophy','investment_horizon']
    robust &= not any((possible_ip&(self.roles==r)).any() for r in order[:order.index(role)])
    if not(pref_self or pref_port) and (possible_ip&(self.roles=='philosophy')).any() and (possible_ip&(self.roles=='portfolio')).any():robust=False
   if j>=0 and self.roles[j]=='philosophy' and d['mode']=={'self'} and pos[9]:comp.append(9);robust &= sup[9]
   elif j>=0 and self.roles[j]=='philosophy' and 'self' in d['mode'] and pos[9]:robust=False
  elif p=='trading_candidate':
   j,ok,a=rankgroup(th);k,ok2,b=rankgroup(st);comp=[j,k] if min(j,k)>=0 else [];shortlist=a+b;robust &= ok and ok2 and bool(comp) and (dl[j]>=.5 or dl[k]>=.5)
  return f,fok,p,comp,robust,shortlist,sorted(paths)
 def assess(self,t,e,answer,budget=12,noise=False):
  if t is None or e is None:return dict(foundation='UNRESOLVED',pathway='UNRESOLVED',components='',provisional_foundation='UNRESOLVED',provisional_pathway='UNRESOLVED',provisional_components='',shortlist='',questions=0,trace=[],readiness='verification_required',screen=False,reason='missing_intake',live=False)
  d=self.state(t,e);seen=set();trace=[];missing=False
  # Question value: entropy reduction of requirement domains, weighted by relevance to candidate set. No labels used.
  def priority(q,cal,de):
   f=q.field;vals=d[f];yes=vals&set(q.yes);no=vals-set(q.yes)
   if not yes or not no:return -1
   p=len(yes)/len(vals);ent=-p*math.log2(p)-(1-p)*math.log2(1-p)
   pos,sup,lo,hi,dl,dh=cal;market=pos[5:].any();
   if f in ['KL','EX'] and not any(x[0].field==f for x in trace):return 100+ent+(1 if (q.id in ['BQ-049','BQ-052']) else 0)
   if t['blocked']:return -1
   weights={'FO':12,'secondary_goal':7,'risk':9 if market else 1,'reject_any_loss':18 if market else 0,'mode':7 if market else 0,'time':5 if market and any(pos[self.mon=='daily']) else 1,'intervention':6 if market and any(pos[self.mon=='daily']) else 0,'timing':6 if any(pos[self.mon=='intraday']) else 0,'same_bucket_liquidity':15 if market and t['horizon'] in ['months','immediate'] else 0,'obligation_uncertain':4 if not e['exposure'] and not de[1] else 0,'same_bucket_borrowed':4 if not e['exposure'] and not de[1] else 0,'security_motive':3 if (not de[1] or market) else 0,'control_every_decision':4 if market and 'self' in d['mode'] else 0,'low_maintenance':5 if market else 0,'time_sensitive_review_delay':7 if pos[28] or pos[29] else 0,'opportunity_search':5 if 'quick profit' in d['FO'] and market else 0,'activity':4 if 'quick profit' in d['FO'] and market else 0}
   if f in ['KL','EX']:return -1
   # score-relevant preference uncertainty among remaining candidates
   count=sum(f in self.sig[i] for i in np.flatnonzero(pos)); relevant=de[5]; count=max(count,2*sum(f in self.sig[i] for i in relevant))
   wt=weights.get(f,min(4,count));
   if not de[4] and any(f in self.sig[i] for i in relevant):wt=max(wt,min(4,count))
   if f in ['FO','secondary_goal'] and de[1] and de[4]:wt=0
   return wt*ent
  for _ in range(budget+1):
   cal=self.calc(d,t,e);de=self.decision(d,t,e,cal)
   screen=all(any(q.field==f for q,a,g in trace) for f in ['KL','EX'])
   if screen and de[1] and de[4]:reason='supported_decision';break
   if len(trace)>=budget:reason='budget';break
   choices=[(priority(q,cal,de),q.id,q) for q in Q if q.id not in seen];value,_,q=max(choices,key=lambda x:(x[0],x[1] in ['BQ-049','BQ-052'],-len(x[1]),x[1]))
   if value<=0:reason='no_relevant_question';break
   a=answer(q);trace.append((q,a,value));seen.add(q.id)
   if a not in [0,1]:missing=True;reason='missing_answer';break
   d[q.field]&=set(q.yes) if a else set(DOM[q.field])-set(q.yes)
   if not d[q.field]:missing=True;reason='contradictory_answers';break
  f,fok,p,c,ok,sl,paths=de; pos,sup,lo,hi,dl,dh=cal
  # no confirmed market mandate without verified eligibility and explicit loss answer. Inference is conditional only.
  safe=not missing and ok and all(sup[j] for j in c) and (not c or d['reject_any_loss']=={False})
  ids=lambda xs:'|'.join(f'ST-{j:02}' for j in xs)
  return dict(foundation=f'ST-{f:02}' if fok and not missing else 'UNRESOLVED',pathway=p if safe else 'UNRESOLVED',components=ids(c) if safe else '',provisional_foundation=f'ST-{f:02}' if f>=0 else 'UNRESOLVED',provisional_pathway=p,provisional_components=ids(c),shortlist=ids(sl),questions=len(trace),trace=[(q.id,a,g) for q,a,g in trace],readiness='verification_required' if screen else 'unresolved',screen=screen,reason=reason,live=False,possible=ids(np.flatnonzero(pos)),supported=ids(np.flatnonzero(sup)),path_alternatives='|'.join(paths),confirmed=bool(safe and fok))
