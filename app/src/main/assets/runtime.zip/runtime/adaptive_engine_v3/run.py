import pandas as pd,numpy as np,json,hashlib,zipfile,sys,os
from pathlib import Path
if os.environ.get("ADAPTIVE_VARIANT")=="guarded":
 from engine_guarded import Engine,Q
elif os.environ.get("ADAPTIVE_VARIANT")=="refined":
 from engine import Engine,Q
else:
 from engine_v30 import Engine,Q
import importlib.util
R=Path(__import__('os').environ['PROJECT_ROOT']);O=Path(__file__).parent
sp=importlib.util.spec_from_file_location('v2_engine',R/'adaptive_engine_v2/engine.py');v2=importlib.util.module_from_spec(sp);sys.modules[sp.name]=v2;sp.loader.exec_module(v2)
def verify(folder):
 m=json.loads((folder/'manifest.json').read_text())['files_sha256'];bad=[]
 for k,h in m.items():
  f=folder/k
  if f.exists():b=f.read_bytes()
  else:
   with zipfile.ZipFile(str(folder)+'.zip') as z:b=z.read(next(n for n in z.namelist() if n==k or n.endswith('/'+k)))
  if hashlib.sha256(b).hexdigest()!=h:bad.append(k)
 return {'files':len(m),'mismatches':bad}
def truth(p):
 d={f:p[f] for f in ['FO','secondary_goal','reject_any_loss','same_bucket_liquidity','obligation_uncertain','same_bucket_borrowed','low_maintenance','control_every_decision','time_sensitive_review_delay','opportunity_search','diversification_preference','long_hold_preference','value_preference','growth_preference','trend_interest','evidence_contrarian','news_monitoring','difficulty_stopping','rely_entirely_on_tips','unrealistic_expectations','inflation_concern','no_learning_time']};styles={p.DS,p.secondary_style};d.update(risk=['very conservative','conservative','balanced','adventurous','risk seeking'].index(p['BP-01']),mode=p['BP-19'],time=p['PC-05'],timing=p['PC-06'],intervention=p['PC-07'],KL=int(p.KL[-2:]),EX=int(p.EX[-2:]),activity=p['BP-15']=='high',security_motive=p.MO=='security',planning=p['CP-11']=='high',patience=p['BP-03']=='patient',fundamental='fundamental' in styles or p['CP-05']=='high',verification=bool(p.challenge_claims or p.verification_preference),rules='rule-based' in styles or p['BP-05']=='disciplined',patterns=p['CP-04']=='high' or 'visual' in styles,quantitative=p['CP-02']=='high' or 'quantitative' in styles,fast=p['CP-07']=='high' and bool(p.fast_decision_preference),adaptive=p['BP-09']=='adaptive' or 'adaptive' in styles,discipline_problem=p['BP-05']=='undisciplined' or p['BP-06']=='impulsive' or p['BB-18']=='strong');return d
def parts(x):return set(x.split('|'))-{''}
def inputs(p):
 t=v2.financial_intake(p.to_dict());s=p.monthly_income-p.monthly_expenses-p.monthly_debt_payment;rb=round(max(0,p.investment_savings-p.earmarked_savings-6*max(0,-s)),2);return t,dict(weight=p.primary_goal_weight,exposure=p.invested_from_savings>rb,budget=rb)
def metrics(df):
 return dict(n=len(df),avg_questions=float(df.questions.mean()),median_questions=float(df.questions.median()),p95_questions=float(df.questions.quantile(.95)),max_questions=int(df.questions.max()),exact=float(df.exact.mean()),compatible=float(df.compatible.mean()),provisional_exact=float(df.provisional_exact.mean()),provisional_compatible=float(df.provisional_compatible.mean()),foundation_exact=float(df.foundation_exact.mean()),pathway_exact=float(df.pathway_exact.mean()),confirmed=int(df.confirmed.sum()),unresolved=int((~df.confirmed).sum()),market_confirmed=int(df.components.ne('').sum()),ineligible_confirmed=int(df.ineligible.sum()),gate_violation=int(df.gate_violation.sum()),screen=float(df.screen.mean()),readiness_exact=float(df.readiness_exact.mean()),repeated=int(df.repeated.sum()),live=int(df.live.sum()),shortlist_contains_reference=int(df.shortlist_contains_reference.sum()))
folders=[R/'persona_v7',R/'integrated_reference_v3',R/'binary_question_v1'];before={f.name:verify(f) for f in folders};assert not any(v['mismatches'] for v in before.values());print('integrity checked',flush=True)
A=pd.read_csv(R/'binary_question_v1/development_answers.csv').set_index('persona_id');ids=A.index;P=pd.read_csv(R/'persona_v7/personas.csv',keep_default_na=False).set_index('persona_id').loc[ids];ref=pd.read_csv(R/'integrated_reference_v3/integrated_plans.csv',keep_default_na=False);ref=ref[(ref.split=='development')&(ref.case_type=='core')].set_index('persona_id').loc[ids];aligned=pd.read_csv(R/'strategy_reference_v2/plans_development.csv',keep_default_na=False).set_index('persona_id').loc[ids].goal_aligned_candidates
reg=pd.read_csv(R/'strategy_reference_v2/strategy_register.csv',keep_default_na=False);E=Engine(reg.to_dict('records'))
def one(i,full_budget=None):
 pid=ids[i];p=P.loc[pid];r=ref.loc[pid];t,e=inputs(p);d=truth(p);assert t['blocked']==r.financial_gate
 ans={q.id:int(A.loc[pid,q.id]=='A') if q.id in A.columns else int(d[q.field] in q.yes) for q in Q};modes=[('baseline' if full_budget is None else 'budget_24_full',E.assess(t,e,lambda q:ans[q.id],budget=12 if full_budget is None else full_budget))]
 if full_budget is None and i%10==0:modes.append(('budget_24_subsample',E.assess(t,e,lambda q:ans[q.id],budget=24)))
 if full_budget is None and i%10==1:
  rng=np.random.default_rng(i+17);noisy={q.id:ans[q.id]^int(q.priority in ['preference','objective','readiness'] and rng.random()<.1) for q in Q};modes.append(('noise10_subsample',E.assess(t,e,lambda q:noisy[q.id],budget=12)))
 rows=[];traces=[]
 for mode,z in modes:
  c=parts(z['components']);pc=parts(z['provisional_components']);rc=parts(r.reference_components);allowed=parts(r.eligible_after_controls);al=parts(aligned.loc[pid]);
  def compatible(f,path,comp):return f==r.foundation and path==r.pathway and ((not comp and not rc) or (bool(comp) and bool(rc) and comp<=allowed and bool(comp&al)))
  row={k:v for k,v in z.items() if k!='trace'};row.update(persona_id=pid,mode=mode,reference_foundation=r.foundation,reference_pathway=r.pathway,reference_components=r.reference_components,reference_readiness=r.readiness,reference_gate=r.financial_gate,foundation_exact=z['foundation']==r.foundation,pathway_exact=z['pathway']==r.pathway,exact=z['foundation']==r.foundation and z['pathway']==r.pathway and z['components']==r.reference_components,compatible=compatible(z['foundation'],z['pathway'],c),provisional_exact=z['provisional_foundation']==r.foundation and z['provisional_pathway']==r.pathway and z['provisional_components']==r.reference_components,provisional_compatible=compatible(z['provisional_foundation'],z['provisional_pathway'],pc),ineligible=bool(c-allowed),gate_violation=bool(c and r.financial_gate),readiness_exact=z['readiness']==r.readiness,repeated=len(set(q for q,a,g in z['trace']))!=len(z['trace']),shortlist_contains_reference=bool(rc and rc<=parts(z['shortlist'])));rows.append(row)
  if mode in ['baseline','budget_24_full']:
   for j,(qid,a,g) in enumerate(z['trace'],1):traces.append(dict(persona_id=pid,step=j,question=qid,answer='A' if a else 'B',question_value=g))
 return rows,traces
if __name__=='__main__':
 import multiprocessing as mp
 pd.DataFrame([dict(id=q.id,field=q.field,yes_values='|'.join(map(str,q.yes)),scenario=q.scenario,choice_A=q.a,choice_B=q.b,priority=q.priority,source='saved BQ answer' if q.id in A.columns else 'new deterministic synthetic proxy; needs human validation') for q in Q]).to_csv(O/'question_register.csv',index=False)
 rows=[];traces=[]
 with mp.Pool(8) as pool:
  for i,(a,b) in enumerate(pool.imap(one,range(len(ids)),chunksize=20)):
   rows.extend(a);traces.extend(b)
   if i%250==0:print('completed',i,flush=True)
 fixtures=[]
 for pid in ids[:30]:
  p=P.loc[pid];t,e=inputs(p);d=truth(p);a=lambda q:int(d[q.field] in q.yes)
  for name,tt,ee,fn in [('missing_intake',None,None,a),('borrowed_funding',v2.financial_intake(dict(p.to_dict(),**{'FP-08':'borrowed'})),e,a),('no_answer',t,e,lambda q:None),('loss_rejection',t,e,lambda q:1 if q.field=='reject_any_loss' else a(q))]:
   z=E.assess(tt,ee,fn);fixtures.append(dict(persona_id=pid,fixture=name,passed=not z['components'] and not z['live'],reason=z['reason']))
 D=pd.DataFrame(rows);B=D[D['mode']=='baseline'];D.to_csv(O/'simulation_results.csv',index=False);pd.DataFrame(traces).to_csv(O/'question_traces.csv',index=False);pd.DataFrame(fixtures).to_csv(O/'safety_fixtures.csv',index=False)
 M=pd.DataFrame([dict(mode=k,**metrics(g)) for k,g in D.groupby('mode',sort=False)]);M.to_csv(O/'configuration_metrics.csv',index=False);pd.DataFrame([dict(pathway=k,**metrics(g)) for k,g in B.groupby('reference_pathway')]).to_csv(O/'pathway_metrics.csv',index=False)
 reach=[dict(strategy_id=s,reference_count=int((B.reference_foundation.eq(s)|B.reference_components.map(lambda x:s in parts(x))).sum()),confirmed_count=int((B.foundation.eq(s)|B.components.map(lambda x:s in parts(x))).sum()),provisional_count=int((B.provisional_foundation.eq(s)|B.provisional_components.map(lambda x:s in parts(x))).sum()),possible_count=int(B.possible.map(lambda x:s in parts(x)).sum())) for s in reg.id];pd.DataFrame(reach).to_csv(O/'reachability.csv',index=False)
 pd.DataFrame(traces).groupby('question').agg(asked=('persona_id','size'),mean_step=('step','mean'),mean_value=('question_value','mean')).to_csv(O/'question_usage.csv')
 after={f.name:verify(f) for f in folders};assert before==after
 S=dict(baseline=metrics(B),configs=M.to_dict('records'),integrity=after,questions=len(Q),new_questions=sum(q.id not in A.columns for q in Q),reach_confirmed=sum(x['confirmed_count']>0 for x in reach),reach_provisional=sum(x['provisional_count']>0 for x in reach),reach_possible=sum(x['possible_count']>0 for x in reach),fixture_passed=sum(x['passed'] for x in fixtures),fixtures=len(fixtures),stop_reasons=B.reason.value_counts().to_dict(),intake_fields=14,validation_used=False,holdout_used=False);(O/'summary.json').write_text(json.dumps(S,indent=2));print(json.dumps(S,indent=2),flush=True)
