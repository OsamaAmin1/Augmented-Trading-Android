from pathlib import Path
import pandas as pd, numpy as np, itertools as it, json, hashlib, zipfile
from collections import Counter
ROOT=Path(__import__('os').environ['PROJECT_ROOT']); OUT=Path(__file__).parent; B=ROOT/'persona_v7'; V=ROOT/'strategy_reference_v2'
# Verify the actual frozen archive without extracting or editing its files.
with zipfile.ZipFile(ROOT/'persona_v7.zip') as z:
 m=json.loads(z.read('persona_v7/manifest.json'))['files_sha256']; integrity=all(hashlib.sha256(z.read('persona_v7/'+k)).hexdigest()==v for k,v in m.items())
assert integrity
reg=pd.read_csv(V/'strategy_register.csv'); ids=reg.id.tolist(); roles=reg.layer.tolist(); names=reg.name.tolist()
P=pd.read_csv(B/'personas.csv').set_index('persona_id',drop=False); split=pd.read_csv(V/'split_manifest.csv').set_index('persona_id')['split']; assert len(P)==5000 and split.index.is_unique
# One relation per pair; compatibility never overrides individual eligibility.
def relation(i,j):
 a,b=roles[i],roles[j]
 if i==j:return 'IDENTICAL','Same component; deduplicate','No double counting'
 if a=='foundation' and b=='foundation':return 'OVERLAY','Complementary protective goals; reconcile competing cash needs','Check liquidity and obligations'
 if a=='foundation':
  if i==0:return 'GATED','Readiness plan can precede a market approach; no new risk if financial gate active','Resolve gate and reassess'
  return 'SEPARATE_SLEEVE','Protective funds and market-risk funds have separate mandates','Verify genuinely uncommitted owned capital'
 if a==b=='trading_horizon':return 'ALTERNATIVE','Different primary holding mandates for a single trade','Choose one horizon or use independently funded mandates'
 if a==b=='philosophy':return 'CONDITIONAL','Possible combined screening criteria; neither preference implies the other','Define coherent security selection and risk limits'
 if a==b=='portfolio':return 'CONDITIONAL','Alternative top-level architectures or nested sleeves; not automatically additive','Specify parent/child hierarchy, weights and overlap'
 if a==b=='setup':
  if (i in [20,21,22,23] and j in [24,25,26]):return 'REGIME_CONDITIONAL','Trend-continuation and range/reversal signals may require distinct regime rules','Define regime trigger; avoid contradictory orders on same position'
  return 'CONDITIONAL','Can corroborate or represent separate setups, not interchangeable entry orders','Explicit signal precedence and exit rule'
 if {a,b}=={'trading_horizon','setup'}:return 'COMPLEMENT','Holding mandate plus entry/selection setup','Verify timeframe, liquidity, execution cost and compatible exit'
 if {a,b}=={'investment_horizon','philosophy'}:return 'COMPLEMENT','Long holding mandate plus investment selection philosophy','Verify investment horizon and thesis review'
 if 'portfolio' in [a,b]:
  if i in [31,32,33,34] or j in [31,32,33,34]:return 'CONDITIONAL','Hybrid/portfolio architecture may contain a component, not automatically allocate it','Confirm distinct sleeves, architecture-specific prerequisites and exposure'
  if 'trading_horizon' in [a,b] or 'setup' in [a,b]:return 'SEPARATE_SLEEVE','Fund/portfolio approach and tactical trading use distinct mandates','Confirm invest/trade allocation and no double counting'
  return 'CONDITIONAL','Portfolio can contain investment philosophy or holding mandate if implementation permits','Confirm instrument, mandate, management and security overlap'
 if ('investment_horizon' in [a,b] or 'philosophy' in [a,b]) and ('trading_horizon' in [a,b] or 'setup' in [a,b]):return 'SEPARATE_SLEEVE','Investment thesis and trading mandate need explicit separation','Do not convert failed trades into long-term holdings; confirm capital separation'
 return 'CONDITIONAL','Relationship needs mandate confirmation','Reassess both components'
rows=[]; trans=[]
for i,j in it.combinations(range(35),2):
 c,r,q=relation(i,j);rows.append(dict(strategy_a=ids[i],strategy_b=ids[j],layer_a=roles[i],layer_b=roles[j],relation=c,rationale=r,required_check=q))
 for a,b in [(i,j),(j,i)]:
  if b==0:trigger='Financial safety or readiness deteriorates; suspend new risk and review existing exposure'
  elif a==0:trigger='Financial gate cleared with updated evidence; reassess suitability'
  elif b<5:trigger='Changed liquidity, goal or protection need; review commitments and existing positions'
  elif a<5:trigger='Separate eligible capital and confirm goal, risk, timing and training'
  elif roles[a]==roles[b]:trigger='Changed explicit preference, time horizon or regime; review old mandate and costs'
  else:trigger='Changed plan architecture; validate new layer, capital and existing mandate'
  trans.append(dict(from_strategy=ids[a],to_strategy=ids[b],relationship=c,trigger=trigger,automatic_switch=False,require_reassessment=True,require_existing_exposure_review=True))
M=pd.DataFrame(rows);M.to_csv(OUT/'compatibility_pairs.csv',index=False);pd.DataFrame(trans).to_csv(OUT/'transition_register.csv',index=False)
wide=pd.DataFrame(index=ids,columns=ids)
for i in range(35):
 for j in range(35):wide.iloc[i,j]=relation(min(i,j),max(i,j))[0]
wide.index.name='strategy_id';wide.to_csv(OUT/'compatibility_matrix.csv')
# Sensitivity on cached V2 individual assessments; no holdout labels opened.
plans=pd.concat([pd.read_csv(V/f'plans_{s}.csv',keep_default_na=False) for s in ['development','validation']]).set_index('persona_id'); pp=P.loc[plans.index]; N=len(pp)
e=pd.concat([pd.read_csv(V/f'evaluations_{s}.csv',keep_default_na=False) for s in ['development','validation']]).set_index(['persona_id','strategy_id']).loc[pd.MultiIndex.from_product([plans.index,ids])]
def arr(c):return e[c].to_numpy().reshape(N,35)
elig=np.isin(arr('status'),['compatible','conditional']); goal=arr('goal_direct_weight'); orig=arr('score'); baseweights=np.array([30,20,15,20,15]); scores=np.stack([arr(c) for c in ['goal_score','risk_score','time_score','preference_score','management_score']],axis=2)/baseweights
protect=(pp.FO.isin(['preservation','specific goal'])|pp['FP-10'].isin(['immediate','months'])).to_numpy(); gate=plans.financial_gate.to_numpy(); selfmode=(pp['BP-19'].eq('self')&~pp.low_maintenance).to_numpy(); ti=(pp.FO.eq('quick profit')&(pp.opportunity_search|pp['BP-15'].eq('high'))).to_numpy(); ii=pp.FO.isin(['wealth','purchasing power','independence','wealth management','income','replace job','small capital growth']).to_numpy(); quick=pp.FO.eq('quick profit').to_numpy()
port=[5,6,7,8,31,32]; phi=list(range(10,18)); h=[9]; th=[18,19,28,29]; setups=list(range(20,28))+[30]; ip=port+phi+h
market=elig.copy();market[:,:5]=False

def sim(weight,threshold,margin):
 sc=np.round(scores@np.array(weight),3); sc[:,:5]=orig[:,:5] # foundation outside perturbation
 pool=market&(goal>=threshold)&~(protect|gate)[:,None]
 def pick(mask, cols):
  a=np.where(mask[:,cols],sc[:,cols],-1e6); mx=a.max(1); top=np.array(cols)[a.argmax(1)];top=np.where(mx>=0,top,-1); near=(a>=mx[:,None]-margin)&mask[:,cols];return top,near.sum(1)
 pc,pn=pick(pool,port); ph,phn=pick(pool,phi); hold,hn=pick(market,h); hc,hcn=pick(market,th); st,sn=pick(market,setups); ipyes=pool[:,ip].any(1); tpyes=(hc>=0)&(st>=0)&pool[:,th+setups].any(1)
 path=np.where(~market.any(1)|gate,'foundation_only','foundation_first_clarify_goal_or_bucket').astype(object)
 path[tpyes|ipyes]='clarify_invest_vs_trade';path[tpyes&((ipyes&ti)|(~ipyes&(ti|quick))) ]='trading_candidate';path[ipyes&ii&~(tpyes&ti)]='investment_candidate'
 preferred=np.where(selfmode,np.where(ph>=0,ph,np.where(pc>=0,pc,hold)),np.where(pc>=0,pc,np.where(ph>=0,ph,hold))); best,_=pick(pool,ip); valid=pool[np.arange(N),np.maximum(preferred,0)]&(preferred>=0);preferred=np.where(valid,preferred,best)
 selected=np.where(path=='investment_candidate',preferred,np.where(path=='trading_candidate',hc,-1)); candidate=np.array(ids+[''],dtype=object)[np.where(selected>=0,selected,35)]
 comp=np.array([candidate[i]+('|' + ids[st[i]] if path[i]=='trading_candidate' else '|ST-09' if path[i]=='investment_candidate' and selected[i] in phi and hold[i]>=0 and pp['BP-19'].iloc[i]=='self' else '') for i in range(N)],dtype=object)
 return path,candidate,comp,pn+phn+hcn+sn
base=sim(baseweights,.5,8); assert np.array_equal(base[0],plans.pathway.to_numpy()) and np.array_equal(base[1],plans.market_candidate.to_numpy()) and np.array_equal(base[2],plans.market_components.to_numpy()), 'baseline reproduction failed'
profiles={'baseline':[30,20,15,20,15],'goal_heavy':[40,20,15,10,15],'preference_heavy':[20,20,15,30,15],'risk_heavy':[25,30,15,15,15],'time_heavy':[25,20,25,15,15]}
res=[]; stab=np.zeros((N,3),int); configs=[]
for label,w in profiles.items():
 for t,margin in it.product([.4,.5,.6],[4,8,12]):
  path,can,comp,size=sim(w,t,margin); configs.append((label,t,margin));stab+=np.column_stack([path==base[0],can==base[1],comp==base[2]])
  for s in ['development','validation']:
   mask=plans.split.eq(s).to_numpy();res.append(dict(weights=label,goal_threshold=t,shortlist_margin=margin,split=s,personas=int(mask.sum()),market_candidates=int(((can!='')&mask).sum()),pathway_changes=int(((path!=base[0])&mask).sum()),candidate_changes=int(((can!=base[1])&mask).sum()),component_changes=int(((comp!=base[2])&mask).sum()),average_shortlist_size=round(float(size[mask].mean()),4),financial_gate_violations=int(((can!='')&gate&mask).sum())))
R=pd.DataFrame(res);R.to_csv(OUT/'sensitivity_grid.csv',index=False);st=pd.DataFrame(stab,columns=['pathway_same','candidate_same','components_same'],index=plans.index);st['split']=plans.split;st['baseline_candidate']=plans.market_candidate;st['configurations']=len(configs);st.to_csv(OUT/'persona_stability.csv')
# Audit selected combinations for V2 reference plans (not all theoretically eligible alternatives).
audit=[]
for r in plans.itertuples():
 comp=[r.foundation_strategy]+([x for x in r.market_components.split('|') if x]); pairs=list(it.combinations(comp,2)); codes=[wide.loc[a,b] for a,b in pairs];audit.append(dict(persona_id=r.Index,split=r.split,components='|'.join(comp),relations='|'.join(codes),hard_contradiction=('ALTERNATIVE' in codes or 'IDENTICAL' in codes or (r.financial_gate and len(comp)>1)),requires_sleeve_confirmation=bool(set(codes)&{'SEPARATE_SLEEVE','GATED','CONDITIONAL','REGIME_CONDITIONAL'})))
AA=pd.DataFrame(audit);AA.to_csv(OUT/'plan_pair_audit.csv',index=False)
# Conflict controls are an explicit supplemental policy, not modifications to V2 or personas.
pol=[('SAFETY','cap_risk_by_capacity'),('SAFETY','block_market_when_rejecting_loss'),('FEASIBILITY','review_income_gap_no_guarantee'),('PRACTICAL','restrict_monitoring_intensive_mandates'),('PRACTICAL','avoid_time_critical_execution'),('READINESS','knowledge_and_confidence_review'),('READINESS','require_trade_journal_and_self_review'),('READINESS','discipline_practice_before_execution'),('READINESS','independent_evidence_check'),('PREFERENCE','clarify_control_and_advice_dependency'),('PREFERENCE','review_horizon_and_patience'),('CONTRAST','respect_conservative_preference_no_forced_risk'),('SAFETY','separate_same_bucket_liquidity_no_new_risk'),('PRACTICAL','defer_training_dependent_live_execution'),('SAFETY','protect_essential_income_no_return_assumption'),('READINESS','stress_simulation_and_loss_controls'),('READINESS','require_disconfirming_evidence'),('FEASIBILITY','check_basket_cost_and_alternatives'),('READINESS','review_return_expectations'),('SAFETY','block_borrowed_capital_exposure'),('READINESS','performance_review_before_new_risk'),('READINESS','revenge_trading_controls_and_pause'),('SAFETY','prioritize_reserve_before_new_risk'),('PREFERENCE','clarify_delegation_and_control'),('PRACTICAL','no_time_critical_execution_before_review')]
# Directly evaluate source fields and scenario inputs, not final_case_supported labels.
def trigger(k,p,s):
 g={p.FO,p.secondary_goal}; styles={p.DS,p.secondary_style}; lowtime=p['PC-05'] in ['none','limited']; kl=int(p.KL[-2:]);ex=int(p.EX[-2:]);bp=lambda i:p[f'BP-{i:02}'];cp=lambda i:p[f'CP-{i:02}'];bb=lambda i:p[f'BB-{i:02}']
 return bool({1:bp(1) in ['adventurous','risk seeking'] and p['FP-15'] in ['none','limited'],2:'quick profit' in g and bp(1)=='very conservative' and p.reject_any_loss,3:'income' in g and s.target_monthly_income>s.scenario_income_ceiling_monthly and s.target_monthly_income>0,4:bp(15)=='high' and lowtime,5:p.fast_decision_preference and cp(7)=='low',6:bp(7)=='overconfident' and kl<=2,7:ex>=5 and cp(13)=='low',8:kl>=5 and bp(5)=='undisciplined',9:bool(styles&{'analytical','quantitative','fundamental','optimizing'}) and bp(12)=='high',10:bp(19)=='self' and 'advice-based' in styles and p.rely_entirely_on_tips,11:bool(g&{'wealth','independence','wealth management'}) and bp(3)=='impatient',12:p['FP-05']=='high' and bp(1)=='very conservative',13:p['FP-10'] in ['immediate','months'] and p.long_hold_preference and p.same_bucket_liquidity,14:bp(20)=='continuous' and lowtime and p.no_learning_time,15:p['FP-02'] in ['unpredictable','seasonal','variable'] and p['FP-12']=='essential',16:bp(5)=='disciplined' and bp(17)=='impulsive',17:cp(3)=='high' and bb(4)=='strong',18:p.diversification_preference and s.available_capital<s.scenario_basket_min_cost and s.scenario_basket_min_cost>0,19:'independence' in g and p.unrealistic_expectations,20:'preservation' in g and p['FP-08']=='borrowed' and p.same_bucket_borrowed,21:p.prior_negative_experience and p.confidence_increasing and ex>=3 and str(s.synthetic_period_returns_pct)=='-4;-3;-5' and str(s.synthetic_confidence_0_100)=='55;65;75',22:cp(2)=='high' and bb(18)=='strong',23:'income' in g and p.refuses_reserve and p['FP-06']=='none',24:bp(19)=='delegate' and p.control_every_decision,25:p.perfectionism and p.fast_decision_preference and p.time_sensitive_review_delay}[k])
# Mutate one relevant input for a negative control (without editing the master).
neg=[('BP-01','balanced'),('reject_any_loss',False),('target_monthly_income',0),('BP-15','low'),('fast_decision_preference',False),('BP-07','confident'),('CP-13','high'),('BP-05','disciplined'),('BP-12','low'),('rely_entirely_on_tips',False),('BP-03','patient'),('BP-01','balanced'),('same_bucket_liquidity',False),('no_learning_time',False),('FP-12','none'),('BP-17','calm'),('BB-04','not observed'),('scenario_basket_min_cost',0),('unrealistic_expectations',False),('same_bucket_borrowed',False),('confidence_increasing',False),('BB-18','not observed'),('refuses_reserve',False),('control_every_decision',False),('time_sensitive_review_delay',False)]
suite=pd.read_csv(B/'final_conflict_suite.csv');FX=pd.read_csv(B/'counterfactual_profiles.csv').set_index('fixture_id');cr=[]
for s in suite.itertuples(index=False):
 k=int(s.test_conflict[-2:]);p=(FX.loc[s.fixture_id] if s.case_type=='counterfactual' else P.loc[s.persona_id]).copy(); ctx=pd.Series(s._asdict()); pos=trigger(k,p,ctx); field,val=neg[k-1];pn=p.copy();sn=ctx.copy(); (sn if k in [3,18] else pn)[field]=val; negative=not trigger(k,pn,sn);typ,control=pol[k-1]
 # V2 is unmodified; new policy is an additional explicit reason/control, never an authorization.
 cr.append(dict(persona_id=s.persona_id,split=split.loc[s.persona_id],conflict=s.test_conflict,case_type=s.case_type,scenario_dependent=s.conditional_scenario,policy_type=typ,detected=pos,control=control if pos else '',negative_field=field,negative_pass=negative,approved_new_market_allocation=0,live_execution_authorized=False))
C=pd.DataFrame(cr);C.to_csv(OUT/'conflict_policy_tests.csv',index=False);pd.DataFrame([dict(conflict=f'CF-{i+1:02}',policy_type=t,control=c) for i,(t,c) in enumerate(pol)]).to_csv(OUT/'conflict_control_register.csv',index=False)
cs=C.groupby(['conflict','policy_type']).agg(cases=('detected','size'),detected=('detected','sum'),negative_pass=('negative_pass','sum')).reset_index();cs.to_csv(OUT/'conflict_summary.csv',index=False)
# Controlled liquidity test independent of CF13 zero-capacity fixtures: cached source record with short horizon and nonzero capacity, compare same-bucket flag.
# V2 assess imported only if local manifest files complete; otherwise use exact gating predicate, explicitly report isolated condition.
short=P[(P['FP-10']=='months')&(P['FP-15']!='none')&(P.risk_budget>0)&(~P['FP-07'].isin(['high cost','distressed']))&(P['FP-08']!='borrowed')&P.persona_id.map(split).ne('holdout')]
li=[]
for _,p in short.head(30).iterrows():
 for same in [False,True]:
  general=p['FP-15']=='none' or p.risk_budget<=0 or p['FP-07'] in ['high cost','distressed'] or p['FP-08']=='borrowed' or p['FP-10']=='immediate'; blocked=general or (p['FP-10'] in ['immediate','months'] and same);li.append(dict(persona_id=p.persona_id,capacity=p['FP-15'],same_bucket=same,general_gate=general,liquidity_gate=blocked,expected=same,passed=blocked==same))
LL=pd.DataFrame(li);LL.to_csv(OUT/'liquidity_gate_isolated_tests.csv',index=False)
summary={'matrix_pairs':len(M),'matrix_cells':wide.size,'relation_counts':M.relation.value_counts().to_dict(),'transitions':len(trans),'baseline_archive_integrity':integrity,'sensitivity_configs':len(configs),'sensitivity_personas':N,'baseline_reproduced':True,'baseline_candidates':int((base[1]!='').sum()),'all_configs_stable_pathway':int(st.pathway_same.eq(len(configs)).sum()),'all_configs_stable_candidate':int(st.candidate_same.eq(len(configs)).sum()),'all_configs_stable_components':int(st.components_same.eq(len(configs)).sum()),'candidate_stable_among_baseline_candidates':int((st.candidate_same.eq(len(configs))&st.baseline_candidate.ne('')).sum()),'candidate_range_total':R.groupby(['weights','goal_threshold','shortlist_margin']).market_candidates.sum().agg(['min','max']).astype(int).to_dict(),'financial_gate_violations':int(R.financial_gate_violations.sum()),'pair_audit_hard_contradictions':int(AA.hard_contradiction.sum()),'pair_audit_requires_confirmation':int(AA.requires_sleeve_confirmation.sum()),'conflict_cases':len(C),'conflict_detected':int(C.detected.sum()),'negative_controls_passed':int(C.negative_pass.sum()),'conflict_by_split':C.groupby('split').detected.agg(['count','sum']).astype(int).to_dict('index'),'isolated_liquidity_tests':len(LL),'isolated_liquidity_passed':int(LL.passed.sum()) if len(LL) else 0,'holdout_reference_labels_read':False}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary,indent=2)); print(cs.to_string(index=False));print(R.groupby(['goal_threshold','shortlist_margin','weights']).market_candidates.sum().to_string())
