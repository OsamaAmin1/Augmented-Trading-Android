from pathlib import Path
import sys,importlib.util,ast,json,os
import numpy as np,pandas as pd,multiprocessing as mp
R=Path(__import__('os').environ['PROJECT_ROOT']);O=Path(__file__).parent
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
opt=load('qopt',R/'question_optimization_v1/build.py');rel=opt.rel;E,Q,DOM,REG=rel.E,rel.Q,rel.DOM,rel.REG;QM={q.id:q for q in Q};parts=rel.parts
integ=load('integ',R/'integrated_reference_v3/build.py');source=R/'strategy_reference_v2/build.py';tree=ast.parse(source.read_text());tree.body=[n for n in tree.body if not isinstance(n,(ast.Assert,ast.If))];ns={'__file__':str(source),'__name__':'raw_reference'};exec(compile(tree,str(source),'exec'),ns);evaluate=ns['evaluate'];intake=sys.modules['run'].v2.financial_intake
FIRST='monthly_income monthly_expenses monthly_debt_payment debt_principal debt_annual_rate debt_overdue investment_savings earmarked_savings emergency_reserve_separate FP-08 FP-10 FP-12 invested_from_savings primary_goal_weight'.split()
EXTRA='FO secondary_goal MO DS secondary_style KL EX PC-05 PC-06 PC-07 FP-02 FP-05 FP-06 BP-01 BP-03 BP-05 BP-06 BP-07 BP-09 BP-12 BP-15 BP-17 BP-19 BP-20 BB-04 BB-18 CP-02 CP-03 CP-04 CP-05 CP-07 CP-11 CP-13 verification_preference challenge_claims fast_decision_preference long_hold_preference diversification_preference low_maintenance opportunity_search value_preference growth_preference trend_interest evidence_contrarian news_monitoring difficulty_stopping rely_entirely_on_tips unrealistic_expectations inflation_concern no_learning_time control_every_decision time_sensitive_review_delay reject_any_loss same_bucket_liquidity same_bucket_borrowed obligation_uncertain refuses_reserve perfectionism prior_negative_experience confidence_increasing'.split();FIELDS=FIRST+EXTRA;GF='goal_id goal weight months target_today real_target withdrawal'.split()
def initial_input(x):
 if any(k not in x or x[k] is None or pd.isna(x[k]) for k in FIRST):return None,None
 try:
  t=intake(x);s=x['monthly_income']-x['monthly_expenses']-x['monthly_debt_payment'];rb=round(max(0,x['investment_savings']-x['earmarked_savings']-6*max(0,-s)),2)
  if t is None or not 0<=x['primary_goal_weight']<=1 or not 0<=x['invested_from_savings']<=x['investment_savings'] or x['earmarked_savings']>x['investment_savings']:return None,None
  return t,dict(weight=x['primary_goal_weight'],exposure=x['invested_from_savings']>rb,budget=rb)
 except (ValueError,TypeError,KeyError):return None,None
def materialize(x,sid):
 if any(k not in x or x[k] is None or pd.isna(x[k]) for k in FIELDS):raise ValueError('incomplete structured profile')
 t,e=initial_input(x)
 if t is None:raise ValueError('invalid financial intake')
 p=pd.Series({k:x[k] for k in FIELDS});p['persona_id']=sid;p['monthly_surplus']=round(p.monthly_income-p.monthly_expenses-p.monthly_debt_payment,2);p['emergency_months']=p.emergency_reserve_separate/(p.monthly_expenses+p.monthly_debt_payment);p['risk_budget']=e['budget'];p['exposure_above_budget']=e['exposure'];p['secondary_goal_weight']=round(1-p.primary_goal_weight,10);p['FP-15']=['none','limited','medium','high'][t['capacity']];p['FP-07']='none' if p.debt_principal==0 else 'distressed' if p.debt_overdue else 'high cost' if p.debt_annual_rate>=.20 else 'low cost';return p
def discover(x,ask,ask_atom,confirm=False):
 t,e=initial_input(x);logs=[];supp=[];train=set();unresolved=False
 def wrapped(q):
  a=ask(q,0);logs.append((q.id,a))
  if a not in (0,1):return None
  if not confirm or q.field!='FO':return a
  b=ask(q,1);logs.append((q.id+'-C1',b))
  if b not in (0,1):return None
  if a==b:return a
  c=ask(q,2);logs.append((q.id+'-C2',c));return c if c in (0,1) else None
 z=E.assess(t,e,wrapped,budget=36);z.setdefault('confirmed',False);z.setdefault('trace',[]);z.setdefault('screen',False)
 d=E.state(t,e) if t is not None else {k:set(v) for k,v in DOM.items()}
 for qid,a,_ in z['trace']:
  if a not in (0,1):unresolved=True;break
  q=QM[qid];d[q.field]&=set(q.yes) if a else set(DOM[q.field])-set(q.yes)
  if not d[q.field]:unresolved=True;break
 def query(f,yes,label):
  nonlocal unresolved
  vals=d[f];v=True if vals<=yes else False if not vals&yes else None
  if v is None:
   v=ask_atom('field',f,yes);supp.append(('field',f,sorted(yes),v))
   if v not in (True,False):unresolved=True;return
   d[f]&=yes if v else set(DOM[f])-yes
  if v:train.add(label)
 if z['confirmed'] and not unresolved:
  for st in sorted(parts(z['components'])):
   sp=REG.loc[st];n=int(st[-2:]);
   if sp.min_knowledge:query('KL',set(range(int(sp.min_knowledge))),'knowledge_training')
   if sp.min_experience:query('EX',set(range(int(sp.min_experience))),'supervised_simulation_or_practice')
   if n in list(range(18,31))+[33,34]:query('difficulty_stopping',{True},'behavioral_controls_and_review')
   query('difficulty_stopping',{True},'behavioral_control_assessment');query('unrealistic_expectations',{True},'realistic_return_expectations')
   if sp.management=='self':query('rely_entirely_on_tips',{True},'independent_decision_training')
   if sp.monitor in ['daily','intraday']:query('discipline_problem',{True},'discipline_and_loss_control')
 nready=len(supp);states={k:'unresolved' for k in opt.PRIORITY}
 if z['confirmed'] and not unresolved and t is not None:
  verified={"p['FP-15'] in ['none', 'limited']":t['capacity']<=1,"p['FP-10'] in ['immediate', 'months']":t['horizon'] in ['immediate','months'],"p['FP-12'] == 'essential'":x['FP-12']=='essential',"p['FP-08'] == 'borrowed'":x['FP-08']=='borrowed'}
  def atom(a):
   v=ask_atom('atom',a,None);supp.append(('atom',a,[],v));return v
  try:states,_=opt.screen(d,verified,atom,opt.PRIORITY,1 if len(logs)+nready<=11 else 0)
  except ValueError:unresolved=True
 return dict(z=z,logs=logs,supp=supp,domains=d,training='|'.join(sorted(train)),hits='|'.join(f'CF-{k:02}' for k,v in sorted(states.items()) if v=='detected'),pending='|'.join(sorted({f'CF-{i:02}' for i in range(1,26)}-{f'CF-{k:02}' for k,v in states.items() if v!='unresolved'})),unresolved=unresolved,questions=len(logs)+len(supp),confirmations=len(logs)-z['questions'],readiness_questions=nready)
def finalize(i,first,full,gs,sid):
 if not i['z']['confirmed'] or i['unresolved']:return None,[],[],'discovery_unresolved'
 if full is None or gs is None:return None,[],[],'structured_intake_pending'
 try:
  if any(full.get(k)!=first.get(k) for k in FIRST):raise ValueError('changed financial intake')
  p=materialize(full,sid);d=rel.truth(p);a=opt.atoms(p)
  if len(gs)!=2 or len({g.get('goal_id') for g in gs})!=2:raise ValueError('two goals required')
  for j,g in enumerate(gs):
   if any(k not in g or g[k] is None for k in GF) or g['goal']!=[p.FO,p.secondary_goal][j] or abs(g['weight']-[p.primary_goal_weight,p.secondary_goal_weight][j])>1e-8 or not 1<=g['months']<=600 or int(g['months'])!=g['months'] or g['target_today']<=0 or g['withdrawal']<0:raise ValueError('invalid goal')
  if any(d[k] not in v for k,v in i['domains'].items()) or any((d[k] in set(ys) if typ=='field' else a[k])!=v for typ,k,ys,v in i['supp']):return None,[],[],'answer_conflict_requires_clarification'
  ee,pl=evaluate(p);e=pd.DataFrame(ee).set_index('strategy_id');z=i['z']
  if (z['foundation'],z['pathway'],z['components'])!=(pl['foundation_strategy'],pl['pathway'],pl['market_components']):return None,[],[],'reference_reassessment_requires_clarification'
  out,g,s=integ.run(p,pd.Series(pl),e,gs);return out,g,s,'conditional_plan'
 except (ValueError,KeyError,TypeError,AttributeError) as err:return None,[],[],'intake_invalid:'+str(err)
# Harness only; runtime functions do not receive reference labels.
SPLIT=pd.read_csv(R/'strategy_reference_v2/split_manifest.csv');NON=SPLIT[SPLIT.split.isin(['development','validation'])];PID=NON.persona_id.tolist();SPL=NON.set_index('persona_id').split.to_dict();P=pd.read_csv(R/'persona_v7/personas.csv',keep_default_na=False).set_index('persona_id',drop=False).loc[PID];REF=pd.read_csv(R/'integrated_reference_v3/integrated_plans.csv',keep_default_na=False);REF=REF[(REF.case_type=='core')&(REF.split.isin(['development','validation']))].set_index('persona_id').loc[PID];AL=pd.concat([pd.read_csv(R/'strategy_reference_v2'/f'plans_{s}.csv',keep_default_na=False) for s in ['development','validation']]).set_index('persona_id').goal_aligned_candidates

def simulate(task):
 pid,mode=task;p=P.loc[pid];r=REF.loc[pid];truth=rel.truth(p);atoms=opt.atoms(p);x={k:p[k] for k in FIRST};full={k:p[k] for k in FIELDS};gs=integ.goal.goals(p);seed=int(pid[1:]);rng=np.random.default_rng(seed+170);noise={q.id:int(q.priority in ['objective','preference','readiness'] and rng.random()<.1) for q in Q};extra=np.random.default_rng(seed+921).random((len(Q),2));idx={q.id:j for j,q in enumerate(Q)}
 def ask(q,k):return int(truth[q.field] in q.yes)^(0 if mode=='clean' or q.priority not in ['objective','preference','readiness'] else noise[q.id] if k==0 or mode=='persistent' else int(extra[idx[q.id],k-1]<.1))
 def atom(typ,f,ys):return truth[f] in ys if typ=='field' else atoms[f]
 i=discover(x,ask,atom,mode!='clean');z=i['z'];c=parts(z['components']);rc=parts(r.reference_components);allowed=parts(r.eligible_after_controls);exact=(z['foundation'],z['pathway'],z['components'])==(r.foundation,r.pathway,r.reference_components);compatible=z['foundation']==r.foundation and z['pathway']==r.pathway and ((not c and not rc) or (bool(c) and bool(rc) and c<=allowed and bool(c&parts(AL.loc[pid]))))
 out,g,s,status=finalize(i,x,full,gs,pid);meta=dict(persona_id=pid,split=SPL[pid],mode=mode);row=dict(**meta,foundation=z['foundation'],pathway=z['pathway'],components=z['components'],reference_foundation=r.foundation,reference_pathway=r.pathway,reference_components=r.reference_components,exact=exact,compatible=compatible,confirmed=z['confirmed'],ineligible=bool(c-allowed),gate_violation=bool(c and r.financial_gate),questions=i['questions'],strategy_questions=z['questions'],confirmation_questions=i['confirmations'],readiness_questions=i['readiness_questions'],supplemental_questions=len(i['supp']),initial_intake_fields=len(FIRST),additional_profile_fields=len(EXTRA),goal_input_values=2*len(GF),initial_conflicts=i['hits'],pending_conflicts=i['pending'],status=status,final_plan=out is not None,full_agreement=False,allocation=0.,reference_allocation=r.market_alloc,live=False,repeat=len({k for k,v in i['logs']})!=len(i['logs']))
 if out:
  sets=['eligible_after_controls','conflicts','blocked_strategies','joint_components','active_components','training'];keys=['foundation','pathway','reference_components','readiness','base_all_met','robust_all_met']+sets;diff=[k for k in keys if (parts(str(out[k]))!=parts(str(r[k])) if k in sets else out[k]!=r[k])];diff += [k for k in ['market_alloc','joint_envelope','contributions','cash_assigned','objective_shortfall'] if abs(out[k]-r[k])>(1e-6 if k=='objective_shortfall' else .05)];row.update(full_agreement=not diff,allocation=out['market_alloc'],differences='|'.join(diff),final_conflicts=out['conflicts'],final_training=out['training'],final_readiness=out['readiness'],live=out['live_authorized'],final_gate_violation=bool(out['market_alloc']>.05 and out['financial_gate']),final_ineligible=bool(parts(out['active_components'])-parts(out['eligible_after_controls'])))
 tr=[dict(**meta,step=j,question=q,answer=a) for j,(q,a) in enumerate(i['logs'],1)]+[dict(**meta,step=len(i['logs'])+j,question=k,answer=v) for j,(_,k,ys,v) in enumerate(i['supp'],1)]
 return row,dict(**meta,**{k:v for k,v in out.items() if k!='persona_id'}) if out else None,[dict(**meta,**r) for r in g],[dict(**meta,**r) for r in s],tr

def execute(tasks,name):
 rows=[];plans=[];goals=[];scenarios=[];traces=[]
 with mp.Pool(5) as pool:
  for j,(r,p,g,s,t) in enumerate(pool.imap(simulate,tasks,chunksize=12)):
   rows.append(r);traces.extend(t)
   if p:plans.append(p);goals.extend(g);scenarios.extend(s)
   if j%250==0:print(name,j,flush=True)
 for arr,f in [(rows,'results'),(plans,'plans'),(goals,'goals'),(scenarios,'scenarios'),(traces,'traces')]:pd.DataFrame(arr).to_csv(O/f'{name}_{f}.csv',index=False)
 D=pd.DataFrame(rows);print(name,D.groupby('mode').agg(n=('persona_id','size'),exact=('exact','mean'),compatible=('compatible','mean'),q=('questions','mean'),complete=('final_plan','sum'),full_match=('full_agreement','sum'),ineligible=('ineligible','sum'),gate=('gate_violation','sum')).to_string(),flush=True);print(D.status.value_counts().to_string(),flush=True)
if __name__=='__main__':
 phase=sys.argv[1];dev=[p for p in PID if SPL[p]=='development'];val=[p for p in PID if SPL[p]=='validation'];pd.DataFrame([dict(field=k,stage='initial' if k in FIRST else 'full_profile',source='explicit structured input; synthetic oracle in test') for k in FIELDS]+[dict(field=k,stage='each of 2 goal records',source='explicit goal input; synthetic fixture in test') for k in GF]).to_csv(O/'intake_register.csv',index=False)
 tasks=[(p,'clean') for p in (dev[:20] if phase=='pilot' else dev if phase=='development' else val)] if phase!='noise' else [(p,m) for p in dev[1::10] for m in ['noise','persistent']];execute(tasks,phase)
