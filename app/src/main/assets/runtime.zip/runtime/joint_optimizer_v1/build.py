from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,os,zipfile
from scipy.optimize import linprog
R=Path(os.environ.get('PROJECT_ROOT','/mnt/data')); O=Path(__file__).parent; V=R/'strategy_reference_v2'; P=R/'persona_v7'; C=R/'strategy_compatibility_v1'; A=R/'capital_sleeve_v1'
reg=pd.read_csv(V/'strategy_register.csv').fillna('').set_index('id'); mat=pd.read_csv(C/'compatibility_matrix.csv').set_index('strategy_id'); roles=reg.layer.to_dict(); goals={k:set(v.split('|')) for k,v in reg.goals.items()}; tc={'none':0,'limited':0,'medium':.1,'high':.2}
cashfit={'preservation':1,'specific goal':.9,'income':.65,'replace job':.65,'purchasing power':.45,'wealth management':.5,'wealth':.25,'independence':.25,'small capital growth':.25,'quick profit':.15}
strategy_gates={'no_candidate','no_component','ineligible_component','trading_mandate','trading_availability','intraday','hybrid_missing','hybrid_consent','alternative_mandates','separate_sleeve'}
def parts(x):return str(x).split('|') if pd.notna(x) and x else []
def pipe(x):return '|'.join(x)
def valid(a,b):return mat.loc[a,b] not in ['ALTERNATIVE','GATED','SEPARATE_SLEEVE','REGIME_CONDITIONAL']
def solve(p,a,e,pl,ban=(),consent=False,regime=False,stress=(.5,.35,.5),penalty=.15,require=''):
 g=set(parts(a.reasons))-strategy_gates-{'no_loss_room'};free=float(a.uncommitted_cash);limit=float(a.stress_loss_limit);used=stress[0]*float(a.existing_investment_proxy);room=min(max(0,limit-used),12*max(0,p.monthly_surplus));cap=tc[a.effective_capacity]*float(a.uncommitted_wealth)
 if room<=.005:g.add('no_loss_room')
 if free<=.005:g.add('no_free_cash')
 eligible=set(e.index[(e.status.isin(['compatible','conditional']))&(e.goal_direct_weight>=.5)])-set(ban)-set(reg.index[:5]); path=pl.pathway
 I=sorted(k for k in eligible if int(k[3:])<18); H=sorted(k for k in eligible if roles[k]=='trading_horizon');S=sorted(k for k in eligible if roles[k]=='setup');T=[(h,s) for h in H for s in S if valid(h,s) and p['PC-05']!='none' and p['PC-07']!='unavailable' and p['BP-19']!='delegate' and (h not in ('ST-28','ST-29') or (p['PC-05']=='high' and p['PC-06']=='session' and p['PC-07']=='immediate' and not p.time_sensitive_review_delay))]
 w=[(p.FO,p.primary_goal_weight),(p.secondary_goal,p.secondary_goal_weight)];cash=sum(z*cashfit.get(k,.5) for k,z in w)
 def u(ids):return .7*sum(z*sum(k in goals[i] for i in ids)/len(ids) for k,z in w)+.3*np.mean([e.loc[i,'score']/100 for i in ids])
 opts=[]
 if path=='investment_candidate' or consent:opts += [('investment',(i,),(),()) for i in I]+[('investment',(i,'ST-09'),(),()) for i in I if roles[i]=='philosophy' and 'ST-09' in I and valid(i,'ST-09')]
 if path=='trading_candidate' or consent:opts += [('trading',(),t,()) for t in T]
 if consent:
  if 'ST-31' in eligible:opts += [('ST-31',(i,),(),()) for i in I if 'income' in goals[i]]
  if 'ST-32' in eligible:opts += [('ST-32',(i,),(),(j,)) for i in I if i in ['ST-05','ST-06','ST-07','ST-08'] for j in I if roles[j]=='philosophy']
  if 'ST-33' in eligible:opts += [('ST-33',(i,),t,()) for i in I for t in T]
  if 'ST-34' in eligible and regime:opts += [('ST-34',(i,),(),t) for i in I for t in T]
 if require:opts=[o for o in opts if o[0]==require]
 best=['cash',(),(),(),np.zeros(3),0.,0.]
 if not g:
  for arch,i,t,j in opts:
   coeff=np.array([u(i)-cash-penalty*stress[1] if i else 0,u(t)-cash-penalty*stress[2] if t else 0,u(j)-cash-penalty*stress[1] if j and arch=='ST-32' else 0]);mc=free*(.8 if arch=='ST-31' else 1);bounds=[(0,mc if i else 0),(0,min(cap,mc) if t else 0),(0,mc if j and arch=='ST-32' else 0)];rows=[[1,1,1],[stress[1],stress[2],stress[1]]];rhs=[mc,room]
   if arch in ['ST-32','ST-33']:
    k=2 if arch=='ST-32' else 1;b=[0.,0.,0.];b[0]=.1;b[k]=-.9;rows.append(b);rhs.append(0);b=[0.,0.,0.];b[0]=-.3 if arch=='ST-32' else -.9;b[k]=.7 if arch=='ST-32' else .1;rows.append(b);rhs.append(0);bounds[0]=(1000,bounds[0][1]);bounds[k]=(1000,bounds[k][1])
   if arch=='ST-34':rows[1][0]=max(stress[1],stress[2]);bounds[0]=(0,min(mc,cap));coeff[0]=min(u(i),u(j))-cash-penalty*rows[1][0]
   if any(lo>hi for lo,hi in bounds):continue
   active=[k for k,b in enumerate(bounds) if b[1]>0]
   if len(active)==1:
    k=active[0];x=np.zeros(3);x[k]=min(bounds[k][1],mc,room/rows[1][k]) if coeff[k]>0 else 0
   elif len(active)>1:
    sol=linprog(-coeff,A_ub=rows,b_ub=rhs,bounds=bounds,method='highs')
    if not sol.success:continue
    x=sol.x
   else:continue
   gain=float(coeff@x)
   if gain>best[5]+1e-7 and x.sum()>.005:best=[arch,i,t,j,x,gain,float(np.array(rows[1])@x)]
 arch,i,t,j,x,gain,loss=best;total=float(x.sum());ids=set(i+t+j)|({arch} if arch.startswith('ST-') else set())
 return dict(persona_id=p.persona_id,foundation=pl.foundation_strategy,pathway=path,previous_components=pl.market_components,architecture=arch,investment_components=pipe(i),trading_components=pipe(t),satellite_or_standby=pipe(j),investment=x[0],trading=x[1],satellite=x[2],total_envelope=total,unallocated_cash=free-total,available_cash=free,loss_room=room,existing_loss=used,loss_limit=limit,trade_cap=cap,stress_loss=loss,objective_gain=gain,objective=cash+gain/max(free,1),cash_proxy=cash,candidate_compositions=len(opts),gates=pipe(sorted(g)),live_authorized=False,approved_allocation=0,check_cash=total<=free+.01,check_risk=loss<=room+.01 and (total==0 or used+loss<=limit+.01),check_gate=not g or total==0,check_eligible=ids<=eligible,check_trade=x[1]<=cap+.01 and (arch!='ST-34' or x[0]<=cap+.01),check_consent=consent or not arch.startswith('ST-'),check_utility=gain>=0)
def main():
 m=json.loads((P/'manifest.json').read_text())['files_sha256'];z=zipfile.ZipFile(R/'persona_v7.zip');assert all(hashlib.sha256(z.read('persona_v7/'+k)).hexdigest()==v and (not (P/k).exists() or hashlib.sha256((P/k).read_bytes()).hexdigest()==v) for k,v in m.items());split=pd.read_csv(V/'split_manifest.csv');split=split[split.split!='holdout'];core=pd.read_csv(P/'personas.csv').merge(split[['persona_id','split']],on='persona_id').set_index('persona_id',drop=False)
 plans=pd.concat([pd.read_csv(V/f'plans_{s}.csv',keep_default_na=False) for s in ['development','validation']]).set_index('persona_id');ev=pd.concat([pd.read_csv(V/f'evaluations_{s}.csv',keep_default_na=False) for s in ['development','validation']]);E={k:g.set_index('strategy_id') for k,g in ev.groupby('persona_id')};alloc=pd.read_csv(A/'core_allocations.csv',keep_default_na=False).set_index('persona_id');overlay=pd.read_csv(C/'conflict_plan_overlay.csv',keep_default_na=False);ban={k:set(x for v in g.blocked_strategies for x in parts(v)) for k,g in overlay[overlay.case_type=='baseline'].groupby('persona_id')}
 def run(**kw):return pd.DataFrame([dict(split=p['split'],**solve(p,alloc.loc[k],E[k],plans.loc[k],ban.get(k,()),**kw)) for k,p in core.iterrows()])
 D=run();D.to_csv(O/'joint_plans.csv',index=False);sens=[];ss=[]
 for name,kw in [('baseline',{}),('zero_penalty',{'penalty':0}),('double_penalty',{'penalty':.3}),('severe_stress',{'stress':(.75,.5,.75)}),('full_loss',{'stress':(1,1,1)})]:
  d=D if not kw else run(**kw);sens.append(dict(scenario=name,positive=int((d.total_envelope>0).sum()),total=float(d.total_envelope.sum()),median_positive=float(d.loc[d.total_envelope>0,'total_envelope'].median()),checks=bool(d.filter(regex='^check_').all().all())));ss.append(d.set_index('persona_id').total_envelope.rename(name))
 pd.DataFrame(sens).to_csv(O/'sensitivity.csv',index=False);pd.concat(ss,axis=1).to_csv(O/'stability.csv')
 dp=pd.concat([pd.read_csv(V/f'stress_plans_{s}.csv',keep_default_na=False) for s in ['development','validation']]).set_index('case_id');de=pd.concat([pd.read_csv(V/f'stress_evaluations_{s}.csv',keep_default_na=False) for s in ['development','validation']]);de={k:g.set_index('strategy_id') for k,g in de.groupby('case_id')};dy=pd.read_csv(P/'dynamic_snapshots.csv').merge(split[['persona_id','split']],on='persona_id');da=pd.read_csv(A/'dynamic_allocations.csv',keep_default_na=False).set_index(['persona_id','event','state']);out=[]
 for _,p in dy.iterrows():
  k=f'{p.persona_id}:{p.event_id}:{p.state}';out.append(dict(event=p.event_id,state=p.state,split=p['split'],**solve(p,da.loc[(p.persona_id,p.event_id,p.state)],de[k],dp.loc[k])))
 Y=pd.DataFrame(out);Y.to_csv(O/'dynamic_plans.csv',index=False)
 p=core.iloc[0].copy();p.update({'FO':'wealth','secondary_goal':'income','primary_goal_weight':.7,'secondary_goal_weight':.3,'monthly_surplus':20000,'PC-05':'high','PC-06':'session','PC-07':'immediate','BP-19':'self','time_sensitive_review_delay':False});a=pd.Series(dict(reasons='',uncommitted_cash=200000,uncommitted_wealth=200000,stress_loss_limit=40000,existing_investment_proxy=0,effective_capacity='high'));pl=pd.Series(dict(pathway='investment_candidate',foundation_strategy='ST-01',market_components=''));F=[]
 for arch,ids in {'ST-31':['ST-31','ST-13'],'ST-32':['ST-32','ST-05','ST-10'],'ST-33':['ST-33','ST-10','ST-19','ST-23'],'ST-34':['ST-34','ST-10','ST-19','ST-23']}.items():
  q=p.copy();q['FO']='income' if arch=='ST-31' else 'wealth';q['secondary_goal']='quick profit' if arch in ('ST-33','ST-34') else 'wealth'
  for label,cons,rg,allowed,blocked,expected in [('positive',True,True,ids,False,True),('no_consent',False,True,ids,False,False),('missing_component',True,True,ids[:-1],False,False),('hard_gate',True,True,ids,True,False)]+([('no_regime',True,False,ids,False,False)] if arch=='ST-34' else []):
   e=pd.DataFrame(index=reg.index,data={'status':['compatible' if k in allowed else 'incompatible' for k in reg.index],'goal_direct_weight':1.,'score':95.});aa=a.copy();aa['reasons']='debt' if blocked else '';z=solve(q,aa,e,pl,consent=cons,regime=rg,require=arch);F.append(dict(fixture=arch+':'+label,expected_positive=expected,passed=(z['total_envelope']>0)==expected,**z))
 F=pd.DataFrame(F);F.to_csv(O/'composition_tests.csv',index=False);checks=[]
 for name,d in [('core',D),('dynamic',Y),('fixtures',F)]:
  for k in d.filter(regex='^check_'):checks.append(dict(dataset=name,check=k,total=len(d),passed=int(d[k].sum())))
  checks.append(dict(dataset=name,check='no_live_authorization',total=len(d),passed=int((~d.live_authorized & (d.approved_allocation==0)).sum())))
 checks.append(dict(dataset='fixtures',check='expected_branch',total=len(F),passed=int(F.passed.sum())));pd.DataFrame(checks).to_csv(O/'checks.csv',index=False)
 J=D.set_index('persona_id').join(alloc[['total_envelope','components']],rsuffix='_v1');pos=J.total_envelope>0;old=J.total_envelope_v1>0;change=Y.pivot(index=['persona_id','event'],columns='state',values='total_envelope');summary=dict(core=len(D),positive=int(pos.sum()),old_positive=int(old.sum()),retained=int((pos&old).sum()),new=int((pos&~old).sum()),cash_instead=int((~pos&old).sum()),architectures=D.architecture.value_counts().to_dict(),changed_components=int((pos&((J.investment_components+'|'+J.trading_components).str.strip('|')!=J.components)).sum()),median_positive=float(D.loc[D.total_envelope>0,'total_envelope'].median()),total=float(D.total_envelope.sum()),dynamic_records=len(Y),dynamic_changed=int((abs(change.before-change.after)>.01).sum()),fixtures=len(F),fixtures_pass=int(F.passed.sum()),checks=sum(x['total'] for x in checks),checks_pass=sum(x['passed'] for x in checks),manifest_verified=len(m),sensitivity=sens)
 (O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2));print(F[['fixture','passed','total_envelope']].to_string(index=False))
if __name__=='__main__':main()
