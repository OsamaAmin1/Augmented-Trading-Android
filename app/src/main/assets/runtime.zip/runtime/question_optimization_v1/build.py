import sys,importlib.util,ast,json,zipfile
from pathlib import Path
import numpy as np,pandas as pd,multiprocessing as mp
R=Path(__import__('os').environ['PROJECT_ROOT']);O=Path(__file__).parent
sp=importlib.util.spec_from_file_location('rel',R/'adaptive_reliability_v1/build.py');rel=importlib.util.module_from_spec(sp);sp.loader.exec_module(rel)
E,Q,P,A,ids,ref,truth,inputs,parts,verify,folders=[getattr(rel,k) for k in ['E','Q','P','A','ids','ref','truth','inputs','parts','verify','folders']]
DOM=rel.DOM;RULES=rel.ruletexts;M=rel.M;INTAKE=rel.intake;T=rel.T
C=pd.read_csv(R/'adaptive_reliability_v1/completeness_results.csv',keep_default_na=False).set_index('persona_id')
def atoms(p):
 g={p.FO,p.secondary_goal};styles={p.DS,p.secondary_style};lowtime=p['PC-05'] in ['none','limited'];kl=int(p.KL[-2:]);ex=int(p.EX[-2:]);bp=lambda i:p[f'BP-{i:02}'];cp=lambda i:p[f'CP-{i:02}'];bb=lambda i:p[f'BB-{i:02}'];env=dict(p=p,g=g,styles=styles,lowtime=lowtime,kl=kl,ex=ex,bp=bp,cp=cp,bb=bb)
 return {a:bool(eval(code,{},env)) for a,code in rel.codes.items()}
AT=pd.DataFrame([atoms(P.loc[i]) for i in ids],index=ids);PROB=AT.mean().to_dict()
GOALS={"'quick profit' in g":{'quick profit'},"'independence' in g":{'independence'},"'preservation' in g":{'preservation'},"'income' in g":{'income'},"bool(g & {'wealth', 'independence', 'wealth management'})":{'wealth','independence','wealth management'}}
def known(a,d,cache):
 if a in cache:return cache[a]
 if a in M:
  f,yes=M[a];v=d[f];return True if v<=yes else False if not v&yes else None
 if a in GOALS:
  yes=GOALS[a];x,y=d['FO'],d['secondary_goal'];return True if x<=yes or y<=yes else False if not (x|y)&yes else None
 return None
PRIORITY={1,2,4,5,13,15,20,23,25}
def screen(d,verified,ask,selected,limit=None):
 cache=dict(verified);trace=[]
 while True:
  status={};pending={}
  for k in selected:
   vals={a:known(a,d,cache) for a in RULES[k]}
   if False in vals.values():status[k]='not_detected'
   elif all(v is True for v in vals.values()):status[k]='detected'
   else:status[k]='unresolved';pending[k]=[a for a,v in vals.items() if v is None]
  if not pending or (limit is not None and len(trace)>=limit):break
  def value(a):
   p=PROB.get(a,.5);return sum(1 if len(aa)==1 else (1-p)+p/len(aa) for aa in pending.values() if a in aa)
  a=max(set(sum(pending.values(),[])),key=lambda a:(value(a),a));v=ask(a)
  if v not in (True,False):break
  cache[a]=v;trace.append((a,v))
  if a in M:
   f,yes=M[a];d[f]&=yes if v else set(DOM[f])-yes
   if not d[f]:raise ValueError('contradictory evidence')
 return status,trace
SR=pd.read_csv(R/'adaptive_reliability_v1/supplemental_question_traces.csv');READY={pid:list(zip(g.question[:int(C.loc[pid].readiness_questions)],g.answer[:int(C.loc[pid].readiness_questions)]=='A')) for pid,g in SR.groupby('persona_id')}
def conflict_one(pid):
 d=rel.state([(x.question,int(x.answer=='A')) for x in T.get_group(pid).itertuples()]);oracle=AT.loc[pid].to_dict();verified={a:oracle[a] for a in INTAKE};c=C.loc[pid];n=int(c.base_questions+c.readiness_questions)
 for key,val in READY.get(pid,[]):
  f,_,rest=key.partition(':')
  if f in DOM:
   ys=set(ast.literal_eval(rest));d[f]&=ys if val else set(DOM[f])-ys
 rows=[];traces=[]
 for mode,sel,budget in [('all',set(RULES),None),('priority',PRIORITY,None),('initial',set(RULES),max(0,12-n)),('no_extra',set(RULES),0),('one_priority',PRIORITY,1 if n<=11 else 0)]:
  dd={k:set(v) for k,v in d.items()};st,tr=screen(dd,verified,lambda a:oracle[a],sel,budget);hits={f'CF-{k:02}' for k,v in st.items() if v=='detected'};resolved={f'CF-{k:02}' for k,v in st.items() if v!='unresolved'};expected=parts(c.reference_conflicts);pending={f'CF-{k:02}' for k in RULES}-resolved|{'CF-03','CF-18','CF-21'}
  rows.append(dict(persona_id=pid,mode=mode,base_and_readiness=n,additional_questions=len(tr),total_questions=n+len(tr),resolved=len(resolved),detected=len(hits),pending=len(pending),false_positive=len(hits-expected),false_negative_resolved=len((expected&resolved)-hits),full_exact=hits==expected and len(resolved)==22,priority_resolved=len(resolved&{f'CF-{k:02}' for k in PRIORITY}),detected_ids='|'.join(sorted(hits)),pending_ids='|'.join(sorted(pending)),live=False))
  if mode=='initial':traces.extend(dict(persona_id=pid,step=j,question=a,answer='A' if v else 'B') for j,(a,v) in enumerate(tr,1))
 return rows,traces
if __name__=='__main__':
 with mp.Pool(5) as pool:out=list(pool.imap(conflict_one,ids,chunksize=40))
 D=pd.DataFrame([r for rr,_ in out for r in rr]);D.to_csv(O/'progressive_results.csv',index=False);pd.DataFrame([r for _,rr in out for r in rr]).to_csv(O/'progressive_traces.csv',index=False)
 S=D.groupby('mode').agg(n=('persona_id','size'),avg_questions=('total_questions','mean'),avg_extra=('additional_questions','mean'),avg_resolved=('resolved','mean'),avg_pending=('pending','mean'),false_positive=('false_positive','sum'),false_negative_resolved=('false_negative_resolved','sum'),full_exact=('full_exact','sum'),avg_priority_resolved=('priority_resolved','mean'),live=('live','sum')).reset_index();S.to_csv(O/'progressive_summary.csv',index=False);print(S.to_string(index=False),flush=True)
