import os,tempfile,csv,hashlib,random,math
from pathlib import Path
import technical as t
from fastapi.testclient import TestClient
P=Path(__file__).parent;checks=[]
def ck(n,v):
 checks.append({'test':n,'passed':bool(v)});assert v,n
def reject(fn):
 try:fn();return False
 except ValueError:return True
def rows(xs):return [{'time':i,'close':x,'data_class':'D5'} for i,x in enumerate(xs)]
ck('RSI rising',t.rsi(list(range(1,16)),14)==100);ck('RSI falling',t.rsi(list(range(15,0,-1)),14)==0);ck('RSI flat',t.rsi([10]*15,14)==50);ck('RSI warmup',t.rsi([10]*14,14) is None);ck('EMA seed',t.ema([1,2,3],3)==2);ck('EMA update',t.ema([1,2,3,4],3)==3)
a=t.analyze(rows([100]*250),'exercise')[-1]['metrics'];ck('flat standard indicators',a['sma200']==100 and a['macd']==0 and a['macd_signal']==0 and a['bb_upper']==100 and a['rsi14']==50)
ck('no fabricated OHLC',a['atr14'] is None and a['stoch14'] is None and a['obv'] is None)
ck('invalid prices',reject(lambda:t.analyze(rows([100,0]),'exercise')));ck('duplicate time',reject(lambda:t.analyze([{'time':0,'close':1}]*2,'exercise')));ck('OHLC guard',reject(lambda:t.analyze([{'time':0,'close':10,'open':10,'high':9,'low':8}],'exercise')));ck('negative volume guard',reject(lambda:t.analyze([{'time':0,'close':10,'volume':-1}],'exercise')))
a=t.analyze([{'time':i,'close':100,'open':100,'high':101,'low':99,'volume':10} for i in range(14)],'exercise')[-1];ck('ATR constant range',a['metrics']['atr14']==2);ck('stochastic midpoint',a['metrics']['stoch14']==50);ck('doji',a['patterns']==['doji_10pct_range']);ck('OBV unchanged',a['metrics']['obv']==0)
a=t.analyze([{'time':0,'close':9,'open':10,'high':11,'low':8},{'time':1,'close':11,'open':8,'high':12,'low':7}],'exercise');ck('engulfing',a[-1]['patterns']==['bullish_body_engulfing']);ck('prior-only breakout',t.analyze(rows([1,2,3,4,5,6]),'exercise')[-1]['signals']==['close_above_prior_5_closes'])
rng=random.Random(13)
for k in range(100):
 x=[rng.uniform(50,150) for _ in range(40)];prefix=t.analyze(rows(x[:24]),'exercise');full=t.analyze(rows(x),'exercise');mut=t.analyze(rows(x[:24]+[rng.uniform(5,500) for _ in range(16)]),'exercise');ck('prefix invariance '+str(k),prefix==full[:24]==mut[:24]);m=full[-1]['metrics'];ck('bounds '+str(k),0<=m['rsi14']<=100 and m['bb_lower']<=m['sma20']<=m['bb_upper']);scaled=t.analyze(rows([v*3 for v in x]),'exercise')[-1]['metrics'];ck('price scale '+str(k),abs(scaled['rsi14']-m['rsi14'])<1e-10 and abs(scaled['sma20']-3*m['sma20'])<1e-10)
coverage=[];exports=[];intra=[]
with t.connect() as c:
 cat=t.catalogue(c);ck('catalogue',len(cat)==387)
 for i in cat:
  s=t.observed(c,i['id']);a=t.anchors(c,i['id']);coverage.append({'id':i['id'],'observed_series':len(s),'observed_points':sum(len(x['series']) for x in s),'intraday_sessions':len(a),'historical_training_approved':0});ck('lineage '+i['id'],all(not d['training_approved'] and not d['verified_historical'] and d['error'] is None and all(r['source_id'] for r in d['series']) for d in s))
  for d in s:
   for r in d['series']:exports.append({'id':i['id'],'mode':d['mode'],'source':d['source'],'time':r['time'],'price':r['close'],'class':r['data_class'],'signals':'|'.join(r['signals']),'patterns':'|'.join(r['patterns']),**r['metrics']})
  for x in a:
   d=t.intraday(c,i['id'],x['anchor_id']);p=t.intraday(c,i['id'],x['anchor_id'],10);ck('intraday prefix '+x['anchor_id'][:12],d['series'][:11]==p['series'] and len(d['series'])==24 and all(r['metrics']['atr14'] is None for r in d['series']));intra.append({'id':i['id'],'anchor_id':x['anchor_id'],'anchor_date':x['anchor_date'],'points':24,**d['series'][-1]['metrics']})
 ck('observed points',len(exports)==172);ck('intraday sessions',len(intra)==70);ck('no long sample indicator',all(r.get('sma20') is None and r.get('rsi14') is None for r in exports));ck('cutoff',len(t.observed(c,'EGX:ADIB','2026-10-01')[0]['series'])==1);ck('nav no technical ratios',all('rsi14' not in r['metrics'] for d in t.observed(c,'THNDR:FUND:AZG') for r in d['series']));ck('unknown ID',reject(lambda:t.observed(c,'bad')))
def write(name,rs):
 keys=list(dict.fromkeys(k for r in rs for k in r));f=(P/name).open('w',newline='');w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rs);f.close()
write('technical_coverage.csv',coverage);write('technical_observed.csv',exports);write('technical_intraday_summary.csv',intra)
with tempfile.TemporaryDirectory() as td:
 os.environ['INVESTOR_DB']=str(Path(td)/'test.sqlite');import server as s
 A=TestClient(s.app,base_url='http://localhost');B=TestClient(s.app,base_url='http://localhost');ck('auth guard',A.get('/technical/api/catalogue').status_code==401);ck('page auth guard',A.get('/technical').status_code==401)
 for client,alias in ((A,'test_a'),(B,'test_b')):
  p={'alias':alias,'password':'Test-only-password-123'};ck(alias+' registered',client.post('/account/register',json=p).status_code==200);ck(alias+' logged in',client.post('/account/login',json=p).status_code==200)
 ck('page',A.get('/technical').status_code==200);ck('dashboard link','/technical' in A.get('/').text);ck('observed API',len(A.get('/technical/api/observed',params={'id':'EGX:ADIB'}).json()[0]['series'])==5)
 sc=next(k for k,v in s.world.scenarios.items() if v['split']=='train');z=A.post('/market/api/start',json={'scenario':sc,'capital':100000}).json();p={'id':'EGX:ADIB','replay_id':z['token']};d=A.get('/technical/api/replay',params=p).json();ck('replay prefix initial',len(d['series'])==1);ck('cross account replay rejected',B.get('/technical/api/replay',params=p).status_code==400);A.post('/market/api/advance',json={'token':z['token'],'replay_revision':0});e=A.get('/technical/api/replay',params=p).json();ck('replay prefix after advance',len(e['series'])==2 and e['series'][:1]==d['series']);ck('no future quote',e['series'][-1]['time']==1);s.store.db.close()
ck('warehouse hash',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip());write('technical_checks.csv',checks);print('PASS',len(checks),'observed',len(exports),'intraday',len(intra),'observed_series',sum(x['observed_series'] for x in coverage))
