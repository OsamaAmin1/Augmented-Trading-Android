"""Observed-data candidate replay. Strict historical execution blocked until independent evidence passes.
No user input can override verification status. Not a live investment recommendation.
"""
import csv, datetime as dt, math, random, sqlite3
from pathlib import Path
import numpy as np
import optimizer as opt
import intelligence as mi
from replay import money
P=Path(__file__).resolve().parent
COMMIT='910eabba2e16f5dcec37a78c89a3f6e49b675a49'
BASE=f'https://github.com/mekaweey/egx-data/blob/{COMMIT}/data/'
SOURCES={'ADIB':BASE+'01_daily/EGX_ADIB.csv','EGX30':BASE+'09_indices/EGX30_daily.csv','holiday':'https://arabfinance.com/en/news/newdetails/egx-suspends-trading-august-27-for-prophet-muhammad-birthday','crosscheck':'https://stockanalysis.com/quote/egx/ADIB/history/'}
HOLIDAY={'2026-08-27'}
WARNING='D1 candidate observations; opening quote differs across vendors; adjustment, full corporate-action and reuse rights unresolved. Paper results are hypothetical, not verified historical performance. No live orders.'
def load():
 with (P/'paired_source.csv').open() as f:
  r=[{'date':x['date'],**{k:float(v) for k,v in x.items() if k!='date'}} for x in csv.DictReader(f)]
 validate(r);return r

def validate(r):
 dates=[dt.date.fromisoformat(x['date']) for x in r]
 if not dates or sorted(set(dates))!=dates:raise ValueError('Invalid date order')
 for x,d in zip(r,dates):
  if d.weekday() in (4,5) or x['date'] in HOLIDAY:raise ValueError('Unexpected market date')
  o,h,l,c,v,b=[x[k] for k in ('adib_open','adib_high','adib_low','adib_close','adib_volume','egx30_close')]
  if not all(math.isfinite(z) and z>0 for z in (o,h,l,c,v,b)) or not l<=min(o,c)<=max(o,c)<=h:raise ValueError('Invalid observed bar')
 expected=[dates[0]+dt.timedelta(days=i) for i in range((dates[-1]-dates[0]).days+1)]
 if dates!=[d for d in expected if d.weekday() not in (4,5) and d.isoformat() not in HOLIDAY]:raise ValueError('Unresolved calendar gap')

def gate():
 return {'verified_historical':False,'training_approved':False,'strict_execution_allowed':False,'candidate_paper_allowed':True,'checks':{'paired_dates':'pass','weekday_and_known_holiday':'pass_candidate','independent_open_price':'conflict_2026-10-07_48.17_vs_48.11','price_adjustment_basis':'unverified','corporate_action_completeness':'unverified','market_calendar_and_suspensions':'partial','data_reuse_rights':'unverified','international_daily_prices':'missing','fees_settlement_liquidity':'assumed'},'sources':SOURCES,'warning':WARNING}

def snapshot(r,step):
 if type(step)!=int or not 0<=step<len(r):raise ValueError('Invalid step')
 prefix=r[:step+1];cutoff=prefix[-1]['date']
 with sqlite3.connect(f'file:{P/"warehouse.sqlite"}?mode=ro',uri=True) as c:
  c.row_factory=sqlite3.Row;ctx=mi.history(c,cutoff,'EGX:ADIB');ctx['other_local_events']=[e for e in mi.history(c,cutoff)['local_events'] if e['instrument_id']!='EGX:ADIB']
  # filter to known as-of info; candidate publication cutoffs are date-only
  return {'step':step,'date':cutoff,'bars':prefix,'context':ctx,'gate':gate()}

def forecast(prefix,horizon=20,n=48):
 if len(prefix)<21:raise ValueError('Need at least 20 preceding intervals')
 if type(horizon)!=int or not 1<=horizon<=20:raise ValueError('Invalid horizon')
 # Only past observed close ratios, synchronized in chronological contiguous 3-interval blocks.
 v=np.array([x['adib_close'] for x in prefix[-31:]],float);rs=v[1:]/v[:-1];rng=random.Random(1701);out=[]
 for _ in range(n):
  remaining=horizon;f=1.
  while remaining:
   l=min(3,remaining);start=rng.randrange(len(rs)-l+1);f*=float(np.prod(rs[start:start+l]));remaining-=l
  out.append([f])
 return np.array(out)

def paper(r,start=30,steps=20,strict=True):
 if strict is not False:raise ValueError('Strict historical gate blocked: '+WARNING)
 validate(r)
 if type(start)!=int or type(steps)!=int or start<20 or not 1<=steps<=20 or start+steps>=len(r):raise ValueError('Invalid candidate window')
 p=opt.parameters();cash=10000000;held=[0];pending=None;curve=[];orders=[];decisions=[];base_cash=cash;base_held=[0];base_cost=0;full_cash=cash;full_held=0;peak=cash
 # Cap-constrained passive allocation uses same next-open atomic execution and 40% turnover.
 initial_mark=money(r[start]['adib_close']);unit=opt.unit_cost(initial_mark,p['spread_bps'],p['fee_bps'])[0];base_buy=int(cash*.38//unit)
 for t in range(start,start+steps+1):
  x=r[t];o=money(x['adib_open']);mark=money(x['adib_close'])
  if t>start and pending is not None:
   b,s=pending['buy'],pending['sell'];cap=int(r[t-1]['adib_volume']*.01)
   if b[0]+s[0]>cap:cost=0;status='prior_volume_cap_rejected'
   else:cash,held,cost,status=opt.execute(cash,held,[o],b,s,p)
   orders.append({'decision_date':r[t-1]['date'],'execution_date':x['date'],'status':status,'buy_requested':b[0],'sell_requested':s[0],'open_reference':x['adib_open'],'cost':cost/100})
  if t==start+1:
   if base_buy<=int(r[t-1]['adib_volume']*.01):base_cash,base_held,base_cost,_=opt.execute(base_cash,base_held,[o],[base_buy],[0],p)
   # Unconstrained buy-and-hold comparator uses same prior-volume cap and costs; marked, not sold.
   full_unit=opt.unit_cost(o,p['spread_bps'],p['fee_bps'])[0];full_held=min(full_cash//full_unit,int(r[t-1]['adib_volume']*.01));full_cash-=full_held*full_unit
  eq=cash+held[0]*mark;peak=max(peak,eq)
  curve.append({'date':x['date'],'equity':eq/100,'cash':cash/100,'shares':held[0],'drawdown_pct':(1-eq/peak)*100,'passive_capped':(base_cash+base_held[0]*mark)/100,'buy_hold':(full_cash+full_held*mark)/100,'egx30_gross':100000*x['egx30_close']/r[start]['egx30_close']})
  if t==start+steps:break
  f=forecast(r[:t+1]);d=opt.optimize(cash,held,[mark],f,p);decisions.append({'date':x['date'],'forecast_end_horizon':20,**d});pending=d if d['status']=='optimal' and any(d['buy']+d['sell']) else None
 return {'curve':curve,'orders':orders,'decisions':decisions,'gate':gate(),'params':p,'data_class':'D1 prices / D4 estimated forecasts / hypothetical execution','live_authorized':False,'warning':WARNING}

def extended(world,length,seed=1701):
 if length not in (20,60,120):raise ValueError('Choose 20, 60 or 120 steps')
 # D5 synchronized blocks from development only; independent seed, no actual market dates.
 pool=sorted(k for k,v in world.scenarios.items() if v['split']=='train');rng=random.Random(seed);ids=['EGX:ADIB','EGX:COMI','EGX:FWRY'];fs=sorted(world.factors[pool[0]]);paths={i:[100.] for i in ids+fs};blocks=[]
 while len(paths[ids[0]])<=length:
  k=rng.choice(pool);l=min(3,length+1-len(paths[ids[0]]));start=rng.randrange(9-l);blocks.append({'scenario':k,'start':start,'length':l})
  for j in range(start,start+l):
   for i in paths:
    p=world.paths[k][i] if i in ids else world.factors[k][i];paths[i].append(paths[i][-1]*p[j+1]/p[j])
 return {'data_class':'D5','length':length,'paths':paths,'blocks':blocks,'verified_historical':False,'training_approved':False}

def extended_prefix(world,length,step):
 if type(step)!=int or not 0<=step<=length:raise ValueError('Invalid step')
 z=extended(world,length);z['paths']={k:v[:step+1] for k,v in z['paths'].items()};z.pop('blocks');z['step']=step;return z
