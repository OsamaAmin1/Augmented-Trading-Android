import csv,copy,hashlib,os,tempfile,json,sqlite3,math
from pathlib import Path
import numpy as np
import historical as h
from replay import World
P=Path(__file__).parent;checks=[]
def ck(n,b):checks.append({'test':n,'passed':bool(b)});assert b,n
def reject(fn):
 try:fn();return False
 except ValueError:return True
def write(name,rows):
 with (P/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
r=h.load();ck('51 dates',len(r)==51);ck('holiday gap handled','2026-08-27' not in [x['date'] for x in r]);ck('gate closed',not h.gate()['verified_historical']);ck('strict denied',reject(lambda:h.paper(r)));ck('gap rejected',reject(lambda:h.validate(r[:2]+r[3:])));ck('duplicate rejected',reject(lambda:h.validate(r[:2]+r[1:])));x=copy.deepcopy(r);x[0]['adib_high']=1;ck('invalid bar rejected',reject(lambda:h.validate(x)))
with sqlite3.connect(P/'warehouse.sqlite') as c:
 for date,o,hi,lo,cl,v in c.execute("select observation_date,open,high,low,close,volume from history_observation where instrument_id='EGX:ADIB'"):
  a=next(z for z in r if z['date']==date);ck('ADIB overlap '+date,all(abs(a[k]-t)<1e-6 for k,t in zip(['adib_open','adib_high','adib_low','adib_close','adib_volume'],[o,hi,lo,cl,v])))
 for date,cl in c.execute("select observation_date,close from history_observation where instrument_id='INDEX:EGX30'"):
  ck('EGX30 overlap '+date,abs(next(z for z in r if z['date']==date)['egx30_close']-cl)<1e-6)
for t in range(51):
 z=h.snapshot(r,t);c=z['context'];ck('prefix '+str(t),len(z['bars'])==t+1 and z['date']==r[t]['date']);ck('event cutoff '+str(t),all(e['available_from']<=z['date'] for e in c['global_events']+c['local_events']+c['other_local_events']));ck('macro cutoff '+str(t),all(e['available_from']<=z['date'] and e['period_end']<=z['date'] for e in c['macro']));ck('strict gate '+str(t),z['gate']['strict_execution_allowed'] is False)
for t in range(30,50):
 x=copy.deepcopy(r)
 for a in x[t+1:]:
  for k in ('adib_open','adib_high','adib_low','adib_close'):a[k]*=1.5
 ck('future forecast mutation '+str(t),np.array_equal(h.forecast(r[:t+1]),h.forecast(x[:t+1])))
 # Prefix paper decision parity, only change later than last requested step.
 a=h.paper(r,start=30,steps=max(1,t-30),strict=False);b=h.paper(x,start=30,steps=max(1,t-30),strict=False)
 if t>30:ck('future paper mutation '+str(t),a==b)
z=h.paper(r,strict=False);ck('21 marks 20 decisions',len(z['curve'])==21 and len(z['decisions'])==20);ck('portfolio accounting',all(abs(a['equity']-a['cash']-a['shares']*next(q['adib_close'] for q in r if q['date']==a['date']))<1e-6 and a['cash']>=0 and a['shares']>=0 for a in z['curve']));ck('all solver statuses',all(d['status']=='optimal' for d in z['decisions']));ck('next date orders',all(o['execution_date']>o['decision_date'] for o in z['orders']));ck('no future dates',all(d['date']<z['curve'][-1]['date'] for d in z['decisions']));ck('no authorization',not z['live_authorized']);write('historical_paper_curve.csv',z['curve']);write('historical_paper_decisions.csv',z['decisions']);(P/'historical_paper_result.json').write_text(json.dumps(z,indent=2))
w=World();rows=[]
for length in (20,60,120):
 a=h.extended(w,length);ck('extended length '+str(length),len(a['paths'])==10 and all(len(v)==length+1 and min(v)>0 for v in a['paths'].values()));ck('development only '+str(length),all(w.scenarios[b['scenario']]['split']=='train' for b in a['blocks']));ck('reproducible '+str(length),a==h.extended(w,length));
 for t in (0,1,length//2,length):
  b=h.extended_prefix(w,length,t);ck(f'extended prefix {length}:{t}',all(v==a['paths'][k][:t+1] for k,v in b['paths'].items()) and 'blocks' not in b)
 for k,v in a['paths'].items():
  for i,p in enumerate(v):rows.append({'length':length,'instrument_or_factor':k,'step':i,'normalized_value':p,'provenance':'D5'})
write('extended_synthetic_paths.csv',rows)
with tempfile.TemporaryDirectory() as td:
 os.environ['INVESTOR_DB']=td+'/test.sqlite';import server as s
 from fastapi.testclient import TestClient
 c=TestClient(s.app,base_url='http://localhost');ck('anonymous denied',c.get('/historical/api/snapshot').status_code==401);x={'alias':'historical-test','password':'Test-only-password-17'};ck('register',c.post('/account/register',json=x).status_code==200);ck('login',c.post('/account/login',json=x).status_code==200);ck('page',c.get('/historical').status_code==200);ck('dashboard link','/historical' in c.get('/').text);ck('metadata',c.get('/historical/api/meta').json()['count']==51);ck('snapshot',len(c.get('/historical/api/snapshot?step=9').json()['bars'])==10);ck('bad step',c.get('/historical/api/snapshot?step=51').status_code==400);ck('ack gate',c.post('/historical/api/paper',json={}).status_code==400);ck('paper acknowledged',c.post('/historical/api/paper',json={'acknowledge_candidate':True}).status_code==200);ck('extended',len(c.get('/historical/api/extended?length=120&step=10').json()['paths']['EGX:ADIB'])==11);ck('bad length',c.get('/historical/api/extended?length=100&step=10').status_code==400);s.store.db.close()
ck('warehouse unchanged',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip());write('historical_checks.csv',checks);print('Phase17',len(checks),'checks;',len(rows),'D5 points')
