import csv,json,hashlib,sqlite3
from pathlib import Path
P=Path(__file__).parent
# Implementation inventory only: these work-item identifiers are NOT the locked capability IDs.
items=[
('Investor','Account authentication and encrypted persistence','implemented','store.py; server.py; checks.csv','Independent security review; Windows deployment'),
('Investor','Adaptive questionnaire and financial intake','implemented','assessment_adapter.py; assessment.html; checks.csv','Full browser workflow'),
('Investor','Versioned strategy plan and goals','implemented','server.py /api/plan; checks.csv','Full browser workflow'),
('Investor','Safety gates and zero live allocation','implemented','server.py /api/plan; checks.csv','Independent acceptance'),
('Investor','Descriptive progress and simulation evidence','implemented','academy.py evidence; progress.html; integration_checks.csv','No behavioral inference'),
('Investor','Behavioral inference and reassessment','partial','progress.html; academy.py','Validated inference and user-confirmed reassessment absent'),
('Education','31 lessons and 35 curriculum mappings','implemented','academy.py; academy.html; runtime/trading_academy_v1/academy_data.json','Educational effectiveness and browser acceptance'),
('Education','Persistent graded quiz progress and prerequisites','implemented','academy.py; server.py /academy/api/submit; integration_checks.csv','Full browser workflow'),
('Education','Automatic competency-to-assessment feedback','partial','academy.py; assessment_adapter.py','No automatic change to eligibility; reviewed evidence integration pending'),
('Data','Instrument master and icons','implemented','warehouse.sqlite instrument_catalogue; icons/','Official logos and current membership reconciliation'),
('Data','Actual local OHLCV and NAV','partial','warehouse.sqlite history_observation; paired_source.csv','Bulk history, data rights and price adjustment verification'),
('Data','Company statements','partial','warehouse.sqlite fundamental_observation','Only five issuers; publication dates and rights incomplete'),
('Data','Corporate actions and distributions','partial','warehouse.sqlite corporate_action','Complete event coverage and adjustment conventions'),
('Data','Global prices, news and economic series','partial','warehouse.sqlite global_event; macro_observation','Daily international prices and comprehensive chronology missing'),
('Data','Reconstruction and synthetic paths','implemented','warehouse.sqlite recon_synthetic_universe; recon_nav_retrospective','No empirical calibration; D3–D5 not observed prices'),
('Fundamental','Sector-specific financial indicators','implemented','fundamental.py; fundamental_checks.csv','Broader source coverage'),
('Fundamental','DCF, multiples, fee and economic scenarios','implemented','fundamental.py; fundamental.html; fundamental_checks.csv','Hypothetical assumptions only'),
('Fundamental','Actual valuation and compatible peer rankings','partial','fundamental.py; fundamental_coverage.csv','Matched price, shares and accounting inputs insufficient'),
('Technical','Moving averages, RSI, MACD, bands, ATR and other indicators','implemented','technical.py; technical_checks.csv','Historical long-window history insufficient'),
('Technical','Support/resistance and initial candlestick conditions','implemented','technical.py; technical_observed.csv','Advanced patterns and empirical predictive validation'),
('Technical','Multi-timeframe analysis','partial','technical.py; technical.html','Actual intraday, weekly and monthly aligned series absent'),
('Market','Dated news, report vintages and event channels','implemented','intelligence.py; intelligence_checks.csv','Sparse historical archive; no causal effect claims'),
('Market','Sector breadth and evidence agreement','implemented','intelligence.py; intelligence_scenario_summary.csv','Synthetic only; no actual flow estimates'),
('Market','Economic surprises and sentiment','partial','intelligence.py','Historical consensus and empirical scoring missing; trained AI deferred'),
('Replay','Synthetic virtual portfolio and next-step orders','implemented','replay.py; market.html; checks.csv','Simplified execution, single pending order'),
('Replay','Static leverage stress and spread stress','implemented','replay.py; market.html','No actual margin orders or dynamic liquidation'),
('Replay','Order-book reconstruction','partial','warehouse.sqlite recon_intraday_synthetic','Synthetic single-level only; no actual depth or execution capacity'),
('Replay','Extended synthetic viewer','implemented','historical.py; extended_synthetic_paths.csv; historical_checks.csv','Extended order execution not supported'),
('Replay','Historical candidate replay and OR paper experiment','partial','historical.py; paired_source.csv; historical_checks.csv','51 dates only; verified execution blocked'),
('Backtesting','Chronological strategy execution and benchmark comparisons','implemented','backtest.py; backtest_checks.csv','Synthetic assumptions only'),
('Backtesting','Locked strategy execution coverage','partial','backtest_registry.csv; backtest_development_results.csv','11 of 35 prototypes; 24 not implemented'),
('Optimization','Integer allocation and CVaR solver','implemented','optimizer.py; optimizer_checks.csv','Forecasts not calibrated; personal profile not automatically linked'),
('Optimization','Rolling next-step repricing and constraints','implemented','optimizer.py; historical.py; optimizer_checks.csv','Settlement, dynamic margin, realistic order liquidity missing'),
('Optimization','Fundamental/technical/news-conditioned forecasts','partial','optimizer.py; intelligence.py','Independent unconditional/bootstrapped priors only'),
('Risk','Cash, position limits and no negative holdings','implemented','replay.py; optimizer.py; backtest.py','Actual market restrictions not validated'),
('Risk','Dynamic leverage, liquidation and settlement','partial','replay.py; optimizer.py','Static leverage only, settlement not modeled'),
('Interface','Authenticated consolidated workspace navigation','implemented','index.html; server.py; integration_checks.csv','Browser and native Windows acceptance pending'),
('Interface','Data export and account deletion','implemented','store.py; server.py; checks.csv','Independent audit; backups/export retention'),
('Governance','Original 80-capability definition reconciliation','blocked','baseline_recovery.csv; PROJECT_ROADMAP.md','Exact original register unavailable; no definitions inferred'),
('Governance','Verified historical data acceptance','blocked','historical.py gate; historical_checks.csv','Source conflict, corporate actions, reuse rights and calendar completeness'),
('V2','Trained AI and adaptive decision support','deferred_v2','PROJECT_ROADMAP.md phase 18','No model fitting in V1'),
('V2','Live EGX, Thndr and portfolio sync','deferred_v2','PROJECT_ROADMAP.md phases 21–23','Free access and permission verification'),
('V2','Real-time intelligence, AI and optimization','deferred_v2','PROJECT_ROADMAP.md phases 24–26','Validated data and models'),
('V2','Augmented Thndr interface and broker execution','deferred_v2','PROJECT_ROADMAP.md phases 27–28','Broker permission, confirmation, regulatory review'),
('V2','Live risk and V2 acceptance','deferred_v2','PROJECT_ROADMAP.md phases 29–30','Independent validation')]
rows=[dict(work_item=f'W{i:02}',domain=d,description=n,status=s,evidence=e,remaining=g) for i,(d,n,s,e,g) in enumerate(items,1)]
def write(name,rows):
 with (P/name).open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
write('integration_work_items.csv',rows)
# Only recoverable ID ranges are enumerated; no names or definitions assigned.
counts={'AI':8,'CH':11,'FC':9,'OB':10,'TR':6,'OR':15,'RK':6,'BT':1,'TP':5}
known=[dict(known_id=f'{m}-{n:02}',original_definition='',mapping_status='blocked_exact_definition_unavailable') for m,c in counts.items() for n in range(1,c+1)]
write('baseline_recovery.csv',known)
summary={'release':'V1.19 integration candidate','formal_gate':'BLOCKED — original 80 definitions not available','locked_total':80,'known_id_slots':len(known),'unresolved_id_slots':80-len(known),'formal_mappings_verified':0,'note':'Work items are an independent implementation inventory, not the locked register. No original definitions have been reconstructed or changed.','counts':{k:sum(r['status']==k for r in rows) for k in ('implemented','partial','blocked','deferred_v2')},'items':rows}
(P/'integration_status.json').write_text(json.dumps(summary,indent=2))
print(summary['counts'],len(known))
