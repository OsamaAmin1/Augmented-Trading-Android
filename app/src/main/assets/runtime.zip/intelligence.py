"""Read-only chronological evidence synthesis; no trade recommendations or trained model."""
import datetime as dt, math, statistics as st, collections
import fundamental as fa
import technical as ta

CHANNELS={
 'geopolitics':('Energy','Risk appetite','FX','Trade'), 'shipping':('Freight','Suez receipts','FX'), 'health':('Demand','Liquidity','Travel'), 'banking':('Credit','Liquidity'), 'commodity_policy':('Energy','Inflation'), 'gold':('Gold','FX'), 'leverage':('Funding','Liquidity','Contagion'), 'macro_release':('Rates','FX','Valuation'), 'monetary':('Rates','Credit','FX'), 'technology':('Technology demand','Valuation','Risk appetite'), 'trade_policy':('Supply chains','Inflation','Trade'), 'egypt_financing':('FX','Sovereign funding'),
 'earnings':('Profitability','Valuation'), 'capital_action':('Share count','Cash flows'), 'partnership':('Commercial execution','Revenue'), 'fund_inception':('Fund availability',), 'fund_subscription':('Fund flows',), 'guidance':('Expectations',), 'index_membership':('Passive flows',), 'investment_agreement':('Capital expenditure','Execution'), 'regulatory_approval':('Regulatory conditions',), 'trading_status_request':('Trading access',), 'transaction_cancelled':('Execution risk',), 'transaction_proposed':('Execution risk','Valuation')}
# Structural materiality triage, not sentiment, magnitude, or market impact prediction.
PRIORITY={'geopolitics','shipping','leverage','monetary','banking','health','trade_policy','macro_release','egypt_financing','earnings','capital_action','trading_status_request','transaction_cancelled'}
def annotate(r,kind):
 k=r['category' if kind=='global' else 'event_type']; return {**r,'kind':kind,'channels':list(CHANNELS.get(k,('Unclassified',))), 'review_priority':'high_review' if k in PRIORITY else 'standard_review','sentiment':'unassessed','impact':'unmeasured'}
def history(c,cutoff,ident=None):
 cutoff=fa.date(cutoff)
 if ident is not None and not c.execute('select 1 from instrument_catalogue where id=?',(ident,)).fetchone():raise ValueError('Unknown instrument')
 g=[annotate(r,'global') for r in fa.rows(c,"select * from global_event where available_from is not null and available_from!='' and available_from<=? and published_date<=? order by available_from desc,event_id",(cutoff,cutoff))]
 sql="select * from disclosure_event where available_from is not null and available_from!='' and available_from<=? and publication_date<=?";args=[cutoff,cutoff]
 if ident:sql+=' and instrument_id=?';args.append(ident)
 l=[annotate(r,'local') for r in fa.rows(c,sql+' order by available_from desc,event_id',args)]
 # Select latest published vintage for latest period, not a later revision. Conflicting same vintage values withheld.
 rr=fa.rows(c,"select m.*,s.region,s.unit,s.frequency,p.url as source_url from macro_observation m join macro_series s using(series_id) left join macro_source p using(source_id) where m.available_from is not null and m.available_from!='' and m.available_from<=? and m.publication_date<=? and m.period_end<=? order by m.series_id,m.period_end desc,m.available_from desc,m.observation_id",(cutoff,cutoff,cutoff))
 groups=collections.defaultdict(list)
 for r in rr:groups[r['series_id']].append(r)
 macro=[];conflicts=[]
 for k,v in groups.items():
  top=v[0];same=[x for x in v if (x['period_end'],x['available_from'])==(top['period_end'],top['available_from'])]
  if len({x['value'] for x in same})>1:conflicts.append(k);continue
  old=next((x for x in v if x['period_end']<top['period_end']),None)
  if old and len({x['value'] for x in v if (x['period_end'],x['available_from'])==(old['period_end'],old['available_from'])})>1:old=None
  macro.append({**top,'previous_period_value':old['value'] if old else None,'change':top['value']-old['value'] if old else None,'age_days':(dt.date.fromisoformat(cutoff)-dt.date.fromisoformat(top['period_end'])).days,'surprise':None})
 fundamental=None
 if ident:
  f=fa.report(c,ident,cutoff);fundamental={'metrics':f['metrics'],'conflicts':f['conflicts'],'statement_ids':[x['observation_id'] for x in f['statements']]}
 return {'mode':'dated_candidate_context','cutoff':cutoff,'global_events':g,'local_events':l,'macro':macro,'macro_conflicts':conflicts,'fundamental':fundamental,'technical':None,'decision_status':'insufficient_verified_historical_evidence','verified_historical':False,'training_approved':False,'note':'Date-only candidate availability. Historical prices, actual surprises, sentiment and causal reactions unverified; no executable signal.'}

def pct(a,b):return (b/a-1)*100

def movement(p):
 if not p or any(not ta.positive(v) for v in p):raise ValueError('Invalid path')
 return {'value':p[-1],'return_pct':pct(p[0],p[-1]),'step_pct':pct(p[-2],p[-1]) if len(p)>1 else None,'drawdown_pct':(1-p[-1]/max(p))*100}
def direction(v,threshold=.05):return 'up' if v>threshold else 'down' if v< -threshold else 'flat'
def combine(technical,factor):
 if technical is None or factor is None:return 'insufficient_evidence'
 if technical=='flat' or factor=='flat':return 'mixed_or_neutral'
 return 'directional_agreement' if technical==factor else 'directional_conflict'

def replay(c,world,state,ident):
 k=state['scenario'];step=state['step'];paths=world.paths[k];factors=world.factors[k]
 if ident not in paths:raise ValueError('Unknown modeled instrument')
 if type(step)!=int or not 0<=step<len(paths[ident]):raise ValueError('Invalid replay step')
 f={a:movement(v[:step+1]) for a,v in factors.items()};p=[x/100 for x in paths[ident][:step+1]];m=movement(p);cat=world.catalog[ident];model=world.models[ident]
 by=collections.defaultdict(list)
 for i,v in paths.items():
  if world.kind(i)=='exchange' and world.models[i]=='equity_proxy' and world.catalog[i]['category'] and world.catalog[i]['type']!='ETF':by[world.catalog[i]['category']].append(pct(v[0],v[step]))
 allr=[r for v in by.values() for r in v];sectors=[]
 for name,vals in sorted(by.items()):
  if len(vals)<3:continue
  sectors.append({'sector':name,'count':len(vals),'equal_weight_return_pct':st.mean(vals),'positive_fraction':sum(x>0 for x in vals)/len(vals),'relative_to_egx30_pp':st.mean(vals)-f['EGX30']['return_pct']})
 # Fund NAV proxies get return evidence but no stock-style technical signals.
 tech=None;td=None
 if world.kind(ident)!='fund':
  tech=ta.replay(p)['series'][-1];sma=tech['metrics'].get('sma3')
  if sma is not None:td=direction(pct(sma,p[-1]))
 benchmark={'equity_proxy':'EGX30','equity_index_proxy':'EGX30','equity_fund':'EGX30','index_proxy':'EGX30'}.get(model)
 benchmark_note='Generic factor comparator, not a verified tracking benchmark.'
 if model=='gold_fund':
  bench=(1+f['GOLD_USD']['return_pct']/100)*(1+f['USD_EGP']['return_pct']/100)*100-100;benchmark='GOLD_EGP_THEORETICAL'
 elif benchmark:bench=f[benchmark]['return_pct']
 else:bench=None
 fd=direction(bench) if bench is not None and step>0 else None
 # Compare cumulative proxy direction with short-window price/SMA condition; descriptive, differing horizons.
 context=history(c,world.scenarios[k]['available_from'],ident)
 risk={'sampled_drawdown_pct':m['drawdown_pct'],'spread_stress_proxy':abs(f['EGX30']['step_pct'] or 0)>=2 if step else None,'actual_liquidity':'unknown','leverage':'disabled','max_exposure_pct':max((q*paths[i][step] for i,q in state['holdings'].items()),default=0)/world.mark(state)*100 if world.mark(state)>0 else None}
 return {'mode':'D5_replay','step':step,'instrument':cat,'model':model,'movement':m,'factors':f,'breadth':{'count':len(allr),'advances':sum(x>0 for x in allr),'declines':sum(x<0 for x in allr),'unchanged':sum(x==0 for x in allr),'sentiment_proxy':sum(x>0 for x in allr)/len(allr) if step and allr else None},'sectors':sectors,'technical':tech,'technical_direction':td,'benchmark':benchmark,'benchmark_return_pct':bench,'benchmark_note':benchmark_note,'factor_direction':fd,'agreement':combine(td,fd),'risk':risk,'historical_context':context,'simulated_feed':world.feed(k,step),'decision_status':'education_only','training_approved':False,'verified_historical':False,'note':'Synthetic proxy prices, current catalogue sectors; breadth is not actual sentiment, flows or historical membership. Context anchored to event date; no causal or investment recommendation.'}
