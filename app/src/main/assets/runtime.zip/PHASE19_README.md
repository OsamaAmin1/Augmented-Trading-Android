# Augmented Trading V1.19 — integration candidate

Phase 19 is **partial**, not formal acceptance of the locked 80-capability baseline. The recovered summaries identify the locked count, approval and nine known ID ranges (71 slots). Exact definitions and remaining identifiers were not retrieved. `baseline_recovery.csv` records known slots with empty original definitions, not a replacement register. `integration_work_items.csv` is a separate implementation-level inventory: 45 work items, 24 prototype implementations, 14 partial, 2 blocked, 5 deferred to V2. Counts are not capability acceptance metrics. `integration_status.json` drives the authenticated audit page. Phase 18 and live connectivity remain V2.

## What's new
- `/academy` — existing 31-lesson curriculum and 35 strategy mappings, server-scored quizzes, prerequisite enforcement, persistent attempts and best/last scores, encrypted under existing account. Full marks required for lesson completion (new provisional instructional rule); historical pass retained on retry. No automated strategy or eligibility changes. Source curriculum copied unchanged from prior runtime.
- `/progress` — descriptive education and replay evidence, including executed buys/sells, rejection counts, holding count, return and current drawdown. No inferred personality, actual trading or change to financial eligibility.
- `/integration` — filterable implementation work-item inventory and explicit blocked formal gate. Authenticated API routes; existing private account format backward-compatible (new keys created lazily). No private account or test credentials included in release.

## Run
Extract the complete archive, install `requirements.txt`, run `START_WINDOWS.bat` or `python server.py`, open http://127.0.0.1:8767. Sign in or register a fictional local account. Existing private account files are not distributed; make protected backups before migrating. Test with fictional data until independent security review. No data upload, no broker connector. Quiz materials are public within this local distribution; this is practice, not secure certification.

## Verification
79 new integration assertions passed, plus freshly rerun 4,762 existing regression checks (4,841 total). Original warehouse checksum and curriculum bytes unchanged. API tests include all 31 lessons, invalid quiz input, prerequisite gates, answer-key omission before submission, cross-account isolation, restart, persistence, encrypted data scan, unchanged live allocation and descriptive replay evidence. Browser interaction and Windows deployment not verified. JavaScript syntax checks are not browser tests. No additional real historical data or model training. Exact register mapping, remaining gaps and independent acceptance required before phase 20 can pass.

## Files
`academy.py`, `academy.html`, `progress.html`, `integration.html`, `integration_work_items.csv`, `baseline_recovery.csv`, `integration_status.json`, `test_integration.py`, `integration_checks.csv`, `PROJECT_ROADMAP.md`. Existing analytical, simulation and optimization modules retained. `build_audit.py` regenerates the provisional inventory (does not infer original locked definitions).
