import os,tempfile,csv,hashlib,copy,random,json
from pathlib import Path
import intelligence as m, fundamental as f
from replay import World
from fastapi.testclient import TestClient
P=Path(__file__).parent;checks=[];summary=[];coverage=[]
def ck(n,v):
 checks.append({'test':n,'passed':bool(v)});assert v,n
def write(n,rows):
 with (P/n).open('w',newline='') as h:
  w=csv.DictWriter(h,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
w=World();rng=random.Random(14)
with f.connect() as c:
 h=m.history(c,'2026-11-25');ck('historical counts',len(h['global_events'])==21 and len(h['local_events'])==44);ck('no approved labels',not h['training_approved'] and h['technical'] is None);ck('all events classified',all(x['channels']!=['Unclassified'] for x in h['global_events']+h['local_events']));ck('no invented sentiment',all(x['sentiment']=='unassessed' and x['impact']=='unmeasured' for x in h['global_events']+h['local_events']));ck('macro consensus not fabricated',all(x['surprise'] is None for x in h['macro']))
 for cutoff in ['1900-01-01','2020-03-11','2020-03-12','2024-08-02','2024-08-03','2024-09-07','2026-11-25']:
  a=m.history(c,cutoff);ck('chronology '+cutoff,all(x['available_from']<=cutoff for x in a['global_events']+a['local_events']+a['macro']));ck('period cutoff '+cutoff,all(x['period_end']<=cutoff for x in a['macro']))
 a=m.history(c,'2024-08-03');b=m.history(c,'2024-09-07');ck('payroll vintage',next(x['value'] for x in a['macro'] if x['series_id']=='US_PAYROLL')==114000 and next(x['value'] for x in b['macro'] if x['series_id']=='US_PAYROLL')==89000)
 for ident in w.catalog:
  a=m.history(c,'2026-11-25',ident);ck('instrument identity '+ident,all(x['instrument_id']==ident for x in a['local_events']) and all(x['instrument_id']==ident for x in a['fundamental']['metrics']));coverage.append({'id':ident,'dated_disclosures':len(a['local_events']),'dated_fundamental_metrics':len(a['fundamental']['metrics']),'synthetic_model':w.models.get(ident,''),'historical_training_approved':False})
 for k in sorted(w.scenarios):
  for step in range(9):
   state={'scenario':k,'step':step,'cash':10000000,'holdings':{}};a=m.replay(c,w,state,'EGX:ADIB');b=a['breadth'];ck(f'breadth {k} {step}',b['advances']+b['declines']+b['unchanged']==b['count'] and b['count']>0);ck(f'cutoff {k} {step}',a['technical']['time']==step and all(x['step']<=step for x in a['simulated_feed']));ck(f'sectors {k} {step}',all(s['count']>=3 and 0<=s['positive_fraction']<=1 for s in a['sectors']));ck(f'no execution {k} {step}',a['risk']['leverage']=='disabled' and not a['verified_historical'] and not a['training_approved']);
   summary.append({'scenario':k,'step':step,'equity_proxies':b['count'],'advances':b['advances'],'declines':b['declines'],'unchanged':b['unchanged'],'sector_count':len(a['sectors']),'EGX30_pct':a['factors']['EGX30']['return_pct'],'gold_USD_pct':a['factors']['GOLD_USD']['return_pct'],'ADIB_pct':a['movement']['return_pct'],'ADIB_agreement':a['agreement'],'spread_stress_proxy':a['risk']['spread_stress_proxy'],'class':'D5'})
  state={'scenario':k,'step':4,'cash':10000000,'holdings':{}};base=m.replay(c,w,state,'EGX:ADIB');gold=m.replay(c,w,state,'THNDR:FUND:AZG');ck('fund no technical '+k,gold['technical'] is None and gold['agreement']=='insufficient_evidence');ck('gold fx formula '+k,abs(gold['benchmark_return_pct']-((1+gold['factors']['GOLD_USD']['return_pct']/100)*(1+gold['factors']['USD_EGP']['return_pct']/100)-1)*100)<1e-9)
  savedp=copy.deepcopy(w.paths[k]);savedf=copy.deepcopy(w.factors[k]);
  try:
   for arr in w.paths[k].values():arr[5:]=[rng.randint(10,200000) for _ in arr[5:]]
   for arr in w.factors[k].values():arr[5:]=[rng.uniform(1,2000) for _ in arr[5:]]
   ck('future mutation '+k,base==m.replay(c,w,state,'EGX:ADIB'))
  finally:w.paths[k]=savedp;w.factors[k]=savedf
 ck('agreement rules',m.combine('up','up')=='directional_agreement' and m.combine('up','down')=='directional_conflict' and m.combine('flat','up')=='mixed_or_neutral' and m.combine(None,'up')=='insufficient_evidence')
with tempfile.TemporaryDirectory() as td:
 os.environ['INVESTOR_DB']=str(Path(td)/'test.sqlite');import server as s
 A=TestClient(s.app,base_url='http://localhost');B=TestClient(s.app,base_url='http://localhost');ck('history auth',A.get('/intelligence/api/history?cutoff=2026-11-25').status_code==401);ck('page auth',A.get('/intelligence').status_code==401)
 for cl,alias in [(A,'mi_test_a'),(B,'mi_test_b')]:
  p={'alias':alias,'password':'Test-only-password-123'};ck(alias+' register',cl.post('/account/register',json=p).status_code==200);ck(alias+' login',cl.post('/account/login',json=p).status_code==200)
 ck('page',A.get('/intelligence').status_code==200);ck('dashboard link','/intelligence' in A.get('/').text);ck('history endpoint',A.get('/intelligence/api/history?cutoff=2026-11-25').json()['mode']=='dated_candidate_context');ck('invalid date',A.get('/intelligence/api/history?cutoff=bad').status_code==400);ck('unknown instrument',A.get('/intelligence/api/history?cutoff=2026-11-25&id=bad').status_code==400)
 k=next(k for k,v in s.world.scenarios.items() if v['split']=='train');z=A.post('/market/api/start',json={'scenario':k,'capital':100000}).json();p={'id':'EGX:ADIB','replay_id':z['token']};d=A.get('/intelligence/api/replay',params=p).json();ck('initial prefix',d['step']==0 and d['agreement']=='insufficient_evidence');ck('cross account reject',B.get('/intelligence/api/replay',params=p).status_code==400);A.post('/market/api/advance',json={'token':z['token'],'replay_revision':0});ck('next prefix',A.get('/intelligence/api/replay',params=p).json()['step']==1);s.store.db.close()
ck('warehouse checksum',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip());write('intelligence_checks.csv',checks);write('intelligence_scenario_summary.csv',summary);write('intelligence_coverage.csv',coverage);print('PASS',len(checks),'snapshots',len(summary),'coverage',len(coverage))
