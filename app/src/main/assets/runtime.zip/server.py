from pathlib import Path
import os, json, secrets, threading, copy, time
from fastapi import FastAPI,Request
from fastapi.responses import JSONResponse,FileResponse
from cryptography.exceptions import InvalidTag
import uvicorn
import assessment_adapter as a
from replay import World
from store import Store,now
P=Path(__file__).resolve().parent
app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None);store=Store(os.getenv('INVESTOR_DB',str(P/'private'/'investors.sqlite')));world=World();V=a.V;rec=a.rec

def reply(x,code=200):return JSONResponse(rec.plain(x),status_code=code)
def token(r):return r.cookies.get('investor_session','')
def event(s,kind,**details):s['events'].append({'time':now(),'kind':kind,**details})
def draft(s,ident):
 d=s['draft']
 if not d or d['id']!=ident:raise ValueError('Assessment missing or superseded')
 return d
@app.middleware('http')
async def security(r,call):
 host=r.headers.get('host','');origin=r.headers.get('origin')
 if host not in ('localhost','127.0.0.1') and not (host.startswith(('localhost:','127.0.0.1:')) and host.rsplit(':',1)[-1].isdigit()):return reply({'error':'Localhost only'},403)
 if r.method=='POST':
  if origin not in ('http://'+host,None) or r.headers.get('sec-fetch-site')=='cross-site':return reply({'error':'Origin rejected'},403)
  if r.headers.get('content-type','').split(';')[0]!='application/json':return reply({'error':'JSON required'},415)
  if len(await r.body())>256*1024:return reply({'error':'Request too large'},413)
 try:out=await call(r)
 except PermissionError:out=reply({'error':'Sign in required'},401)
 except (ValueError,KeyError,TypeError,OverflowError,InvalidTag) as e:out=reply({'error':str(e) if isinstance(e,ValueError) else 'Invalid request or unreadable account'},400)
 out.headers['Cache-Control']='no-store';out.headers['X-Content-Type-Options']='nosniff';out.headers['Referrer-Policy']='no-referrer';out.headers['X-Frame-Options']='SAMEORIGIN';return out
@app.get('/')
def home():return FileResponse(P/'index.html')
@app.get('/assessment')
def assessment(r:Request):store.auth(token(r));return FileResponse(P/'assessment.html')
@app.get('/market')
def market(r:Request):store.auth(token(r));return FileResponse(P/'market.html')
@app.get('/icons/{name}')
def icon(name:str):
 p=P/'icons'/name
 if p.suffix!='.svg' or not p.is_file():return reply({'error':'Missing'},404)
 return FileResponse(p)
@app.post('/account/{action}')
def account(action:str,x:dict,r:Request):
 with store.lock:
  if action=='register':store.register(x['alias'],x['password']);return reply({'created':True})
  if action=='login':
   t=store.login(x['alias'],x['password']);store.logout(token(r));out=reply({'signed_in':True});out.set_cookie('investor_session',t,httponly=True,samesite='strict',max_age=3600,path='/');return out
  if action=='logout':store.logout(token(r));out=reply({'signed_out':True});out.delete_cookie('investor_session');return out
  if action=='delete':store.delete(token(r),x['password']);out=reply({'deleted':True});out.delete_cookie('investor_session');return out
  raise ValueError('Unknown action')
@app.get('/api/profile')
def profile(r:Request):
 with store.lock:
  s,rev=store.read(token(r));latest=s['assessments'][-1] if s['assessments'] else None
  return reply({'revision':rev,'draft':bool(s['draft']),'assessments':[{'id':z['id'],'created':z['created'],'status':z['result']['status'],'current':z['current'],'foundation':z['result']['plan'].get('foundation'),'market_alloc':z['result']['plan'].get('market_alloc'),'approved_allocation':0} for z in s['assessments']], 'replays':[{'id':i,'scenario':z['state']['scenario'],'step':z['state']['step'],'updated':z['updated'],'equity':world.mark(z['state'])/100,'completed':z['state']['step']==8} for i,z in s['replays'].items()], 'events':s['events'][-30:], 'live_authorized':False,'approved_allocation':0})
@app.get('/api/export')
def export(r:Request):
 with store.lock:s,_=store.read(token(r));return reply({'warning':'Sensitive decrypted export; keep private','profile':s})
@app.get('/api/schema')
def schema(r:Request):store.auth(token(r));return a.schema()
@app.get('/api/resume')
def resume(r:Request):
 with store.lock:
  s,_=store.read(token(r));d=s['draft']
  if not d:return reply({'stage':'none'})
  return reply({'session':d['id'],'first':d['first'],**a.compute(copy.deepcopy(d))})
@app.post('/api/start')
def start(x:dict,r:Request):
 with store.lock:
  s,rev=store.read(token(r));a.validate(x,V.FIRST)
  if V.initial_input(x)[0] is None or x['monthly_expenses']+x['monthly_debt_payment']<=0:raise ValueError('Invalid financial intake')
  d={'id':secrets.token_hex(16),'first':x,'answers':[]};out=a.compute(d);d.pop('discovery',None);s['draft']=d
  for z in s['assessments']:z['current']=False
  event(s,'assessment_started',id=d['id']);store.write(token(r),s,rev);return reply({'session':d['id'],**out})
@app.post('/api/answer')
def answer(x:dict,r:Request):
 with store.lock:
  s,rev=store.read(token(r));d=draft(s,x['session']);pending=a.compute(d)
  if pending['stage']!='question' or x['id']!=pending['question']['id'] or x['answer'] not in ('A','B'):raise ValueError('Invalid or stale answer')
  d['answers'].append({'id':x['id'],'answer':x['answer']});out=a.compute(d);d.pop('discovery',None);store.write(token(r),s,rev);return reply(out)
@app.post('/api/plan')
def plan(x:dict,r:Request):
 with store.lock:
  s,rev=store.read(token(r));d=draft(s,x['session']);a.compute(d);i=d.get('discovery')
  if not i:raise ValueError('Discovery incomplete')
  full=x['full'];gs=x['goals'];a.validate(full,V.FIELDS)
  out,g,sc,st,review=rec.finalize(i,d['first'],full,gs,d['id'],x.get('approval'))
  result=rec.plain({'status':st,'review':review,'plan':out,'goals':g,'scenarios':sc,'live_authorized':False})
  if out is not None:
   if out['live_authorized'] or out['approved_allocation']!=0:raise ValueError('Safety check failed')
   s['assessments'].append({'id':d['id'],'created':now(),'current':True,'input':full,'goals':gs,'answers':d['answers'],'result':result});s['draft']=None;event(s,'assessment_completed',id=d['id'],status=st);store.write(token(r),s,rev)
  return reply(result)
@app.get('/market/api/{action}')
def market_get(action:str,r:Request):
 with store.lock,world.lock:
  s,_=store.read(token(r));q=r.query_params
  if action=='meta':return reply(world.meta())
  if action=='evidence':return reply(world.evidence(q['date']))
  if action=='samples':return reply(world.samples(q['id']))
  if action=='state' or action=='chart':
   t=q['token'];z=s['replays'].get(t)
   if not z:raise ValueError('Unknown replay')
   world.sessions[t]=copy.deepcopy(z['state'])
   try:return reply({**world.state(t),'token':t,'replay_revision':z['revision']} if action=='state' else world.chart(t,q['id']))
   finally:world.sessions.pop(t,None)
  raise ValueError('Unknown action')
@app.post('/market/api/{action}')
def market_post(action:str,x:dict,r:Request):
 with store.lock,world.lock:
  s,rev=store.read(token(r))
  if action=='leverage':return reply(world.leverage(x['capital'],x['multiple'],x['shock']))
  if action=='start':
   if len(s['replays'])>=100:raise ValueError('Replay limit reached')
   out=world.start(x['scenario'],x.get('capital',100000),x.get('expose',False));t=out['token'];state=world.sessions.pop(t);s['replays'][t]={'state':state,'revision':0,'updated':now()};event(s,'replay_started',id=t,scenario=state['scenario']);store.write(token(r),s,rev);return reply({**out,'replay_revision':0})
  t=x['token'];z=s['replays'].get(t)
  if not z:raise ValueError('Unknown replay')
  if type(x.get('replay_revision')) is not int or x['replay_revision']!=z['revision']:raise ValueError('Stale replay; reopen from dashboard')
  world.sessions[t]=copy.deepcopy(z['state'])
  try:
   if action=='order':out=world.order(t,x['id'],x['side'],x['quantity'])
   elif action=='cancel':out=world.cancel(t)
   elif action=='advance':out=world.advance(t)
   else:raise ValueError('Unknown action')
   z['state']=world.sessions[t];z['revision']+=1;z['updated']=now();event(s,'virtual_'+action,id=t,step=z['state']['step']);store.write(token(r),s,rev);return reply({**out,'replay_revision':z['revision']})
  finally:world.sessions.pop(t,None)
@app.get('/api/assessment/{ident}')
def assessment_detail(ident:str,r:Request):
 with store.lock:
  s,_=store.read(token(r));z=next((x for x in s['assessments'] if x['id']==ident),None)
  if z is None:raise ValueError('Assessment not found')
  return reply({'id':ident,'current':z['current'],'created':z['created'],'result':z['result']})
import fundamental as fa
@app.get('/fundamental')
def fundamental_page(r:Request):store.auth(token(r));return FileResponse(P/'fundamental.html')
@app.get('/fundamental/api/catalogue')
def fundamental_catalogue(r:Request):
 store.auth(token(r))
 with fa.connect() as c:return reply(fa.catalogue(c))
@app.get('/fundamental/api/report')
def fundamental_report(r:Request,id:str,cutoff:str=''):
 store.auth(token(r))
 with fa.connect() as c:return reply(fa.report(c,id,cutoff or None))
@app.get('/fundamental/api/peers')
def fundamental_peers(r:Request,id:str,cutoff:str=''):
 store.auth(token(r))
 with fa.connect() as c:return reply(fa.peers(c,id,cutoff or None))
@app.post('/fundamental/api/scenario')
def fundamental_scenario(r:Request,x:dict):
 store.auth(token(r));kind=x['kind'];args=x['args'];fn={'dcf':fa.dcf,'multiple':fa.multiple,'fund_cost':fa.fund_cost,'sensitivity':fa.sensitivity}.get(kind)
 if fn is None or not isinstance(args,dict):raise ValueError('Unknown scenario')
 return reply(fn(**args))
import technical as ta
@app.get('/technical')
def technical_page(r:Request):store.auth(token(r));return FileResponse(P/'technical.html')
@app.get('/technical/api/catalogue')
def technical_catalogue(r:Request):
 store.auth(token(r))
 with ta.connect() as c:return reply(ta.catalogue(c))
@app.get('/technical/api/observed')
def technical_observed(r:Request,id:str,cutoff:str=''):
 store.auth(token(r))
 with ta.connect() as c:return reply(ta.observed(c,id,cutoff or None))
@app.get('/technical/api/anchors')
def technical_anchors(r:Request,id:str):
 store.auth(token(r))
 with ta.connect() as c:return reply(ta.anchors(c,id))
@app.get('/technical/api/intraday')
def technical_intraday(r:Request,id:str,anchor:str,step:int=23):
 store.auth(token(r))
 with ta.connect() as c:return reply(ta.intraday(c,id,anchor,step))
@app.get('/technical/api/replay')
def technical_replay(r:Request,id:str,replay_id:str):
 with store.lock,world.lock:
  s,_=store.read(token(r));z=s['replays'].get(replay_id)
  if not z:raise ValueError('Unknown replay')
  state=z['state'];path=world.paths[state['scenario']].get(id)
  if path is None:raise ValueError('Unknown modeled instrument')
  return reply(ta.replay([x/100 for x in path[:state['step']+1]]))
import intelligence as mi
@app.get('/intelligence')
def intelligence_page(r:Request):store.auth(token(r));return FileResponse(P/'intelligence.html')
@app.get('/intelligence/api/history')
def intelligence_history(r:Request,cutoff:str,id:str=''):
 store.auth(token(r))
 with fa.connect() as c:return reply(mi.history(c,cutoff,id or None))
@app.get('/intelligence/api/replay')
def intelligence_replay(r:Request,replay_id:str,id:str):
 with store.lock,world.lock:
  s,_=store.read(token(r));z=s['replays'].get(replay_id)
  if not z:raise ValueError('Unknown replay')
  with fa.connect() as c:return reply(mi.replay(c,world,z['state'],id))
import backtest as bt
@app.get('/backtest')
def backtest_page(r:Request):store.auth(token(r));return FileResponse(P/'backtest.html')
@app.get('/backtest/api/meta')
def backtest_meta(r:Request):
 store.auth(token(r));return reply({'strategies':bt.registry(),'scenarios':[{'scenario_id':k,'family':v['family'],'split':v['split']} for k,v in world.scenarios.items()],'instruments':[world.catalog[i] for i,m in world.models.items() if m=='equity_proxy' and world.kind(i)=='exchange']})
@app.post('/backtest/api/run')
def backtest_run(r:Request,x:dict):
 store.auth(token(r));params=x.get('params',{});allowed={'capital','allocation','stop','drawdown','fee_bps','normal_spread','stress_spread','slippage'}
 if not isinstance(params,dict) or set(params)-allowed:raise ValueError('Unknown parameters')
 with world.lock:return reply(bt.experiment(world,x['scenario'],x['id'],x['strategy'],x.get('expose',False),**params))
@app.get('/backtest/api/historical')
def backtest_historical(r:Request,id:str):
 store.auth(token(r))
 with world.lock:return reply(bt.historical_gate(world,id))
import optimizer as opt
@app.get('/optimizer')
def optimizer_page(r:Request):store.auth(token(r));return FileResponse(P/'optimizer.html')
@app.post('/optimizer/api/run')
def optimizer_run(r:Request,x:dict):
 store.auth(token(r));params=x.get('params',{});allowed={'capital','horizon','risk','reserve','asset_cap','portfolio_cap','turnover','alpha','fee_bps','spread_bps'}
 if not isinstance(params,dict) or set(params)-allowed:raise ValueError('Unknown parameters')
 with world.lock:return reply(opt.experiment(world,x['scenario'],x['ids'],x.get('expose',False),x.get('initial_holdings'),**params))
import historical as hr
@app.get('/historical')
def historical_page(r:Request):store.auth(token(r));return FileResponse(P/'historical.html')
@app.get('/historical/api/meta')
def historical_meta(r:Request):
 store.auth(token(r));data=hr.load();return reply({'count':len(data),'gate':hr.gate(),'start':data[0]['date'],'end':data[-1]['date']})
@app.get('/historical/api/snapshot')
def historical_snapshot(r:Request,step:int=0):
 store.auth(token(r));return reply(hr.snapshot(hr.load(),step))
@app.post('/historical/api/paper')
def historical_paper(r:Request,x:dict):
 store.auth(token(r));
 if x.get('acknowledge_candidate') is not True:raise ValueError('Explicit candidate-only acknowledgement required; verified historical execution blocked')
 return reply(hr.paper(hr.load(),strict=False))
@app.get('/historical/api/extended')
def historical_extended(r:Request,length:int=20,step:int=0):
 store.auth(token(r));
 with world.lock:return reply(hr.extended_prefix(world,length,step))
import academy as ac
@app.get('/academy')
def academy_page(r:Request):store.auth(token(r));return FileResponse(P/'academy.html')
@app.get('/academy/api/catalogue')
def academy_catalogue(r:Request):
 with store.lock:s,_=store.read(token(r));return reply(ac.catalogue(s))
@app.get('/academy/api/lesson')
def academy_lesson(r:Request,id:str):
 with store.lock:s,_=store.read(token(r));return reply(ac.lesson(s,id))
@app.post('/academy/api/submit')
def academy_submit(r:Request,x:dict):
 with store.lock:
  s,rev=store.read(token(r));out=ac.submit(s,x['id'],x['answers'],now());event(s,'academy_quiz',id=x['id'],passed=out['passed_this_attempt']);store.write(token(r),s,rev);return reply(out)
@app.get('/progress')
def progress_page(r:Request):store.auth(token(r));return FileResponse(P/'progress.html')
@app.get('/progress/api/evidence')
def progress_evidence(r:Request):
 with store.lock:s,_=store.read(token(r));return reply(ac.evidence(s))
@app.get('/integration')
def integration_page(r:Request):store.auth(token(r));return FileResponse(P/'integration.html')
@app.get('/integration/api/status')
def integration_status(r:Request):
 store.auth(token(r))
 return reply(json.loads((P/'integration_status.json').read_text()))
if __name__=='__main__':uvicorn.run(app,host='127.0.0.1',port=8767,access_log=False)
