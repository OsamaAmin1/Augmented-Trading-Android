import csv,hashlib,random,tempfile,os
from pathlib import Path
from replay import World
import backtest as b
P=Path(__file__).parent;checks=[];rows=[];w=World()
def ck(n,v):checks.append({'test':n,'passed':bool(v)});assert v,n
def write(name,data):
 with (P/name).open('w',newline='') as f:
  q=csv.DictWriter(f,fieldnames=list(data[0]));q.writeheader();q.writerows(data)
ck('locked IDs',len(b.registry())==35 and len(b.RULES)==11)
for k,v in w.scenarios.items():
 if v['split']!='train':continue
 for i in ['EGX:ADIB','EGX:COMI','EGX:ABUK','EGX:ETEL','EGX:FWRY']:
  for st in b.RULES:
   z=b.experiment(w,k,i,st);ck(f'{k} {i} {st} accounting',all(x['cash']>=0 and x['quantity']>=0 and abs(x['cash']+x['quantity']*x['mark']-x['equity'])<.001 for x in z['curve']));ck(f'{k} {i} {st} chronology',all(o['execution_step']==o['submitted_step']+1 for o in z['orders']));rows.append({a:z[a] for a in ['scenario','instrument_id','strategy','return_pct','max_drawdown_pct','ending_equity','filled','rejected','fees','spread_slippage','excess_vs_buy_hold_pct','benchmark_gross_pct']})
for st in b.RULES:
 p=[10000,10100,9800,10300,10500,9900,11000,9500,10500];f=[100]*9
 for t in range(8):
  a=b.run(p,f,st,limit=t);q=p[:t+1]+[20000]*(8-t);z=b.run(q,f,st,limit=t);ck(f'{st} prefix {t}',a==z)
ck('historical gate',all(not b.historical_gate(w,i)['eligible'] for i in w.catalog))
try:b.experiment(w,'TARIFF-mild','EGX:ADIB','ST-09');ck('holdout rejected',False)
except ValueError:ck('holdout rejected',True)
with tempfile.TemporaryDirectory() as td:
 os.environ['INVESTOR_DB']=td+'/test.sqlite';import server as s
 from fastapi.testclient import TestClient
 c=TestClient(s.app,base_url='http://localhost');ck('API anonymous',c.get('/backtest/api/meta').status_code==401)
 x={'alias':'backtest-test','password':'Test-only-password-123'};ck('register',c.post('/account/register',json=x).status_code==200);ck('login',c.post('/account/login',json=x).status_code==200);ck('page',c.get('/backtest').status_code==200);ck('meta',len(c.get('/backtest/api/meta').json()['strategies'])==35);ck('API experiment',c.post('/backtest/api/run',json={'scenario':'WAR-mild','id':'EGX:ADIB','strategy':'ST-09'}).status_code==200);s.store.db.close()
ck('warehouse hash',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip());write('backtest_checks.csv',checks);write('backtest_development_results.csv',rows);write('backtest_registry.csv',b.registry());print('Phase15',len(checks),len(rows))
