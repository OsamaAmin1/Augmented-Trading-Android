import os,tempfile,csv,hashlib,math,random,copy,sqlite3
from pathlib import Path
import fundamental as f
from fastapi.testclient import TestClient
P=Path(__file__).parent; checks=[]
def ck(n,v):
 checks.append({'test':n,'passed':bool(v)});assert v,n
def reject(fn):
 try:fn();return False
 except (ValueError,TypeError,OverflowError):return True
with f.connect() as c:
 catalog=f.catalogue(c); reports=[f.report(c,i['id']) for i in catalog];dated=[f.report(c,i['id'],'2026-11-25') for i in catalog]
 ck('catalogue count',len(catalog)==387);ck('raw observations retained',sum(r['raw_count'] for r in reports)==206);ck('vintage selection count',sum(len(r['statements']) for r in reports)==198)
 ck('dated only count',sum(len(r['statements']) for r in dated)==76)
 for r,d in zip(reports,dated):
  ids={x['observation_id'] for x in r['statements']};ck('lineage '+r['instrument']['id'],all(set(m['input_ids'].split('|'))<=ids and m['training_approved']==0 for m in r['metrics']) and all(x['available_from'] and x['available_from']<='2026-11-25' for x in d['statements']) and not d['fund_terms'] and not d['fund_nav_samples'])
 com=f.report(c,'EGX:COMI');adib=f.report(c,'EGX:ADIB');etel=f.report(c,'EGX:ETEL');az=f.report(c,'THNDR:FUND:AZG')
 def get(r,name,period='2025-12-31',basis=None):return next(m['value'] for m in r['metrics'] if m['metric']==name and m['period_end']==period and (not basis or m['accounting_basis']==basis))
 ck('CIB balance residual',get(com,'balance_sheet_residual')==0);ck('ADIB balance residual',get(adib,'balance_sheet_residual')==0);ck('CIB equity ratio',abs(get(com,'equity_assets')-15.525987835601363)<1e-10);ck('ADIB equity ratio',abs(get(adib,'equity_assets')-9.989972)<.001)
 ck('ETEL EBITDA margin',abs(get(etel,'ebitda_margin')-44.51733833177)<1e-8);ck('bank nonbank exclusion',not any(m['metric'] in f.NONBANK_ONLY for m in com['metrics']));ck('bank peer incompatible bases',not f.peers(c,'EGX:COMI'));ck('fund profile',len(az['fund_terms'])==1 and len(az['fund_nav_samples'])==1);ck('fund no corporate ratios',not az['metrics']);ck('unknown cutoff ADIB withheld',not f.report(c,'EGX:ADIB','2026-11-25')['statements']);ck('CIB before publication withheld',not f.report(c,'EGX:COMI','2026-02-10')['statements']);ck('CIB after publication',len(f.report(c,'EGX:COMI','2026-02-11')['statements'])==46);ck('future FWRY earnings excluded',all(r['available_from']<='2025-01-01' for r in f.report(c,'EGX:FWRY','2025-01-01')['statements']));ck('unknown identifier rejects',reject(lambda:f.report(c,'bad')));ck('invalid cutoff rejects',reject(lambda:f.report(c,'EGX:COMI','bad')))
 row=copy.deepcopy(com['statements'][0]);alt=copy.deepcopy(row);alt['observation_id']='test';alt['normalized_value']+=1
 ck('conflicting same vintage excluded',len(f.select_vintage([row,alt])[0])==0 and len(f.select_vintage([row,alt])[1])==1)
 ck('no historical training approval',all(not x['training_approved'] for r in reports for x in r['statements']))
 # Generate static exports for analysis, not training.
 def export(n,rr):
  with (P/n).open('w',newline='',encoding='utf-8') as h:
   w=csv.DictWriter(h,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
 export('fundamental_metrics.csv',[m for r in reports for m in r['metrics']]);export('fundamental_coverage.csv',[{'id':r['instrument']['id'],'symbol':r['instrument']['symbol'],'model':r['model'],'financial_raw':r['raw_count'],'selected':len(r['statements']),'metrics':len(r['metrics']),'dated_selected':len(d['statements']),'fund_profile':len(r['fund_terms']),'nav_series':len(r['fund_nav_samples']),'dividend_events':len(r['dividend_events']),'training_approved':0} for r,d in zip(reports,dated)])
ck('dcf perpetuity identity',abs(f.dcf(100,0,.1,0,5)['enterprise_value']-1000)<1e-8);ck('negative enterprise cash flow rejected',reject(lambda:f.dcf(-1,0,.1,0,5)));ck('terminal rate guard',reject(lambda:f.dcf(100,0,.1,.1,5)));ck('invalid years guard',reject(lambda:f.dcf(100,0,.1,0,0)));ck('invalid shares guard',reject(lambda:f.dcf(100,0,.1,0,5,shares=0)));ck('nonfinite guard',reject(lambda:f.dcf(float('nan'),0,.1,0,5)));ck('multiple identity',f.multiple(5,8)['per_share']==40);ck('negative EPS not valued',reject(lambda:f.multiple(-1,8)));ck('fund fee identity',abs(f.fund_cost(100000,.15,.02,.01)['ending']-111573)<1e-7);ck('fund invalid fees',reject(lambda:f.fund_cost(1,0,1,0)));ck('sensitivity identity',f.sensitivity(100e6,75e6,30e6,.4,.03,.15)['post_shock_surplus_before_existing_interest_tax']==19600000)
rng=random.Random(12)
for n in range(100):
 cf=rng.uniform(1,100000);g=rng.uniform(-.1,.15);w=rng.uniform(.15,.5);t=rng.uniform(0,.08);y=rng.randrange(1,15);a=f.dcf(cf,g,w,t,y);b=f.dcf(cf,g,w+.01,t,y);ck('discount rate sensitivity '+str(n),a['enterprise_value']>b['enterprise_value'] and abs(a['enterprise_value']-a['pv_explicit']-a['pv_terminal'])<1e-6)
with tempfile.TemporaryDirectory() as td:
 os.environ['INVESTOR_DB']=str(Path(td)/'test.sqlite');import server as s
 A=TestClient(s.app,base_url='http://localhost');ck('anonymous page blocked',A.get('/fundamental').status_code==401);ck('anonymous catalogue blocked',A.get('/fundamental/api/catalogue').status_code==401);ck('anonymous scenario blocked',A.post('/fundamental/api/scenario',json={'kind':'multiple','args':{'value':5,'mult':8}}).status_code==401)
 pw='fictional-test-pass-123';ck('register',A.post('/account/register',json={'alias':'test_account','password':pw}).status_code==200);ck('login',A.post('/account/login',json={'alias':'test_account','password':pw}).status_code==200);ck('dashboard link','/fundamental' in A.get('/').text);ck('page served',A.get('/fundamental').status_code==200);ck('catalogue api',len(A.get('/fundamental/api/catalogue').json())==387);ck('report api',len(A.get('/fundamental/api/report',params={'id':'EGX:COMI'}).json()['metrics'])==46);ck('peers API',A.get('/fundamental/api/peers',params={'id':'EGX:COMI'}).json()==[]);ck('scenario API',A.post('/fundamental/api/scenario',json={'kind':'multiple','args':{'value':5,'mult':8}}).json()['per_share']==40);ck('invalid scenario rejected',A.post('/fundamental/api/scenario',json={'kind':'dcf','args':{'fcff':100,'growth':0,'wacc':.1,'terminal':.1,'years':5}}).status_code==400);ck('old profile API',A.get('/api/profile').json()['approved_allocation']==0);ck('old market API',A.get('/market/api/meta').status_code==200);s.store.db.close()
ck('warehouse hash unchanged',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip())
with (P/'fundamental_checks.csv').open('w',newline='') as h:w=csv.DictWriter(h,fieldnames=['test','passed']);w.writeheader();w.writerows(checks)
print('PASS',len(checks))
