import csv,hashlib,random,tempfile,os,math
from pathlib import Path
import numpy as np
from replay import World
from optimizer import *
P=Path(__file__).parent;w=World();checks=[];rows=[]
def ck(n,v):checks.append({'test':n,'passed':bool(v)});assert v,n
def write(name,data):
 with (P/name).open('w',newline='') as f:
  q=csv.DictWriter(f,fieldnames=list(data[0]));q.writeheader();q.writerows(data)
p=parameters();ck('favorable buys',optimize(10000000,[0],[10000],np.array([[1.2],[1.3]]),p)['buy'][0]>0);ck('adverse sells',optimize(5000000,[500],[10000],np.array([[.8],[.9]]),p)['sell'][0]>0);ck('adverse cash hold',optimize(10000000,[0],[10000],np.array([[.8],[.9]]),p)['buy']==[0]);ck('infeasible',optimize(0,[100],[10000],np.array([[1.1],[.9]]),parameters(turnover=0))['status']=='infeasible')
# independent exact enumeration of small one-asset integer problems
rng=random.Random(1602)
for t in range(60):
 cash=100000;held=[rng.randrange(0,8)];marks=[10000];fac=np.array([[rng.uniform(.8,1.3)] for _ in range(7)]);p=parameters(risk=rng.choice([0,.4,1,2]),reserve=10,asset_cap=70,portfolio_cap=80,turnover=60,alpha=.8);r=optimize(cash,held,marks,fac,p);eq=cash+held[0]*marks[0];choices=[]
 for target in range(30):
  b=[max(0,target-held[0])];s=[max(0,held[0]-target)];c,h,_,status=execute(cash,held,marks,b,s,p)
  if status.startswith('rejected'):continue
  loss=1-(c+fac[:,0]*h[0]*marks[0])/eq;tail=min(v+np.maximum(loss-v,0).mean()/(1-p['alpha']) for v in [0,*[x for x in loss if x>0]]);choices.append((-loss.mean()-p['risk']*tail)*100)
 ck('exhaustive objective '+str(t),bool(choices) and r['status']=='optimal' and abs(max(choices)-r['objective_pct'])<1e-6)
for k,v in w.scenarios.items():
 if v['split']!='train':continue
 for name,ids,h in [('ADIB20',['EGX:ADIB'],20),('ADIB1',['EGX:ADIB'],1),('3-equities',['EGX:ADIB','EGX:COMI','EGX:FWRY'],20),('existing ADIB',['EGX:ADIB'],20)]:
  z=experiment(w,k,ids,horizon=h,initial_holdings=[100] if name=='existing ADIB' else None);ck(k+name+' no future pool',all(w.scenarios[j]['split']=='train' and w.scenarios[j]['family']!=v['family'] for j in z['forecast_pool']));ck(k+name+' accounting',all(x['cash']>=0 and min(x['holdings'])>=0 and abs(x['equity']-x['cash']-sum(q*w.paths[k][i][x['step']]/100 for q,i in zip(x['holdings'],ids)))<.001 for x in z['curve']));ck(k+name+' chronology',all(o['execution_step']==o['submitted_step']+1 for o in z['orders']));ck(k+name+' optimum',all(d['status']=='optimal' for d in z['decisions']));rows.append({'scenario':k,'case':name,'return_pct':z['return_pct'],'passive_pct':z['passive']['return_pct'],'egx30_pct':z['benchmark_gross_pct'],'drawdown_pct':z['max_drawdown_pct'],'ending_equity':z['ending_equity'],'cost':z['cost_total'],'filled':sum(o['status']=='filled' for o in z['orders']),'rejected':sum(o['status'].startswith('rejected') for o in z['orders'])})
for k in ['WAR-mild','AI_BOOM-severe']:
 for t in range(8):
  a=experiment(w,k,['EGX:ADIB'],limit=t);path=w.paths[k]['EGX:ADIB'];old=path[:];path[t+1:]=[20000]*(8-t);b=experiment(w,k,['EGX:ADIB'],limit=t);path[:]=old;ck(f'prefix mutation {k} {t}',a==b)
try:experiment(w,'TARIFF-mild',['EGX:ADIB']);ck('holdout gate',False)
except ValueError:ck('holdout gate',True)
with tempfile.TemporaryDirectory() as td:
 os.environ['INVESTOR_DB']=td+'/test.sqlite';import server as s
 from fastapi.testclient import TestClient
 c=TestClient(s.app,base_url='http://localhost');body={'scenario':'WAR-mild','ids':['EGX:ADIB'],'params':{'horizon':20}};ck('API anonymous',c.post('/optimizer/api/run',json=body).status_code==401);x={'alias':'optimizer-test','password':'Test-only-password-123'};ck('register',c.post('/account/register',json=x).status_code==200);ck('login',c.post('/account/login',json=x).status_code==200);ck('page',c.get('/optimizer').status_code==200);ck('API run',c.post('/optimizer/api/run',json=body).status_code==200);ck('API holdout',c.post('/optimizer/api/run',json={**body,'scenario':'TARIFF-mild'}).status_code==400);ck('API unknown param',c.post('/optimizer/api/run',json={**body,'params':{'bad':1}}).status_code==400);s.store.db.close()
ck('warehouse hash',hashlib.sha256((P/'warehouse.sqlite').read_bytes()).hexdigest()==(P/'warehouse.sha256').read_text().strip());write('optimizer_checks.csv',checks);write('optimizer_development_results.csv',rows);print('Phase16',len(checks),len(rows))
