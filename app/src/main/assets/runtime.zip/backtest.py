"""D5-only strategy experiments; no real orders, historical approval or personalized advice."""
import csv, math, statistics
from pathlib import Path
from replay import money, fee
P=Path(__file__).resolve().parent
RULES={
 'ST-09':'Enter at step zero, hold to end.',
 'ST-18':'Above SMA5 and SMA5 rising (requires six prices).',
 'ST-19':'Enter on positive one-step change after a negative change; exit on a negative change.',
 'ST-20':'Long when SMA3 exceeds SMA5; otherwise cash.',
 'ST-21':'Long when trailing three-step return is positive; otherwise cash.',
 'ST-22':'Enter above prior three closing prices; exit below their minimum.',
 'ST-23':'Enter above SMA5 on a negative one-step return; exit below SMA5.',
 'ST-24':'Enter in bottom quarter of prior three-price range; exit in top quarter.',
 'ST-25':'Enter below SMA3 by 1%; exit at or above SMA3.',
 'ST-30':'Long when trailing three-step return exceeds matched EGX30 return and is positive.',
 'ST-34':'Long when own three-step return and EGX30 three-step return are positive; otherwise cash.'}

def registry():
 with (P/'runtime/strategy_reference_v2/strategy_register.csv').open() as f: rows=list(csv.DictReader(f))
 return [{'id':r['id'],'name':r['name'],'status':'synthetic_proxy' if r['id'] in RULES else 'not_implemented','rule':RULES.get(r['id'],'Requires additional strategy logic or evidence; no backtest generated.')} for r in rows]

def signal(k,p,b,held):
 n=len(p);c=p[-1];d=c/p[-2]-1 if n>=2 else 0;avg=lambda m:sum(p[-m:])/m
 if k=='ST-09':return True
 if k=='ST-18':return c>avg(5) and avg(5)>sum(p[-6:-1])/5 if n>=6 else False
 if k=='ST-19':return (d>=0 if held else d>0 and p[-2]<p[-3]) if n>=3 else False
 if k=='ST-20':return avg(3)>avg(5) if n>=5 else False
 if k=='ST-21':return c>p[-4] if n>=4 else False
 if k=='ST-22':return (c>=min(p[-4:-1]) if held else c>max(p[-4:-1])) if n>=4 else False
 if k=='ST-23':return (c>=avg(5) if held else c>avg(5) and d<0) if n>=5 else False
 if k=='ST-24':
  if n<4:return False
  lo,hi=min(p[-4:-1]),max(p[-4:-1]);return held if lo==hi else (c<lo+.75*(hi-lo) if held else c<=lo+.25*(hi-lo))
 if k=='ST-25':return (c<avg(3) if held else c<=avg(3)*.99) if n>=3 else False
 if k=='ST-30':return c/p[-4]>max(1,b[-1]/b[-4]) if n>=4 else False
 if k=='ST-34':return c>p[-4] and b[-1]>b[-4] if n>=4 else False
 raise ValueError('Unsupported strategy')

def number(v,lo,hi):
 if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not lo<=v<=hi:raise ValueError('Invalid numeric parameter')
 return v

def run(prices,bench,strategy,capital=100000,allocation=50,stop=5,drawdown=10,fee_bps=15,normal_spread=10,stress_spread=40,slippage=5,limit=None):
 if strategy not in RULES:raise ValueError('Unsupported strategy')
 for x,lo,hi in [(capital,100,1e8),(allocation,1,100),(stop,0,100),(drawdown,0,100),(fee_bps,0,200),(normal_spread,0,200),(stress_spread,0,500),(slippage,0,200)]:number(x,lo,hi)
 if stress_spread<normal_spread:raise ValueError('Stress spread below normal spread')
 if len(prices)!=len(bench) or len(prices)<2:raise ValueError('Aligned paths required')
 if limit is None:limit=len(prices)-1
 if type(limit)!=int or not 0<=limit<len(prices):raise ValueError('Invalid cutoff')
 p=list(prices[:limit+1]);b=list(bench[:limit+1]);
 if any(type(v)!=int or v<=0 for v in p) or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in b):raise ValueError('Invalid prices')
 initial=money(capital);cash=initial;qty=0;entry=None;pending=None;peak=initial;locked=False;orders=[];decisions=[];curve=[];fees=0;friction=0
 for t,mid in enumerate(p):
  if pending:
   side,q,submitted,reason=pending;stress=abs(b[t]/b[t-1]-1)>=.02;bps=(stress_spread if stress else normal_spread)+slippage;delta=fee(mid,bps);px=mid+delta if side=='buy' else max(1,mid-delta);gross=q*px;cost=fee(gross,fee_bps);ok=(gross+cost<=cash and q>0) if side=='buy' else 0<q<=qty
   if ok:
    cash+=-gross-cost if side=='buy' else gross-cost;qty+=q if side=='buy' else -q;entry=px if side=='buy' else None;fees+=cost;friction+=q*abs(px-mid)
   orders.append(dict(submitted_step=submitted,execution_step=t,side=side,quantity=q,status='filled' if ok else 'rejected',price=px/100 if ok else None,fee=cost/100 if ok else 0,reason=reason,stress=stress));pending=None
  equity=cash+qty*mid;peak=max(peak,equity);dd=1-equity/peak
  if drawdown>0 and dd>=drawdown/100:locked=True
  stop_hit=bool(qty and stop>0 and mid/entry-1<=-stop/100)
  target=signal(strategy,p[:t+1],b[:t+1],bool(qty));reason='strategy';
  if locked or stop_hit:target=False;reason='portfolio_drawdown_lock' if locked else 'position_stop'
  action='hold';q=0
  if qty and not target:action='sell';q=qty
  elif not qty and target:
   # Quantity fixed at decision quote, with known cost allowance; actual next quote may reject.
   budget=min(cash,int(equity*allocation/100));estimate=mid+fee(mid,stress_spread+slippage);q=min(1000000,budget//max(1,estimate+fee(estimate,fee_bps)))
   while q and q*estimate+fee(q*estimate,fee_bps)>budget:q-=1
   if q:action='buy'
  # Always record the decision, even at cutoff. Final signal is not executed without a next step.
  if action!='hold':pending=(action,q,t,reason)
  decisions.append(dict(step=t,action=action,quantity=q,reason=reason,locked=locked))
  curve.append(dict(step=t,mark=mid/100,cash=cash/100,quantity=qty,equity=equity/100,drawdown_pct=dd*100,benchmark_gross_pct=(b[t]/b[0]-1)*100))
 filled=[o for o in orders if o['status']=='filled'];ret=(curve[-1]['equity']/(initial/100)-1)*100;rets=[y['equity']/x['equity']-1 for x,y in zip(curve,curve[1:])]
 return dict(strategy=strategy,data_class='D5',verified_historical=False,training_approved=False,initial=initial/100,ending_equity=curve[-1]['equity'],return_pct=ret,max_drawdown_pct=max(x['drawdown_pct'] for x in curve),step_volatility_pct=statistics.stdev(rets)*100 if len(rets)>=2 else None,filled=len(filled),rejected=len(orders)-len(filled),fees=fees/100,spread_slippage=friction/100,final_quantity=qty,pending_unexecuted=decisions[-1]['action']!='hold',curve=curve,decisions=decisions,orders=orders,benchmark_gross_pct=curve[-1]['benchmark_gross_pct'],live_authorized=False)

def experiment(world,scenario,ident,strategy,expose=False,**params):
 if scenario not in world.scenarios:raise ValueError('Unknown scenario')
 if world.scenarios[scenario]['split']!='train' and expose is not True:raise ValueError('Explicit evaluation exposure required')
 if ident not in world.paths[scenario] or world.kind(ident)!='exchange' or world.models[ident]!='equity_proxy':raise ValueError('Only modeled equity proxies supported in this version')
 p=world.paths[scenario][ident];b=world.factors[scenario]['EGX30'];r=run(p,b,strategy,**params);base=run(p,b,'ST-09',**{**params,'stop':0,'drawdown':0});return {**r,'scenario':scenario,'split':world.scenarios[scenario]['split'],'instrument_id':ident,'buy_hold':{k:v for k,v in base.items() if k not in ('orders','decisions')},'excess_vs_buy_hold_pct':r['return_pct']-base['return_pct'],'cash_benchmark_pct':0,'warning':'Synthetic normalized equity proxies; no genuine historical backtest. Allocation is an entry budget, not a continuously enforced exposure cap. Stops execute next step; no guaranteed price.'}

def historical_gate(world,ident):
 if ident not in world.catalog:raise ValueError('Unknown instrument')
 rows=world.samples(ident)['rows'];return {'instrument_id':ident,'observations':len(rows),'eligible':False,'reason':'Historical execution blocked: verified calendar, availability, adjustment basis, corporate actions, costs and reuse approval are not established.'}
